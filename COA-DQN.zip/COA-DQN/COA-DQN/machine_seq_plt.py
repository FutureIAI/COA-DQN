import matplotlib.pyplot as plt
from collections import Counter

# 假设训练后的序列
machine_seq_final = [1, 5, 2, 3, 3, 4, 6, 7, 2, 3, 1, 3, 3, 4, 5, 2, 7, 6, 5, 1,
                     3, 4, 3, 2, 6, 7, 6, 5, 3, 4, 1, 2, 3, 6, 7, 7, 1, 2, 5, 3,
                     4, 7, 2, 3, 6, 1, 2, 4, 5, 7, 3, 2, 5, 3, 7, 1, 6, 4]

worker_seq_final = [1, 3, 2, 4, 4, 2, 3, 5, 4, 1, 5, 1, 4, 2, 5, 3, 5, 2, 1, 1,
                    4, 3, 4, 2, 3, 5, 3, 1, 4, 2, 5, 4, 3, 2, 5, 4, 1, 5, 3, 4,
                    2, 5, 4, 4, 2, 1, 3, 3, 5, 4, 4, 5, 1, 4, 4, 2, 3, 1]

# 统计每个机器和工人的任务数
machine_count = Counter(machine_seq_final)
worker_count = Counter(worker_seq_final)

# 排序保证编号顺序
machine_ids = sorted(machine_count.keys())
worker_ids = sorted(worker_count.keys())
machine_load = [machine_count[m] for m in machine_ids]
worker_load = [worker_count[w] for w in worker_ids]

# 绘图
fig, axs = plt.subplots(1, 2, figsize=(12, 5))

# 机器负载分布
axs[0].bar(machine_ids, machine_load, color='skyblue')
axs[0].set_title('机器负载分布')
axs[0].set_xlabel('机器编号')
axs[0].set_ylabel('任务数量')
axs[0].set_xticks(machine_ids)

# 工人负载分布
axs[1].bar(worker_ids, worker_load, color='salmon')
axs[1].set_title('工人负载分布')
axs[1].set_xlabel('工人编号')
axs[1].set_ylabel('任务数量')
axs[1].set_xticks(worker_ids)

plt.tight_layout()
plt.show()
