from random import random

import numpy as np
from matplotlib import pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D
from numpy import array

from fjsp import FJSP
import random as rd


def simulate_drc_fjsp_arrays(job_arr, mac_arr, time_arr, wc_arr):
    """
    针对 NumPy 数组的双资源调度仿真
    返回: (完工时间, 开始时刻字典)
    """
    # 自动识别资源规模
    num_m = int(np.max(mac_arr) + 1)
    num_w = int(np.max(wc_arr) + 1)

    # 初始化资源空闲状态
    m_avail = np.zeros(num_m)  # 机器
    w_avail = np.zeros(num_w)  # 工人
    j_avail = {}  # 工件工序就绪时刻
    op_counter = {}  # 记录工件内部工序索引

    start_times_record = {}

    for i in range(len(job_arr)):
        j_id = int(job_arr[i])
        m_id = int(mac_arr[i])
        w_idx = int(wc_arr[i] - 1)  # 假设工人ID 1-indexed, 转 0-indexed

        # 获取该工件当前第几道工序 (0, 1, 2...)
        idx = op_counter.get(j_id, 0)

        # 计算开工时间: max(机器空闲, 工人空闲, 工件前序完工)
        prev_f = j_avail.get(j_id, 0.0)
        s_ij = max(m_avail[m_id], w_avail[w_idx], prev_f)
        e_ij = s_ij + time_arr[i]

        # 记录
        start_times_record[(j_id, idx)] = (m_id, s_ij)

        # 更新状态
        m_avail[m_id] = e_ij
        w_avail[w_idx] = e_ij
        j_avail[j_id] = e_ij
        op_counter[j_id] = idx + 1

    makespan = max(j_avail.values()) if j_avail else 0
    return makespan, start_times_record


def calculate_sta_metrics(orig_data, res_data, failed_m_idx):
    """
    计算完工时间与稳定性
    """
    # 1. 运行仿真获取时间表
    mt_orig, starts_orig = simulate_drc_fjsp_arrays(orig_data['j'], orig_data['m'], orig_data['t'], orig_data['w'])
    mt_res, starts_res = simulate_drc_fjsp_arrays(res_data['j'], res_data['m'], res_data['t'], res_data['w'])

    # 2. 计算 Sta (公式 5-7)
    # Sta = Σ |S' - S| * (1 - Fk)
    sta = 0.0
    for key, (m_id_res, s_res) in starts_res.items():
        if key in starts_orig:
            _, s_orig = starts_orig[key]

            # (1 - Fk) 逻辑：如果当前工序分配到了故障机器，则不计入稳定性损失
            f_k = 1 if m_id_res == failed_m_idx else 0

            sta += abs(s_res - s_orig) * (1 - f_k)

    return mt_orig, mt_res, sta



import numpy as np


def split_data_by_failure(data, fail_m, fail_time):
    # 提取数组
    j_arr = data['j']
    m_arr = data['m']
    t_arr = data['t']
    w_arr = data['w']

    # 记录资源空闲时刻
    m_clocks = {} # 机器空闲时间
    w_clocks = {} # 工人空闲时间
    j_clocks = {} # 工件(Job)工序结束时间 <-- 新增

    pre_indices = []
    post_indices = []

    for i in range(len(j_arr)):
        job_id = j_arr[i]
        m_id = m_arr[i]
        w_id = w_arr[i]
        dur = t_arr[i]

        # 核心：三重资源约束逻辑
        # 任务必须等到：机器空闲 AND 工人空闲 AND 该工件前一道工序完成
        m_ready = m_clocks.get(m_id, 0)
        w_ready = w_clocks.get(w_id, 0)
        j_ready = j_clocks.get(job_id, 0) # <-- 获取该工件上一道工序的结束时间

        # 实际开始时间是三者取最大
        start_t = max(m_ready, w_ready, j_ready)
        end_t = start_t + dur

        # 划分逻辑
        # 只有在故障前完全结束的任务才算 before
        if end_t <= fail_time:
            pre_indices.append(i)
            # 更新所有相关资源的时钟
            m_clocks[m_id] = end_t
            w_clocks[w_id] = end_t
            j_clocks[job_id] = end_t # <-- 更新工件时钟
        else:
            post_indices.append(i)
            # 注意：一旦某个工序跨越了 fail_time，
            # 该工件后续的所有工序即便 end_t 计算出来小于 fail_time (逻辑上不可能)
            # 也必须全部划入 post，以保证工序顺序不乱。
            # 强制将该工件之后的 j_ready 设为无穷大，确保其后续工序必定进入 else 分支
            j_clocks[job_id] = 9999999

    # 封装返回 (代码与你原先的一致)
    before_failure = {key: data[key][pre_indices] if pre_indices else np.array([]) for key in data}
    after_failure = {key: data[key][post_indices] if post_indices else np.array([]) for key in data}

    return before_failure, after_failure


def combine_data(before, after):
    """将故障前和故障后的数据重新合并为 NumPy 数组字典"""
    combined = {}
    for key in before.keys():
        combined[key] = np.concatenate((before[key], after[key]))
    return combined


def generate_elite_schedule(j_seq, opt_m, opt_t, opt_w, broken_m=6):
    n = len(j_seq)
    new_m = np.zeros(n, dtype=int)
    new_t = np.zeros(n, dtype=int)
    new_w = np.zeros(n, dtype=int)

    # 用于记录每个工件当前是第几个工序
    job_step_counter = {}
    # 记录各机器负载
    m_load = {m: 0 for m in range(1, 7) if m != broken_m}

    for i in range(n):
        job_id = j_seq[i]
        # 获取当前工序索引
        step_idx = job_step_counter.get(job_id, 0)
        job_step_counter[job_id] = step_idx + 1

        # 获取该工序可选机器和时间
        possible_ms = opt_m[job_id][step_idx]
        possible_ts = opt_t[job_id][step_idx]

        # 过滤掉损坏的机器 6
        valid_options = []
        for idx, m_val in enumerate(possible_ms):
            if m_val != broken_m:
                valid_options.append({
                    'm': m_val,
                    't': possible_ts[idx]
                })

        # 精英选择策略：
        if not valid_options:
            # 如果该工序只能在机器6做（极端情况），回退到同job其他机器（此处根据数据通常不会发生）
            selected_m = 1
            selected_t = 999
        else:
            # 1. 优先选时间最短的 (SPT)
            # 2. 时间一样选当前负载最小的 (Load Balance)
            valid_options.sort(key=lambda x: (x['t'], m_load.get(x['m'], 0)))
            selected_m = valid_options[0]['m']
            selected_t = valid_options[0]['t']

        # 分配工人：选择该机器可选工人集中负载最低的或第一个
        # 这里简化为选第一个合规工人，实际可进一步优化工人负载
        selected_w = opt_w[selected_m][0]

        # 更新数据
        new_m[i] = selected_m
        new_t[i] = selected_t
        new_w[i] = selected_w
        m_load[selected_m] += selected_t

    return {
        'j': j_seq,
        'm': new_m,
        't': new_t,
        'w': new_w
    }


def reschedule_min_impact(origin, opt_m, opt_t, opt_w, broken_m=6):
    new_m = origin['m'].copy()
    new_t = origin['t'].copy()
    new_w = origin['w'].copy()
    j_seq = origin['j']

    # 记录每个工件当前遍历到第几个工序
    job_step_counter = {}

    for i in range(len(j_seq)):
        job_id = j_seq[i]
        step = job_step_counter.get(job_id, 0)
        job_step_counter[job_id] = step + 1

        # 检查是否为故障机器上的任务
        if origin['m'][i] == broken_m:
            # 获取该工序在 opt_m 中的约束
            # 容错：防止 j 序列中的工序数超过 opt_m 定义
            if step >= len(opt_m[job_id]):
                step = len(opt_m[job_id]) - 1

            choices = opt_m[job_id][step]
            times = opt_t[job_id][step]

            # 过滤掉坏掉的机器 6，并寻找最优替代（时间最短）
            best_m = -1
            min_time = float('inf')

            for idx, m_val in enumerate(choices):
                if m_val != broken_m:
                    if times[idx] < min_time:
                        min_time = times[idx]
                        best_m = m_val

            # 如果找到了替代机器
            if best_m != -1:
                new_m[i] = best_m
                new_t[i] = min_time
                # 更新工人：如果原工人能操作新机器，则保留；否则换该机器第一个可用工人
                # 注意 opt_w 索引可能需匹配（假设 opt_w[0] 是机器 0）
                allowed_workers = opt_w[best_m]
                if origin['w'][i] not in allowed_workers:
                    new_w[i] = allowed_workers[0]
                else:
                    new_w[i] = origin['w'][i]

    return {'j': j_seq, 'm': new_m, 't': new_t, 'w': new_w}


def reschedule_after_failure(schedule, opt_m, opt_t, opt_w, broken_machine=6):
    """
    针对机器损坏后的重新调度方案生成，增加了安全性检查
    """
    new_j = schedule['j'].copy()
    new_m = schedule['m'].copy()
    new_t = schedule['t'].copy()
    new_w = schedule['w'].copy()

    job_step_counter = {}

    for i in range(len(new_j)):
        job_id = new_j[i]
        step_idx = job_step_counter.get(job_id, 0)
        job_step_counter[job_id] = step_idx + 1

        # --- 安全性检查开始 ---
        # 1. 检查 job_id 索引是否合法
        if job_id >= len(opt_m):
            continue

        # 2. 检查该工件在约束集中是否有定义的工序
        if not opt_m[job_id]:
            continue

        # 3. 检查当前工序步数是否超出约束定义的范围
        if step_idx >= len(opt_m[job_id]):
            continue
        # --- 安全性检查结束 ---

        # 如果当前工序分配到了损坏的机器上
        if new_m[i] == broken_machine:
            possible_machines = opt_m[job_id][step_idx]
            possible_times = opt_t[job_id][step_idx]

            # 过滤掉损坏的机器
            valid_indices = [idx for idx, m in enumerate(possible_machines) if m != broken_machine]

            if not valid_indices:
                # 如果没有备选机器，保持原状或根据业务逻辑处理
                continue

            # 随机选择索引
            chosen_idx = rd.choice(valid_indices)

            chosen_machine = possible_machines[chosen_idx]
            chosen_time = possible_times[chosen_idx]

            # 选择合规工人 (确保 chosen_machine 在 opt_w 范围内)
            if chosen_machine < len(opt_w) and opt_w[chosen_machine]:
                chosen_worker = rd.choice(opt_w[chosen_machine])
            else:
                # 备选：如果 opt_w 索引不对，保留原工人或指派默认值
                chosen_worker = new_w[i]

            # 更新数据
            new_m[i] = chosen_machine
            new_t[i] = chosen_time
            new_w[i] = chosen_worker

    return {
        'j': new_j,
        'm': new_m,
        't': new_t,
        'w': new_w
    }


def generate_MT_elite_individual(data, opt_m, opt_t, opt_w):
    # 1. 预处理约束数据
    # 将 opt_m 中的机器编号从 1-7 转为 0-6，以匹配 data['m']
    adj_opt_m = [[[m - 1 for m in step] for step in job] for job in opt_m]

    # 提取原始工件序列
    j_sequence = data['j'].astype(int)
    num_ops = len(j_sequence)

    # 初始化新个体的容器
    new_m = np.zeros(num_ops, dtype=int)
    new_t = np.zeros(num_ops, dtype=float)
    new_w = np.zeros(num_ops, dtype=int)

    # 资源空闲时间追踪
    num_machines = len(opt_w)
    m_free_time = np.zeros(num_machines)  # 机器空闲时刻
    j_free_time = {}  # 工件空闲时刻

    # 统计工人总数并初始化工人空闲时刻
    all_workers = set()
    for workers in opt_w:
        all_workers.update(workers)
    w_free_time = {w: 0.0 for w in all_workers}

    # 记录每个 job 当前进行到第几道工序
    job_step_counter = {}

    # 2. 开始按顺序优化每一道工序
    for i in range(num_ops):
        job_id = j_sequence[i]
        step_idx = job_step_counter.get(job_id, 0)
        job_step_counter[job_id] = step_idx + 1

        # 获取该工序可选的机器和对应的时间
        # 安全检查：防止序列中的工序数超过约束定义
        if job_id >= len(adj_opt_m) or step_idx >= len(adj_opt_m[job_id]):
            # 若超出约束定义，保留原分配（兜底逻辑）
            new_m[i], new_t[i], new_w[i] = data['m'][i], data['t'][i], data['w'][i]
            continue

        candidates_m = adj_opt_m[job_id][step_idx]
        candidates_t = opt_t[job_id][step_idx]

        best_m = -1
        best_w = -1
        best_t = -1
        earliest_finish = float('inf')

        # 3. 在可选资源中寻找最优组合 (使该工序结束最早)
        for m_idx, m_val in enumerate(candidates_m):
            proc_time = candidates_t[m_idx]
            # 检查该机器可选的工人
            for worker_id in opt_w[m_val]:
                # 开始时间 = max(机器好, 工人好, 工件上道工序完)
                start_time = max(m_free_time[m_val],
                                 w_free_time[worker_id],
                                 j_free_time.get(job_id, 0))
                finish_time = start_time + proc_time

                # 精英选择策略：结束时间越早越好
                if finish_time < earliest_finish:
                    earliest_finish = finish_time
                    best_m = m_val
                    best_w = worker_id
                    best_t = proc_time

        # 4. 锁定资源并更新新个体数据
        new_m[i] = best_m
        new_w[i] = best_w
        new_t[i] = best_t

        m_free_time[best_m] = earliest_finish
        w_free_time[best_w] = earliest_finish
        j_free_time[job_id] = earliest_finish

    # 5. 构建结果字典
    elite_individual = {
        'j': data['j'].copy(),
        'm': new_m,
        't': new_t,
        'w': new_w
    }

    return elite_individual, max(m_free_time)
import numpy as np
import matplotlib.pyplot as plt




# --- 调用演示 ---
# draw_with_failure_style(before, after, fail_m=6, fail_time=60, repair_dur=40)
# --- 测试代码 ---
orig_arrays = {
    'j': np.array(
        [4, 18, 9, 16, 6, 12, 11, 15, 5, 11, 2, 9, 8, 2, 13, 16, 15, 14, 3, 12, 3, 7, 5, 12, 17, 6, 18, 11, 4, 14, 19,
         18, 10, 15, 2, 7, 5, 16, 14, 17, 7, 3, 11, 18, 2, 1, 16, 7, 3, 9, 0, 14, 12, 7, 4, 6, 13, 12]),
    'm': np.array(
        [0, 1, 2, 2, 6, 4, 3, 1, 6, 4, 3, 0, 2, 4, 6, 1, 5, 0, 2, 4, 0, 5, 1, 6, 3, 4, 6, 5, 2, 6, 1, 4, 3, 6, 2, 1, 4,
         4, 0, 6, 1, 5, 2, 6, 5, 2, 1, 4, 3, 6, 2, 4, 5, 3, 5, 4, 6, 2]),
    't': np.array(
        [25, 19, 17, 35, 14, 30, 12, 37, 12, 10, 15, 17, 35, 25, 19, 35, 38, 13, 19, 12, 19, 43, 23, 10, 12, 30, 10, 47,
         29, 24, 35, 10, 11, 13, 31, 17, 17, 10, 15, 11, 20, 10, 18, 14, 24, 14, 10, 23, 20, 12, 17, 26, 14, 24, 15, 14,
         27, 20]),
    'w': np.array(
        [5, 2, 4, 4, 5, 1, 3, 3, 4, 5, 1, 5, 1, 3, 5, 4, 2, 5, 3, 1, 1, 2, 3, 4, 2, 5, 4, 2, 1, 4, 3, 3, 1, 5, 4, 3, 1,
         1, 5, 5, 3, 2, 1, 5, 2, 1, 4, 5, 1, 4, 4, 5, 2, 2, 3, 5, 4, 1])
}


# 假设机器 6 在时间点 50 发生故障
before, after = split_data_by_failure(orig_arrays, fail_m=6, fail_time=50)

print("before", before)
print("after", after)
# print("res_dict", new_individual)

# print("rescheduled_tasks", rescheduled_tasks)

# 验证返回类型


# ==================== 1. 数据准备 (已转换为 np 数组) ====================
opt_m = [[[1, 3, 4, 5, 6, 7]], [[3, 5]], [[1, 5, 7], [1, 2, 3, 4, 6, 7], [1, 6, 7]], [[2, 3, 6, 7], [1, 3, 4, 5], [2, 3, 6, 7], [2, 3, 4, 5, 6, 7]], [[1, 6, 7], [3, 6], [1, 3, 5, 6]], [[1, 2, 3, 4, 6, 7], [2, 3, 5], [1, 2, 3, 5, 6, 7]], [[5, 6], [1, 3, 5]], [[2, 3, 7], [1, 2, 4, 5, 6, 7], [3, 4, 5, 6], [1, 2, 4, 5, 6]], [[1, 3, 7]], [[1, 2, 3, 4, 6, 7], [1, 2, 3, 4, 6, 7]], [[1, 2, 3, 4, 5]], [[1, 3, 4, 6, 7], [1, 2, 3, 4, 5, 7], [1, 4, 5, 6], [3, 4, 5, 6, 7]], [[4, 5], [1, 3, 5, 6], [3, 7], [1, 3, 4, 5, 6, 7], [1, 3, 4, 5, 7]], [[5, 7]], [[1, 3, 4, 6], [1, 2, 3, 5, 7], [1, 3, 4, 5, 6, 7], [1, 2, 3, 4, 5, 6]], [[1, 3, 4, 6], [1, 4, 5, 7]], [[1, 3], [2, 4, 5, 6], [1, 2, 3, 4, 5, 6], [2, 3, 5, 6, 7]], [[1, 3, 4], [1, 2, 4, 6, 7]], [[2, 3, 4, 5, 6, 7], [1, 3, 5, 7]], [[1, 2]]]
opt_t = [[[25, 17, 42, 24, 27, 36]], [[14, 16]], [[39, 41, 15, 36, 30], [25, 25, 25], [49, 31, 31, 28, 34, 43], [37, 24, 43]], [[38, 19, 47, 43], [19, 13, 23, 17], [28, 32, 10, 42], [29, 19, 20, 45, 38, 43]], [[25, 38, 45], [29, 39], [23, 28, 32, 15]], [[42, 39, 32, 42, 13, 12], [23, 49, 38], [37, 37, 42, 17, 46, 39]], [[22, 38, 14], [30, 50], [28, 27, 14]], [[45, 48, 43, 42], [17, 38, 44], [40, 20, 46, 49, 42, 38], [42, 36, 23, 41], [41, 41, 24, 43, 45]], [[38, 35, 41]], [[42, 17], [17, 10, 26, 23, 46, 38], [35, 29, 18, 23, 42, 12]], [[21, 37, 34, 11, 36]], [[47, 43, 12, 19, 43], [43, 40, 42, 23, 10, 26], [44, 50, 47, 47], [18, 30, 27, 48, 21]], [[35, 30], [28, 42, 12, 50], [35, 10], [33, 11, 40, 14, 14, 33], [31, 20, 32, 28, 42]], [[33, 40, 19], [44, 27]], [[13, 23, 46, 45], [25, 22, 17, 29, 24], [15, 23, 21, 21, 31, 21], [18, 19, 46, 28, 26, 32]], [[39, 37, 30, 44, 43], [46, 37, 46, 38], [33, 12, 43, 13]], [[46, 35], [35, 36, 50, 39], [49, 33, 48, 28, 10, 44], [10, 22, 45, 40, 50]], [[35, 22, 12], [14, 20, 46, 27, 11]], [[19, 36, 37, 38, 46, 29], [27, 16, 18, 31, 33, 10], [47, 37, 14, 10, 16, 48], [41, 50, 36, 14]], [[42, 35]]]
opt_w = [[1, 2, 5], [2, 3, 4, 5], [1, 3, 4], [1, 2, 3], [1, 3, 5], [2, 3], [4, 5]]

new_individual = reschedule_after_failure(after, opt_m, opt_t, opt_w, broken_machine=6)
print("after", new_individual)
sta_value = calculate_sta_metrics(after,new_individual,6)
print("sta_value", sta_value)





# 预调度数据
orig_arrays = {
    'j': np.array(
        [4, 18, 9, 16, 6, 12, 11, 15, 5, 11, 2, 9, 8, 2, 13, 16, 15, 14, 3, 12, 3, 7, 5, 12, 17, 6, 18, 11, 4, 14, 19,
         18, 10, 15, 2, 7, 5, 16, 14, 17, 7, 3, 11, 18, 2, 1, 16, 7, 3, 9, 0, 14, 12, 7, 4, 6, 13, 12]),
    'm': np.array(
        [0, 1, 2, 2, 6, 4, 3, 1, 6, 4, 3, 0, 2, 4, 6, 1, 5, 0, 2, 4, 0, 5, 1, 6, 3, 4, 6, 5, 2, 6, 1, 4, 3, 6, 2, 1, 4,
         4, 0, 6, 1, 5, 2, 6, 5, 2, 1, 4, 3, 6, 2, 4, 5, 3, 5, 4, 6, 2]),
    't': np.array(
        [25, 19, 17, 35, 14, 30, 12, 37, 12, 10, 15, 17, 35, 25, 19, 35, 38, 13, 19, 12, 19, 43, 23, 10, 12, 30, 10, 47,
         29, 24, 35, 10, 11, 13, 31, 17, 17, 10, 15, 11, 20, 10, 18, 14, 24, 14, 10, 23, 20, 12, 17, 26, 14, 24, 15, 14,
         27, 20]),
    'w': np.array(
        [5, 2, 4, 4, 5, 1, 3, 3, 4, 5, 1, 5, 1, 3, 5, 4, 2, 5, 3, 1, 1, 2, 3, 4, 2, 5, 4, 2, 1, 4, 3, 3, 1, 5, 4, 3, 1,
         1, 5, 5, 3, 2, 1, 5, 2, 1, 4, 5, 1, 4, 4, 5, 2, 2, 3, 5, 4, 1])
}
machine_faults = {
    7: 30
}

# print("machine_state",machine_state)
# print("worker_state",worker_state)
# # print("before",before)

# orig_arrays = {
#     'j': np.array(
#         [1,2,3,4,5,6]
#     ),
#     'm': np.array(
#         [1, 2, 3, 4, 5, 6]
#     ),
#     't': np.array(
#         [1, 2, 3, 4, 5, 6]
#     ),
#     'w': np.array(
#         [1, 2, 3, 4, 5, 6]
#     )
#  }
# res_arrays = {
#     'j': np.array(
#         [1,2,3,4,5,6]
#     ),
#     'm': np.array(
#         [1, 2, 4, 4, 5, 6]
#     ),
#     't': np.array(
#         [1, 2, 6, 4, 5, 6]
#     ),
#     'w': np.array(
#         [1, 2, 5, 4, 5, 6]
#     )
#  }
# 重调度数据
res_arrays = {
    'j': np.array(
        [4, 18, 9, 16, 6, 12, 11, 15, 5, 11, 2, 9, 8, 17, 10, 14, 2, 14, 14, 12, 12, 7, 19, 14, 7, 16, 2, 13, 18, 7, 15,
         1, 17, 18, 7, 11, 5, 6, 9, 6, 15, 5, 18, 11, 2, 4, 3, 12, 4, 16, 3, 12, 3, 3, 7, 16, 0, 13]),
    'm': np.array(
        [0, 1, 2, 2, 6, 4, 3, 1, 6, 4, 3, 0, 2, 1, 0, 3, 1, 4, 0, 3, 5, 3, 0, 1, 1, 2, 2, 4, 0, 0, 2, 5, 1, 2, 3, 4, 4,
         4, 2, 5, 0, 1, 0, 5, 4, 0, 1, 3, 4, 4, 1, 0, 4, 3, 5, 5, 4, 1]),
    't': np.array(
        [25, 19, 17, 35, 14, 30, 12, 37, 12, 10, 15, 17, 35, 35, 42, 12, 16, 12, 13, 33, 43, 46, 44, 22, 23, 19, 17, 10,
         21, 15, 18, 39, 37, 35, 12, 10, 16, 25, 18, 15, 14, 17, 19, 10, 30, 40, 10, 28, 23, 44, 19, 28, 36, 24, 24, 14,
         28, 29]),
    'w': np.array(
        [5, 2, 4, 4, 5, 1, 3, 3, 4, 5, 1, 5, 1, 2, 2, 5, 4, 3, 5, 1, 2, 1, 5, 5, 2, 4, 3, 3, 4, 2, 3, 3, 5, 5, 3, 1, 5,
         3, 3, 1, 5, 1, 1, 2, 5, 1, 3, 1, 3, 3, 3, 1, 1, 2, 1, 3, 3, 5])
}

# elite_individual, m_free_time = generate_MT_elite_individual(res_arrays,opt_m,opt_t, opt_w)
#
# print("elite_individual",elite_individual)
# print("m_free_time",m_free_time)
# ==================== 2. 执行计算 ====================

# 设置 7号机器(索引为6) 发生重大故障
# FAILED_MACHINE = 5
#
# m1, m2, sta_val = calculate_sta_metrics(orig_arrays, res_arrays, FAILED_MACHINE)
#
# # ==================== 3. 结果输出 ====================
#
# print(f"{'指标':<25} | {'数值':<10}")
# print("-" * 40)
# print(f"{'原调度完工时间 (MT)':<25} | {m1:<10.2f}")
# print(f"{'重调度完工时间 (MT)':<25} | {m2:<10.2f}")
# print(f"{'调度稳定性值 (Sta)':<25} | {sta_val:<10.2f}")

after_failure = {'j': array([16., 19., 14., 14., 16., 10.,  2.,  8.,  7.,  2.,  9.,  7.,  4.,
       14., 18., 14., 15.,  5.,  4., 16.,  7.,  9.,  5.,  6., 13.,  6.,
       11.,  9., 11.,  4., 18.,  2.,  1., 15., 12., 12., 17., 15., 11.,
        3., 12.,  3.,  3.,  0., 12., 11.,  7., 17.,  7.,  6.,  3.]), 'm': array([4., 0., 2., 4., 3., 2., 4., 6., 6., 2., 2., 1., 6., 4., 5., 3., 1.,
       1., 5., 1., 1., 5., 6., 2., 4., 4., 3., 3., 6., 2., 6., 6., 2., 3.,
       4., 6., 3., 0., 5., 2., 2., 0., 6., 6., 4., 2., 3., 0., 0., 2., 1.]), 't': array([50., 42., 23., 29., 28., 34., 25., 41., 42., 31., 17., 17., 45.,
       21., 16., 28., 37., 23., 39., 10., 20., 46., 39., 22., 44., 30.,
       12., 23., 26., 28., 14., 43., 14., 46., 12., 10., 12., 33., 47.,
       19., 11., 19., 42., 36., 28., 18., 36., 14., 41., 27., 29.]), 'w': array([3., 2., 1., 3., 2., 1., 1., 5., 4., 3., 1., 5., 4., 5., 5., 1., 4.,
       4., 2., 5., 5., 2., 4., 1., 3., 3., 1., 2., 5., 4., 4., 4., 4., 3.,
       1., 4., 3., 1., 3., 4., 4., 2., 5., 5., 3., 3., 2., 1., 1., 1., 5.])}
end_Machine_choices = [[[1, 3, 4, 5, 6]], [[3, 5]], [[1, 5], [1, 2, 3, 4, 6], [1, 6]], [[2, 3, 6], [1, 3, 4, 5], [2, 3, 6], [2, 3, 4, 5, 6]], [[1, 6], [3, 6], [1, 3, 5, 6]], [[2, 3, 5], [1, 2, 3, 5, 6]], [[3, 6], [5, 6], [1, 3, 5]], [[3, 4, 6], [2, 3], [1, 2, 4, 5, 6], [3, 4, 5, 6], [1, 2, 4, 5, 6]], [[1, 3]], [[1, 3], [1, 2, 3, 4, 6], [1, 2, 3, 4, 6]], [[1, 2, 3, 4, 5]], [[1, 3, 4, 6], [1, 2, 3, 4, 5], [1, 4, 5, 6], [3, 4, 5, 6]], [[1, 3, 5, 6], [3], [1, 3, 4, 5, 6], [1, 3, 4, 5]], [[5]], [[1, 3, 4, 6], [1, 2, 3, 5], [1, 3, 4, 5, 6], [1, 2, 3, 4, 5, 6]], [[1, 2, 3, 6], [1, 3, 4, 6], [1, 4, 5]], [[2, 4, 5, 6], [1, 2, 3, 4, 5, 6], [2, 3, 5, 6]], [[1, 3, 4], [1, 2, 4, 6]], [[2, 3, 4, 5, 6], [1, 3, 5]], [[1, 2]]]
end_Proc_times = [[[25, 17, 42, 24, 27]], [[14, 16]], [[25, 25], [49, 31, 31, 28, 34], [37, 24]], [[38, 19, 47], [19, 13, 23, 17], [28, 32, 10], [29, 19, 20, 45, 38]], [[25, 38], [29, 39], [23, 28, 32, 15]], [[23, 49, 38], [37, 37, 42, 17, 46]], [[22, 38], [30, 50], [28, 27, 14]], [[45, 48, 43], [17, 38], [40, 20, 46, 49, 42], [42, 36, 23, 41], [41, 41, 24, 43, 45]], [[38, 35]], [[42, 17], [17, 10, 26, 23, 46], [35, 29, 18, 23, 42]], [[21, 37, 34, 11, 36]], [[47, 43, 12, 19], [43, 40, 42, 23, 10], [44, 50, 47, 47], [18, 30, 27, 48]], [[28, 42, 12, 50], [35], [33, 11, 40, 14, 14], [31, 20, 32, 28]], [[44]], [[13, 23, 46, 45], [25, 22, 17, 29], [15, 23, 21, 21, 31], [18, 19, 46, 28, 26, 32]], [[39, 37, 30, 44], [46, 37, 46, 38], [33, 12, 43]], [[35, 36, 50, 39], [49, 33, 48, 28, 10, 44], [10, 22, 45, 40]], [[35, 22, 12], [14, 20, 46, 27]], [[47, 37, 14, 10, 16], [41, 50, 36]], [[42, 35]]]
opt_w = [[1, 2, 5], [2, 3, 4, 5], [1, 3, 4], [1, 2, 3], [1, 3, 5], [2, 3], [4, 5]]
elite_individual, m_free_time = generate_MT_elite_individual(after_failure,end_Machine_choices,end_Proc_times, opt_w)
print("elite_individual",elite_individual)
print("m_free_time",m_free_time)