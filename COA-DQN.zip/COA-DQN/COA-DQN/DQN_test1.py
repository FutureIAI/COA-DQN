import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import random
from collections import deque


# ----------------- 1. DQN 核心网络 -----------------
class QNet(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(QNet, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, action_dim)
        )

    def forward(self, x):
        return self.fc(x)


# ----------------- 2. 强化学习调度环境 -----------------
class LocalRepairEnv:
    def __init__(self, machine_choices, proc_times, worker_choices_list, num_machines, num_workers):
        self.machine_choices = machine_choices
        self.proc_times = proc_times
        self.m_w_map = {i + 1: workers for i, workers in enumerate(worker_choices_list)}
        self.num_machines = num_machines
        self.num_workers = num_workers
        self.state_dim = self.num_machines * 2 + self.num_workers

    def set_chromosome(self, job_seq, machine_seq, worker_seq):
        self.job_seq = np.array(job_seq).astype(int)
        self.m_seq_orig = np.array(machine_seq).astype(int)
        self.w_seq_orig = np.array(worker_seq).astype(int)
        self.total_ops = len(self.job_seq)

    def reset(self):
        self.step_id = 0
        self.m_finish_times = np.zeros(self.num_machines)
        self.w_finish_times = np.zeros(self.num_workers)
        self.op_finish_times = {}
        self.job_op_counter = {}
        self.current_makespan = 0.0
        return self._get_state()

    def _get_state(self):
        job_id = int(self.job_seq[self.step_id])
        op_idx = int(self.job_op_counter.get(job_id, 0))
        m_state = self.m_finish_times.copy()
        w_state = self.w_finish_times.copy()
        t_state = np.zeros(self.num_machines)
        allowed_ms = self.machine_choices[job_id][op_idx]
        times = self.proc_times[job_id][op_idx]
        for m, t in zip(allowed_ms, times):
            idx = int(m) - 1
            if idx < self.num_machines:
                t_state[idx] = t
        return np.concatenate([m_state, w_state, t_state]).astype(np.float32)

    def _calc_metrics(self, m_idx, w_id, job_id, op_idx):
        allowed_ms = self.machine_choices[job_id][op_idx]
        t_idx = allowed_ms.index(m_idx + 1)
        p_time = self.proc_times[job_id][op_idx][t_idx]
        prev_f = self.op_finish_times.get((job_id, op_idx - 1), 0)
        start_t = max(self.m_finish_times[m_idx], self.w_finish_times[w_id - 1], prev_f)
        finish_t = start_t + p_time
        v = max(self.current_makespan, finish_t)
        p = p_time * 1.5
        l = p_time
        return v, p, l, finish_t, p_time

    def step(self, action_idx):
        job_id = int(self.job_seq[self.step_id])
        op_idx = int(self.job_op_counter.get(job_id, 0))

        # 基准计算
        orig_m_idx = self.m_seq_orig[self.step_id]
        orig_w_id = self.w_seq_orig[self.step_id]
        v_orig, P_orig, L_orig, _, _ = self._calc_metrics(orig_m_idx, orig_w_id, job_id, op_idx)

        # 智能体决策执行
        allowed_ws = self.m_w_map[action_idx + 1]
        chosen_w_id = min(allowed_ws, key=lambda w: self.w_finish_times[int(w) - 1])
        v_new, P_new, L_new, f_t_new, p_t_new = self._calc_metrics(action_idx, chosen_w_id, job_id, op_idx)

        # 临时奖励 r_t
        dv = (v_new - v_orig) / max(1.0, v_orig)
        dp = (P_new - P_orig) / max(1.0, P_orig)
        dl = (L_new - L_orig) / max(1.0, L_orig)
        r_t = -(dv + dp + dl)

        # 更新环境
        self.m_finish_times[action_idx] = f_t_new
        self.w_finish_times[chosen_w_id - 1] = f_t_new
        self.op_finish_times[(job_id, op_idx)] = f_t_new
        self.job_op_counter[job_id] = op_idx + 1
        self.current_makespan = v_new

        self.step_id += 1
        done = self.step_id >= self.total_ops
        next_s = self._get_state() if not done else None
        return next_s, r_t, done, (action_idx + 1, chosen_w_id, p_t_new)


# ----------------- 3. 封装类：DQN_RL -----------------
class DQN_RL:
    def __init__(self, machine_choices, proc_times, worker_choices, num_machines, num_worker):
        self.machine_choices = machine_choices
        self.proc_times = proc_times
        self.env = LocalRepairEnv(machine_choices, proc_times, worker_choices, num_machines, num_worker)
        self.memory = deque(maxlen=10000)
        self.net = QNet(self.env.state_dim, num_machines)
        self.target_net = QNet(self.env.state_dim, num_machines)
        self.target_net.load_state_dict(self.net.state_dict())
        self.optimizer = optim.Adam(self.net.parameters(), lr=0.001)
        self.gamma, self.epsilon, self.epsilon_min, self.decay = 0.95, 1.0, 0.1, 0.98

        # --- 混合奖励系数 alpha (0.5表示即时与延迟同等重要) ---
        self.alpha = 0.5

    def _update_net(self):
        if len(self.memory) < 64: return
        batch = random.sample(self.memory, 64)
        s, a, r, sn, d = zip(*batch)
        s, sn = torch.FloatTensor(np.array(s)), torch.FloatTensor(np.array(sn))
        a, r, d = torch.LongTensor(a).view(-1, 1), torch.FloatTensor(r).view(-1, 1), torch.FloatTensor(d).view(-1, 1)
        q_curr = self.net(s).gather(1, a)
        q_next = self.target_net(sn).max(1)[0].detach().view(-1, 1)
        target = r + self.gamma * q_next * (1 - d)
        loss = nn.MSELoss()(q_curr, target)
        self.optimizer.zero_grad();
        loss.backward();
        self.optimizer.step()

    def train(self, job_seq, machine_seq_orig, worker_seq_orig, episodes=30):
        self.env.set_chromosome(job_seq, machine_seq_orig, worker_seq_orig)
        for ep in range(episodes):
            state = self.env.reset()
            done, r_t_history, transitions = False, [], []
            while not done:
                job_id = int(self.env.job_seq[self.env.step_id])
                op_idx = int(self.env.job_op_counter.get(job_id, 0))
                allowed = [m - 1 for m in self.machine_choices[job_id][op_idx]]
                if random.random() < self.epsilon:
                    action = random.choice(allowed)
                else:
                    st = torch.FloatTensor(state).unsqueeze(0)
                    with torch.no_grad():
                        q = self.net(st)
                    mask = torch.full_like(q, float('-inf'))
                    mask[0, allowed] = 0
                    action = torch.argmax(q + mask).item()

                next_s, r_t, done, _ = self.env.step(action)
                transitions.append((state, action, next_s, done))
                r_t_history.append(r_t)
                state = next_s

            # --- 核心修改：计算混合奖励 ---
            R_k = sum(r_t_history) / len(r_t_history)
            for i, (s, a, sn, d) in enumerate(transitions):
                # 混合公式：alpha * 即时奖励 + (1-alpha) * 延迟奖励
                mixed_reward = self.alpha * r_t_history[i] + (1 - self.alpha) * R_k

                self.memory.append((s, a, mixed_reward, sn if sn is not None else np.zeros_like(s), d))

            if self.epsilon > self.epsilon_min: self.epsilon *= self.decay
            self._update_net()
            if ep % 20 == 0:
                self.target_net.load_state_dict(self.net.state_dict())
                # print(f"Ep {ep}, R_k: {R_k:.4f}, Cmax: {self.env.current_makespan:.1f}, Eps: {self.epsilon:.2f}")
        return self._get_final_results(job_seq)

    def _get_final_results(self, job_seq):
        state = self.env.reset()
        done, res_m, res_w, res_t = False, [], [], []
        with torch.no_grad():
            while not done:
                job_id = int(self.env.job_seq[self.env.step_id])
                op_idx = int(self.env.job_op_counter.get(job_id, 0))
                allowed = [m - 1 for m in self.machine_choices[job_id][op_idx]]
                st = torch.FloatTensor(state).unsqueeze(0)
                q = self.net(st)
                mask = torch.full_like(q, float('-inf'))
                mask[0, allowed] = 0
                action = torch.argmax(q + mask).item()
                next_s, _, done, info = self.env.step(action)
                m, w, t = info
                res_m.append(m - 1)
                res_w.append(w)
                res_t.append(t)
                state = next_s
        return res_m, res_w, res_t