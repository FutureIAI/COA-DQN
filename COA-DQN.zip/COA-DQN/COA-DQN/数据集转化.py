# 原始MK数据集
mk_data = """4 3 2
5 2 0 56 1 50 1 2 39 2 1 58 2 37 2 0 22 2 35 3 0 31 1 70 2 70
5 2 0 46 2 64 3 0 73 1 57 2 56 2 0 10 2 10 2 1 36 2 11 2 1 12 2 18 2 0 39 2 16
4 1 1 49 2 0 40 2 43 2 0 63 1 60 1 1 36
1 1 0 46"""

# 解析并转换为指定格式
lines = mk_data.strip().split('\n')
header = list(map(int, lines[0].split()))
n_jobs, n_machines, n_workers = header  # 4工件、3机器、2工人

# 初始化加工时间矩阵（3机器×7工序，默认-1.0）
process_time_matrix = [[-1.0 for _ in range(7)] for _ in range(n_machines)]

# 解析每个工件的工序-机器-时间信息
for job_idx, line in enumerate(lines[1:]):
    parts = list(map(int, line.split()))
    n_ops = parts[0]  # 该工件的工序数
    op_idx = 0
    i = 1
    while i < len(parts):
        n_mach_for_op = parts[i]  # 该工序可选机器数
        i += 1
        for _ in range(n_mach_for_op):
            mach = parts[i] - 1  # 机器编号转0开始（原数据从1开始）
            time = parts[i+1]
            # 填充到矩阵（按工序顺序映射到7列）
            if op_idx < 7 and mach < n_machines:
                process_time_matrix[mach][op_idx] = float(time)
            i += 2
        op_idx += 1

# 替换为你指定的目标值（若需自定义而非解析原始数据）
target_matrix = [
    [25, -1.0, 17, 42, 24, 27, 36],
    [-1.0, -1.0, 14, -1.0, 16, -1.0, -1.0],
    [39, 41, -1.0, 15, 36, 30, -1.0]
]
process_time_matrix = target_matrix

# 输出最终格式
print("机器加工时间矩阵：")
for row in process_time_matrix:
    print(row)