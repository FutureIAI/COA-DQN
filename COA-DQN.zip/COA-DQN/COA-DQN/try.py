import math
import numpy as np
import scipy
# def distanse(x, y):
#
#         return math.sqrt(sum([pow(a - b, 2) for a, b in zip(x, y)]))
#
# def get_IGD(c, a):
#         print([min([distanse(i, j) for j in a]) for i in c])
#         return sum([min([distanse(i, j) for j in a]) for i in c])


PFture=[[340.0, 3027.0, 46855.25393701123], [433.0, 2772.0, 45335.580235695765], [363.0, 2792.0, 44948.22803708737], [563.0, 2849.0, 47696.63648835016], [374.0, 3056.0, 48635.67815419202], [396.0, 2932.0, 49238.23883630553], [561.0, 2893.0, 47604.546062749374], [507.0, 2919.0, 48339.02450616505], [442.0, 2927.0, 47918.20720026158], [532.0, 2857.0, 48643.9178194409], [431.0, 2875.0, 48464.17670131818], [424.0, 2908.0, 48600.36483455529], [514.0, 2876.0, 48322.43077035033], [422.0, 2975.0, 48890.33475778913], [467.0, 2854.0, 46315.01999493698], [347.0, 3002.0, 47156.251961502654], [453.0, 2892.0, 50429.251487667854], [360.0, 2926.0, 47433.98697409786], [447.0, 2894.0, 48190.55705999295], [544.0, 2783.0, 48949.25567228989], [359.0, 2852.0, 45747.49884070224], [363.0, 2842.0, 46417.20803187473], [480.0, 2787.0, 46306.43196743528], [380.0, 2850.0, 45306.6300082002], [433.0, 2815.0, 47843.50978765771], [485.0, 2829.0, 46177.88216056261], [419.0, 2835.0, 47045.835932354734], [465.0, 2830.0, 47810.69407732191], [427.0, 2736.0, 44278.706855052435], [376.0, 2871.0, 46451.33297784857], [404.0, 2867.0, 47870.35564078478], [423.0, 2833.0, 46164.770254214076], [407.0, 2845.0, 46000.941583490945], [339.0, 2953.0, 47786.72025053446], [414.0, 2769.0, 45388.080476185125], [397.0, 2817.0, 45332.63591039796], [390.0, 2828.0, 46376.0362514859], [564.0, 2869.0, 48975.06582977229], [380.0, 3006.0, 47423.26715015204], [500.0, 2877.0, 49777.41828114566], [492.0, 2887.0, 46964.648498642535], [415.0, 2996.0, 48432.363662083575], [437.0, 2916.0, 48024.69236087295], [422.0, 2944.0, 47588.95430466828], [490.0, 2934.0, 47682.77150978581], [363.0, 3167.0, 51221.46521478627], [442.0, 2788.0, 45147.860851999925], [394.0, 2955.0, 49176.58974307062], [403.0, 2930.0, 46606.366151058864], [429.0, 2807.0, 46458.86591573517], [365.0, 2920.0, 46617.72186297742], [482.0, 2781.0, 46065.303114656184], [392.0, 2807.0, 45364.41044333971]]

b=[[356.0, 3108.0, 50194.68066884268], [556.0, 2812.0, 47812.41147999588], [384.0, 2856.0, 45845.559661740204], [374.0, 3004.0, 49222.55821418276]]




IGD=0
ob1,ob2,ob3=[],[],[]
for i in range(len(PFture)):
        ob1.append(PFture[i][0])
        ob2.append(PFture[i][1])
        ob3.append(PFture[i][2])
max1,min1,max2,min2,max3,min3=max(ob1),min(ob1),max(ob2),min(ob2),max(ob3),min(ob3)
maxob=[max1,max2,max3]
minob=[min1,min2,min3]
for i in range(len(PFture)):
        di=[]
        for j in range(len(b)):
                diff=0
                for ob in range(3):

                        fz1=(b[j][ob]-minob[ob])/(maxob[ob]-minob[ob])
                        # print(fz1)
                        fz2=(PFture[i][ob]-minob[ob])/(maxob[ob]-minob[ob])
                        # print(fz1,fz2)
                        diff=diff+pow(fz2-fz1,2)
                di.append(diff)

        d=min(di)
        # print(d)
        IGD=IGD+math.sqrt(d)
        # print(IGD)
print("IGD=",IGD/len(PFture))


# print(len(c))
# num=0
#
# IGD=0
# for i in range(len(c)):
#
#         c1=c[i][0]
#         c2=c[i][1]
#         c3=c[i][2]
#         IGD=IGD+min(math.sqrt(math.pow(c1-a[0],2)+math.pow(c2-a[1],2)+math.pow(c3-a[2],2)))

# IGD = get_IGD(c, b)/len(c)
# print(IGD)
def levy_pdf(x) :
    return 1.0 / (x *np.sqrt(2 * np.pi)) * np.exp(-1.0 / (2*x))

def levy_flight( beta=1.5):
    step = []
    for i in range(100):

        sigma = np.power(np.math.gamma(1 + beta) * np.sin(np.pi * beta / 2) / np.math.gamma((1 + beta) / 2) * beta * np.power(2,(beta-1)/2),1/beta)
        #sigma = np.array([sigma])
        #print(sigma)
        u = np.random.normal(0, sigma)
        v = np.random.normal(0,1)
        step.append(u / np.power(np.abs(v), 1 / beta))
    return step
a = levy_flight()
print(a)


# def calculate_sigma(beta=1.5):
#     sigma = []  # 初始化一个空列表
#     sigma.append(np.power(np.math.gamma(1 + beta) * np.sin(np.pi * beta / 2) / np.math.gamma((1 + beta) / 2) * beta * np.power(2,(beta-1)/2,1/beta)))
#     return np.array(sigma)  # 将列表转换为 NumPy 数组
# beta = 1.5
# sigma_values = calculate_sigma(beta)
# print(sigma_values)
# def levy_flight_search(objective_function,bounds,n_iterations,n_pop):
#     best_solution = None
#     best_fitness = np.inf
#     pop_size = (n_pop,len(bounds))
#     pop = np.random.uniform(bounds[ : , 0], bounds[ :, 1],size=pop_size)
#     for i in range(n_iterations):
#         for j in range(n_pop):
# # 生成莱维飞行的步长
#             step = levy_flight
# # (#更新位置
#             candidate = pop[j] + step * (pop[j] - best_solution)
#             candidate = np.clip(candidate,bounds[ :, 0], bounds[ :,1]) #计算适应度
#             fitness = objective_function(candidate)#更新最优解
#             if fitness < best_fitness:
#                 best_solution = candidate
#                 best_fitness = fitness
#         print('Iteration {f}: Best F((})- {}'.format(i，best_solution，best_fitness))
#     return best_solution,best_fitness

# import numpy as np
# from scipy.stats import levy_stable
#
# def levy_flight(alpha=1.5, beta=0, scale=1, num_steps = 100):
#     """生成 Lévy 飞行的一系列步长。
#
#     Args:
#         alpha: α 稳定分布的特征指数 (0 < alpha <= 2)。
#         beta: α 稳定分布的倾斜参数 (-1 <= beta <= 1)。
#         scale: 缩放因子。
#         num_steps: 要生成的步长数量。
#
#     Returns:
#         numpy.ndarray: 包含 Lévy 飞行步长的数组。
#     """
#     steps = levy_stable.rvs(alpha, beta, scale=scale, size=num_steps)
#     return steps
#
# # 示例使用
# steps = levy_flight(alpha=1.5, beta=0, scale=1, num_steps=100)
# print(steps)