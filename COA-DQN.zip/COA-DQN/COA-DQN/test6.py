import numpy as np


def simulate_and_split(job_list, mac_list, time_list, wc_list, T_fail=80.0):
    """
    输入: 四个原始列表 + 故障时刻
    返回: (故障前四项列表), (故障后待重排四项列表)
    格式: (j_b, m_b, t_b, w_b), (j_a, m_a, t_a, w_a)
    """
    # 自动识别资源数
    num_m = int(max(mac_list) + 1)
    num_w = int(max(wc_list) + 1)

    m_finish = [0.0] * num_m
    w_finish = [0.0] * num_w
    j_finish = {}  # 内部记录工件前序，不作为返回

    # 定义8个结果列表
    jb, mb, tb, wb = [], [], [], []
    ja, ma, ta, wa = [], [], [], []

    for i in range(len(job_list)):
        j_id, m_id, dur, w_id = job_list[i], int(mac_list[i]), time_list[i], int(wc_list[i])
        w_idx = w_id - 1 if w_id > 0 else 0

        prev_j = j_finish.get(j_id, 0.0)
        start_t = max(m_finish[m_id], w_finish[w_idx], prev_j)
        end_t = start_t + dur

        if end_t <= T_fail:
            jb.append(j_id);
            mb.append(mac_list[i]);
            tb.append(dur);
            wb.append(wc_list[i])
        else:
            ja.append(j_id);
            ma.append(mac_list[i]);
            ta.append(dur);
            wa.append(wc_list[i])

        m_finish[m_id] = end_t
        w_finish[w_idx] = end_t
        j_finish[j_id] = end_t

    return (jb, mb, tb, wb), (ja, ma, ta, wa)


def merge_and_calc_ms(jb, mb, tb, wb, ja_new, ma_new, ta_new, wa_new):
    """
    将故障前的列表与重调度后的新列表合并
    返回: 合并后的 (job, mac, time, wc, final_makespan)
    """
    # 列表拼接
    total_j = jb + ja_new
    total_m = mb + ma_new
    total_t = tb + ta_new
    total_w = wb + wa_new

    # 二次仿真计算最终完工时间
    num_m = int(max(total_m) + 1)
    num_w = int(max(total_w) + 1)
    m_f, w_f, j_f = [0.0] * num_m, [0.0] * num_w, {}

    for i in range(len(total_j)):
        jid, mid, dur, wid = total_j[i], int(total_m[i]), total_t[i], int(total_w[i])
        widx = wid - 1 if wid > 0 else 0
        st = max(m_f[mid], w_f[widx], j_f.get(jid, 0.0))
        et = st + dur
        m_f[mid], w_f[widx], j_f[jid] = et, et, et

    final_makespan = max(j_f.values())
    return total_j, total_m, total_t, total_w, final_makespan

job_orig = [4.0, 18.0, 9.0, 16.0, 6.0, 12.0, 11.0, 15.0, 5.0, 11.0]
mac_orig = [0.0, 1.0, 2.0, 2.0, 6.0, 4.0, 3.0, 1.0, 6.0, 4.0]
time_orig = [25.0, 19.0, 17.0, 35.0, 14.0, 30.0, 12.0, 37.0, 12.0, 10.0]
wc_orig = [5.0, 2.0, 4.0, 4.0, 5.0, 1.0, 3.0, 3.0, 4.0, 5.0]

print(">>> 执行切分...")
# 1. 切分 (假设 80 时刻故障)
before, after = simulate_and_split(job_orig, mac_orig, time_orig, wc_orig, T_fail=30.0)
jb, mb, tb, wb = before  # 故障前部分
ja, ma, ta, wa = after   # 故障后待处理部分

print(f"   故障前工序数: {len(jb)}, 故障后工序数: {len(ja)}")

print("\n>>> 模拟完全重调度算法...")
# 2. 模拟算法处理 ja, ma, ta, wa 生成新序列 (ja_new, ma_new, ...)
# 这里模拟算法改变了 ja 的机器分配（全改到0号机）
ja_new = ja
ma_new = [0.0, 1,3,4,5]
ta_new = ta
wa_new = wa

print("\n>>> 执行最终合并...")
# 3. 合并
res = merge_and_calc_ms(jb, mb, tb, wb, ja_new, ma_new, ta_new, wa_new)
final_j, final_m, final_t, final_w, ms = res

# ----------------- 结果打印 -----------------
print("-" * 50)
print("串联测试结果 (全列表格式):")
print(f"合并后总工序列表: {final_j}")
print(f"合并后机器列表:   {final_m}")
print(f"最终完工时间:     {ms}")
print("-" * 50)