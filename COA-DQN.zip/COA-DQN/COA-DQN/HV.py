import math
import numpy as np
from pymoo.indicators.hv import HV
from pymoo.indicators.igd import IGD
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting

from multi_opt import mul_op
import copy
class HV_IGD:

    def compute_HV(self,answer):
        # PFture = [[340.0, 3027.0, 46855.25393701123], [433.0, 2772.0, 45335.580235695765], [363.0, 2792.0, 44948.22803708737],
        #           [563.0, 2849.0, 47696.63648835016], [374.0, 3056.0, 48635.67815419202], [396.0, 2932.0, 49238.23883630553],
        #           [561.0, 2893.0, 47604.546062749374], [507.0, 2919.0, 48339.02450616505], [442.0, 2927.0, 47918.20720026158],
        #           [532.0, 2857.0, 48643.9178194409], [431.0, 2875.0, 48464.17670131818], [424.0, 2908.0, 48600.36483455529],
        #           [514.0, 2876.0, 48322.43077035033], [422.0, 2975.0, 48890.33475778913], [467.0, 2854.0, 46315.01999493698],
        #           [347.0, 3002.0, 47156.251961502654], [453.0, 2892.0, 50429.251487667854], [360.0, 2926.0, 47433.98697409786],
        #           [447.0, 2894.0, 48190.55705999295], [544.0, 2783.0, 48949.25567228989], [359.0, 2852.0, 45747.49884070224],
        #           [363.0, 2842.0, 46417.20803187473], [480.0, 2787.0, 46306.43196743528], [380.0, 2850.0, 45306.6300082002],
        #           [433.0, 2815.0, 47843.50978765771], [485.0, 2829.0, 46177.88216056261], [419.0, 2835.0, 47045.835932354734],
        #           [465.0, 2830.0, 47810.69407732191], [427.0, 2736.0, 44278.706855052435], [376.0, 2871.0, 46451.33297784857],
        #           [404.0, 2867.0, 47870.35564078478], [423.0, 2833.0, 46164.770254214076], [407.0, 2845.0, 46000.941583490945],
        #           [339.0, 2953.0, 47786.72025053446], [414.0, 2769.0, 45388.080476185125], [397.0, 2817.0, 45332.63591039796],
        #           [390.0, 2828.0, 46376.0362514859], [564.0, 2869.0, 48975.06582977229], [380.0, 3006.0, 47423.26715015204],
        #           [500.0, 2877.0, 49777.41828114566], [492.0, 2887.0, 46964.648498642535], [415.0, 2996.0, 48432.363662083575],
        #           [437.0, 2916.0, 48024.69236087295], [422.0, 2944.0, 47588.95430466828], [490.0, 2934.0, 47682.77150978581],
        #           [363.0, 3167.0, 51221.46521478627], [442.0, 2788.0, 45147.860851999925], [394.0, 2955.0, 49176.58974307062],
        #           [403.0, 2930.0, 46606.366151058864], [429.0, 2807.0, 46458.86591573517], [365.0, 2920.0, 46617.72186297742],
        #           [482.0, 2781.0, 46065.303114656184], [392.0, 2807.0, 45364.41044333971]]
        # PFture = []
        PFture =copy.deepcopy(answer)
        # print(PFture)
        front, crowd, crowder = mul_op().dis(PFture)
        sig = front[0]
        b = np.array(PFture)[sig].tolist()
        # print("b", b)
        IGD = 0
        ob1, ob2, ob3 = [], [], []
        for i in range(len(PFture)):
            ob1.append(PFture[i][0])
            ob2.append(PFture[i][1])
            ob3.append(PFture[i][2])
        max1, min1, max2, min2, max3, min3 = max(ob1), min(ob1), max(ob2), min(ob2), max(ob3), min(ob3)
        maxob = [max1, max2, max3]
        minob = [min1, min2, min3]
        for i in range(len(PFture)):
            di = []
            for j in range(len(b)):
                diff = 0
                for ob in range(3):
                    if maxob[ob] == minob[ob]:
                        diff = 0
                    else:
                        fz1 = (b[j][ob] - minob[ob]) / (maxob[ob] - minob[ob])
                        # print(fz1)
                        fz2 = (PFture[i][ob] - minob[ob]) /(maxob[ob] - minob[ob])
                        # print(fz1,fz2)
                        diff = diff + pow(fz2 - fz1, 2)
                di.append(diff)

            d = min(di)
            # print(d)
            IGD = IGD + math.sqrt(d)
            # print(IGD)
        IGD = IGD / len(PFture)
        # print("IGD=", IGD)
        # print("b",b)

        print("IGD", IGD)


        # 归一化
        for i in range(len(PFture)):
            for j in range(3):
                if maxob[j] != minob[j]:
                    PFture[i][j] = (PFture[i][j] - minob[j]) / (maxob[j] - minob[j])
                else:
                    PFture[i][j] = 0
                    # fz2=(PFture[i][0]-min1)/(max1-min1)
        # print("PFture", PFture)

        ref = [1.01, 1.01, 1.01]
        # print(ref)
        # PFture.sort(key=lambda ele: ele[0], reverse=True)  # 按第一个元素降序排序
        # ind = np.zeros(len(PFture))

        # b = PFture.copy()
        all_point = np.array(PFture)
        # print("b",b)
        # b = [[0.1822845417236662, 0.09733124018838304, 0.13166852256690553], [0.27667578659370723, 0.09733124018838304, 0.15572084446575613], [0.11867305061559508, 0.09733124018838304, 0.09809876432570358], [0.1381668946648427, 0.09733124018838304, 0.12037990803830444], [0.2476060191518468, 0.09733124018838304, 0.14094829879049242], [0.2753077975376197, 0.09733124018838304, 0.1506087608876494], [0.30506155950752395, 0.09733124018838304, 0.16589596768557172], [0.3129274965800274, 0.09733124018838304, 0.16950958915536674], [0.1850205198358413, 0.09733124018838304, 0.12406535794172675], [0.2961696306429549, 0.09733124018838304, 0.1655075332143038], [0.24931600547195623, 0.09733124018838304, 0.1522154042175665], [0.24247606019151846, 0.09733124018838304, 0.14462084231073546], [0.1822845417236662, 0.09733124018838304, 0.12895092422165327], [0.39466484268125857, 0.09733124018838304, 0.20113910915669583], [0.3235294117647059, 0.09733124018838304, 0.17097785943609217], [0.2811217510259918, 0.09733124018838304, 0.1640593686951343], [0.18160054719562244, 0.09733124018838304, 0.12177946870159882], [0.2417920656634747, 0.09733124018838304, 0.14999974116810144], [0.3389192886456908, 0.09733124018838304, 0.18227981526730333], [0.19117647058823528, 0.09733124018838304, 0.13158402341957615], [0.1877564979480164, 0.09733124018838304, 0.12403166631023654], [0.1569767441860465, 0.09733124018838304, 0.12478558455221164], [0.1292749658002736, 0.09733124018838304, 0.1093496656909464], [0.28385772913816687, 0.09733124018838304, 0.15947197034548932], [0.27325581395348836, 0.09733124018838304, 0.16100564983584903], [0.3484952120383037, 0.09733124018838304, 0.18986241239867593], [0.2643638850889193, 0.09733124018838304, 0.15591746054931013], [0.253077975376197, 0.09733124018838304, 0.15673021569712617], [0.13303693570451436, 0.09733124018838304, 0.10894420489383877], [0.313953488372093, 0.09733124018838304, 0.17126388679809515], [0.23050615595075238, 0.09733124018838304, 0.14309388473787177], [0.30950752393980846, 0.09733124018838304, 0.16994844425430933], [0.22606019151846785, 0.09733124018838304, 0.14350910415992052], [0.10738714090287278, 0.09733124018838304, 0.10839214692744426], [0.17612859097127223, 0.09733124018838304, 0.12145809486318707], [0.31600547195622436, 0.09733124018838304, 0.1688298897428622], [0.19254445964432285, 0.09733124018838304, 0.1266281377583854], [0.09575923392612859, 0.09733124018838304, 0.10440622083839317], [0.28214774281805743, 0.09733124018838304, 0.1681605134035743], [0.35157318741450067, 0.09733124018838304, 0.18310634311840374], [0.29445964432284544, 0.09733124018838304, 0.16517316880170832], [0.2246922024623803, 0.09733124018838304, 0.1432528834729256], [0.09952120383036936, 0.09733124018838304, 0.09949477135999003], [0.24829001367989056, 0.09733124018838304, 0.15188443205450988], [0.32558139534883723, 0.09733124018838304, 0.16986446786125806], [0.3803009575923393, 0.09733124018838304, 0.19142181623678026], [0.2055403556771546, 0.09733124018838304, 0.13795985131802782], [0.2417920656634747, 0.09733124018838304, 0.15008762151328428], [0.28761969904240764, 0.09733124018838304, 0.15870490321160835], [0.1771545827633379, 0.09733124018838304, 0.12435222661101844], [0.15321477428180574, 0.0, 0.05577518473831111], [0.20109439124487005, 0.0, 0.06445166779184282], [0.05984952120383037, 0.0, 0.02615147100702207], [0.23290013679890562, 0.0, 0.0863702137552566], [0.2274281805745554, 0.0, 0.08191435681554686], [0.21272229822161423, 0.0, 0.07979268502615716], [0.08002735978112176, 0.0, 0.032132502198630154], [0.20622435020519836, 0.0, 0.07718693904083677], [0.11491108071135431, 0.0, 0.04616811520339335], [0.10601915184678523, 0.0, 0.03926159261908763], [0.2759917920656635, 0.0, 0.09934243117718951], [0.24623803009575923, 0.0, 0.08578915874297234], [0.265389876880985, 0.0, 0.09081935541701214], [0.1511627906976744, 0.0, 0.04475128855161757], [0.19767441860465115, 0.0, 0.06778802709878427], [0.13885088919288646, 0.0, 0.05273702334972507], [0.25444596443228457, 0.0, 0.0978020564431871], [0.146374829001368, 0.0, 0.058000046151429334], [0.20075239398084815, 0.0, 0.07602121466130778], [0.2705198358413133, 0.0, 0.09569785272150014], [0.09644322845417237, 0.0, 0.0368669752939671], [0.20348837209302326, 0.0, 0.07696330655169144], [0.1378248974008208, 0.0, 0.05618457071696784], [0.2075923392612859, 0.0, 0.0688340148286711], [0.18194254445964433, 0.0, 0.06910385631222517], [0.25239398084815323, 0.0, 0.08516586784430041], [0.22606019151846785, 0.0, 0.08146931505074184], [0.23153214774281805, 0.0, 0.08455169854690106], [0.10704514363885088, 0.0, 0.040945633700709305], [0.24350205198358413, 0.0, 0.08969906832513923], [0.028727770177838577, 0.0, 0.021357419180201103], [0.15629274965800274, 0.0, 0.0551500377009435], [0.0899452804377565, 0.0, 0.039646764959092536], [0.2270861833105335, 0.0, 0.08179810877031046], [0.18844049247606018, 0.0, 0.06788884248689542], [0.11046511627906977, 0.0, 0.03608383494231809], [0.0, 0.0, 0.0], [0.05027359781121751, 0.0, 0.02464836237263168], [0.16415868673050615, 0.0, 0.049066186548280315], [0.24042407660738713, 0.0, 0.08578476913949587], [0.792407660738714, 0.8828492935635793, 0.7928351434464717], [0.7869357045143639, 0.9466248037676609, 0.8698465954469107], [0.9326265389876881, 0.9175824175824175, 0.8762999487891889], [0.902530779753762, 0.9707613814756672, 0.8998471717579498], [0.9103967168262654, 0.826530612244898, 0.7861449588957427], [0.8888508891928865, 0.9158163265306123, 0.8951162670322933], [0.7855677154582763, 0.8671507064364207, 0.8024216658958968], [0.9538303693570451, 0.9807692307692307, 0.9252287475197859], [1.0, 1.0, 1.0], [0.9952120383036935, 0.9073783359497645, 0.8863925592536372]]
        # b = np.array(b)
        hv_indicator = HV(ref_point=ref)
        hv_value = hv_indicator.do(all_point)

        # print("hv=", hv_value)
        return IGD, hv_value

# print(PF)
    def calculate_igd(self, my_solutions, all_solutions, normalize=True, min_vals=[0, 0, 0], max_vals=[6000, 12000, 250000]):
        my_solutions = np.array(my_solutions)

        # 2. 处理 all_solutions：合并所有子集为一个大的点集
        if isinstance(all_solutions, list) and len(all_solutions) > 0:
            # 如果是列表，且第一个元素是列表/数组，则可能是多个子集的列表
            if isinstance(all_solutions[0], (list, np.ndarray)):
                merged = np.vstack([np.array(sub) for sub in all_solutions])
            else:
                merged = np.array(all_solutions)
        else:
            merged = np.array(all_solutions)

        # 3. 从合并后的点集中提取 Pareto 前沿（第一前沿）作为参考
        nds = NonDominatedSorting()
        fronts = nds.do(merged, sort_by_objectives=True)
        ref_front = merged[fronts[0]]  # 第一前沿（非支配解）

        # 4. 可选归一化（基于合并后所有点的范围）
        if normalize:
            # 使用自定义或自动的 min/max
            if min_vals is None:
                # 合并所有点（包括你的解集）计算 min
                all_points = np.vstack([merged, my_solutions])
                min_vals = all_points.min(axis=0)
            else:
                min_vals = np.array(min_vals)

            if max_vals is None:
                all_points = np.vstack([merged, my_solutions])
                max_vals = all_points.max(axis=0)
            else:
                max_vals = np.array(max_vals)

            range_vals = max_vals - min_vals
            range_vals[range_vals == 0] = 1.0

            my_norm = (my_solutions - min_vals) / range_vals
            ref_norm = (ref_front - min_vals) / range_vals
        else:
            my_norm = my_solutions
            ref_norm = ref_front

        # 5. 计算 IGD
        igd_calculator = IGD(ref_norm)
        igd_value = igd_calculator.do(my_norm)

        return igd_value
    def hv(self, answer):

        # front, crowd, crowder = mul_op().dis(PFture)
        # sig = front[0]
        # b = np.array(PFture)[sig].tolist()
        # # print("b", b)
        # IGD = 0
        # ob1, ob2, ob3 = [], [], []
        # for i in range(len(PFture)):
        #     ob1.append(PFture[i][0])
        #     ob2.append(PFture[i][1])
        #     ob3.append(PFture[i][2])
        # max1, min1, max2, min2, max3, min3 = max(ob1), min(ob1), max(ob2), min(ob2), max(ob3), min(ob3)
        # maxob = [max1, max2, max3]
        # minob = [min1, min2, min3]
        # for i in range(len(PFture)):
        #     for j in range(3):
        #         if maxob[j] != minob[j]:
        #             PFture[i][j] = (PFture[i][j] - minob[j]) / (maxob[j] - minob[j])
        #         else:
        #             PFture[i][j] = 0
        # 小数据集：[1650, 6800, 105000]
        ref = [1.0, 1.0, 1.0]
        PFture = copy.deepcopy(answer)
        max_point = [1650, 6800, 105000]
        min_point = [0, 0, 0]

        max_point = np.array(max_point)  # 转换为numpy数组
        min_point = np.array(min_point)  # 转换为numpy数组
        all_point = np.array(PFture)
        normalized_points = (all_point - min_point) / (max_point - min_point)
        hv_indicator = HV(ref_point=ref)
        hv_value = hv_indicator.do(normalized_points)
        return hv_value

    def hv_reSchedule(self, answer):

        # front, crowd, crowder = mul_op().dis(PFture)
        # sig = front[0]
        # b = np.array(PFture)[sig].tolist()
        # # print("b", b)
        # IGD = 0
        # ob1, ob2, ob3 = [], [], []
        # for i in range(len(PFture)):
        #     ob1.append(PFture[i][0])
        #     ob2.append(PFture[i][1])
        #     ob3.append(PFture[i][2])
        # max1, min1, max2, min2, max3, min3 = max(ob1), min(ob1), max(ob2), min(ob2), max(ob3), min(ob3)
        # maxob = [max1, max2, max3]
        # minob = [min1, min2, min3]
        # for i in range(len(PFture)):
        #     for j in range(3):
        #         if maxob[j] != minob[j]:
        #             PFture[i][j] = (PFture[i][j] - minob[j]) / (maxob[j] - minob[j])
        #         else:
        #             PFture[i][j] = 0
        ref = [1.0, 1.0, 1.0, 1.0]
        PFture = copy.deepcopy(answer)
        max_point = [25000, 68000, 1050000, 800000]
        min_point = [0, 0, 0, 0]

        max_point = np.array(max_point)  # 转换为numpy数组
        min_point = np.array(min_point)  # 转换为numpy数组
        all_point = np.array(PFture)
        normalized_points = (all_point - min_point) / (max_point - min_point)
        hv_indicator = HV(ref_point=ref)
        hv_value = hv_indicator.do(normalized_points)
        return hv_value
    def igd_b(self, answer, b):
        PFture = copy.deepcopy(answer)
        # front, crowd, crowder = mul_op().dis(PFture)
        # sig = front[0]
        # b = np.array(PFture)[sig].tolist()
        # print("b", b)
        PF = copy.deepcopy(b)

        b = [[x * 0.95 for x in row] for row in PF]
        IGD = 0
        ob1, ob2, ob3 = [], [], []
        for i in range(len(PFture)):
            ob1.append(PFture[i][0])
            ob2.append(PFture[i][1])
            ob3.append(PFture[i][2])

        # for i in range(len(b)):
        #     ob1.append(b[i][0])
        #     ob2.append(b[i][1])
        #     ob3.append(b[i][2])
        max1, min1, max2, min2, max3, min3 = max(ob1), min(ob1)/2, max(ob2), min(ob2)/2, max(ob3), min(ob3)/2
        maxob = [max1, max2, max3]
        minob = [min1, min2, min3]
        for i in range(len(PFture)):
            di = []
            for j in range(len(b)):
                diff = 0
                for ob in range(3):
                    if maxob[ob] == minob[ob]:
                        diff = 0
                    else:
                        fz1 = (b[j][ob] - minob[ob]) / (maxob[ob] - minob[ob])
                        # print(fz1)
                        fz2 = (PFture[i][ob] - minob[ob]) /  (maxob[ob] - minob[ob])
                        # print(fz1,fz2)
                        diff = diff + pow(fz2 - fz1, 2)
                di.append(diff)

            d = min(di)
            # print(d)
            IGD = IGD + math.sqrt(d)
            # print(IGD)
        IGD = IGD / len(PFture)
        return IGD
    def igd_four(self, answer, b):
        PFture = copy.deepcopy(answer)
        # front, crowd, crowder = mul_op().dis(PFture)
        # sig = front[0]
        # b = np.array(PFture)[sig].tolist()
        # print("b", b)
        PF = copy.deepcopy(b)

        b = [[x * 0.95 for x in row] for row in PF]
        IGD = 0
        ob1, ob2, ob3, ob4= [], [], [], []
        for i in range(len(PFture)):
            ob1.append(PFture[i][0])
            ob2.append(PFture[i][1])
            ob3.append(PFture[i][2])
            ob4.append(PFture[i][3])

        # for i in range(len(b)):
        #     ob1.append(b[i][0])
        #     ob2.append(b[i][1])
        #     ob3.append(b[i][2])
        max1, min1, max2, min2, max3, min3, max4, min4= max(ob1), min(ob1)/2, max(ob2), min(ob2)/2, max(ob3), min(ob3)/2, max(ob4), min(ob4)/2
        maxob = [max1, max2, max3, max4]
        minob = [min1, min2, min3, min4]
        for i in range(len(PFture)):
            di = []
            for j in range(len(b)):
                diff = 0
                for ob in range(4):
                    if maxob[ob] == minob[ob]:
                        diff = 0
                    else:
                        fz1 = (b[j][ob] - minob[ob]) / (maxob[ob] - minob[ob])
                        # print(fz1)
                        fz2 = (PFture[i][ob] - minob[ob]) /  (maxob[ob] - minob[ob])
                        # print(fz1,fz2)
                        diff = diff + pow(fz2 - fz1, 2)
                di.append(diff)

            d = min(di)
            # print(d)
            IGD = IGD + math.sqrt(d)
            # print(IGD)
        IGD = IGD / len(PFture)
        return IGD
    def igd(self, answer):
        PFture = copy.deepcopy(answer)
        front, crowd, crowder = mul_op().dis(PFture)
        sig = front[0]
        b = np.array(PFture)[sig].tolist()
        # print("b", b)
        IGD = 0
        ob1, ob2, ob3 = [], [], []
        for i in range(len(PFture)):
            ob1.append(PFture[i][0])
            ob2.append(PFture[i][1])
            ob3.append(PFture[i][2])
        max1, min1, max2, min2, max3, min3 = max(ob1), min(ob1), max(ob2), min(ob2), max(ob3), min(ob3)
        maxob = [max1, max2, max3]
        minob = [min1, min2, min3]
        for i in range(len(PFture)):
            di = []
            for j in range(len(b)):
                diff = 0
                for ob in range(3):
                    if maxob[ob] == minob[ob]:
                        diff = 0
                    else:
                        fz1 = (b[j][ob] - minob[ob]) / (maxob[ob] - minob[ob])
                        # print(fz1)
                        fz2 = (PFture[i][ob] - minob[ob]) /  (maxob[ob] - minob[ob])
                        # print(fz1,fz2)
                        diff = diff + pow(fz2 - fz1, 2)
                di.append(diff)

            d = min(di)
            # print(d)
            IGD = IGD + math.sqrt(d)
            # print(IGD)
        IGD = IGD / len(PFture)
        return IGD

    def igd_improved(self, answer):
        """
        改进的IGD计算（使用向量化运算）

        参数:
        answer: 种群的所有解

        返回:
        igd_value: IGD值
        """
        PFture = copy.deepcopy(answer)

        # 1. 获取非支配前沿作为参考前沿
        front, crowd, crowder = mul_op().dis(PFture)
        sig = front[0]
        reference_front = np.array(PFture)[sig]  # 参考前沿

        # 2. 转换为numpy数组
        population = np.array(PFture)

        # 3. 使用固定边界归一化
        max_point = np.array([6000, 12000, 250000])
        min_point = np.array([0, 0, 0])

        normalized_pop = (population - min_point) / (max_point - min_point)
        normalized_ref = (reference_front - min_point) / (max_point - min_point)

        # 4. 计算IGD（向量化）
        IGD = 0
        for ref_point in normalized_ref:
            # 计算参考点到所有种群点的距离
            distances = np.sqrt(np.sum((normalized_pop - ref_point) ** 2, axis=1))
            min_dist = np.min(distances)
            IGD += min_dist

        IGD = IGD / len(normalized_ref)

        return IGD