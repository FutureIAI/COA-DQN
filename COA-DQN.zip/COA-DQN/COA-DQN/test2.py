import numpy as np
import pandas as pd
from collections import defaultdict

# -------------------------- 1. 初始化原始数据（完全保留你的数据，无修改） --------------------------
job_seq = np.array(
    [2, 2, 15, 17, 9, 5, 7, 4, 18, 3, 15, 16, 4, 14, 12, 16, 2, 6, 13, 8, 0, 18, 9, 16, 11, 7,
     2, 14, 12, 17, 3, 7, 3, 6, 11, 12, 11, 5, 6, 1, 18, 12, 16, 14, 7, 18, 5, 14, 12, 15, 11, 19,
     4, 10, 13, 7, 9, 3], dtype=int)

# 原始机器序列（数字规则：0→1号、1→2号、...、6→7号，无数字7）
machine_seq_orig = np.array(
    [4, 0, 1, 0, 2, 5, 3, 6, 4, 6, 2, 2, 5, 2, 3, 4, 2, 5, 6, 6, 2, 3, 5, 3,
     0, 6, 5, 6, 5, 3, 4, 6, 5, 5, 1, 2, 4, 1, 4, 2, 5, 2, 4, 2, 2, 6, 4, 4,
     0, 3, 4, 1, 4, 1, 4, 3, 0, 2])

worker_seq_orig = np.array(
    [5, 5, 2, 1, 3, 2, 1, 5, 1, 5, 1, 3, 2, 4, 3, 1, 3, 2, 5, 4, 3, 2, 3, 2,
     1, 4, 3, 4, 3, 2, 1, 5, 2, 3, 2, 1, 5, 3, 1, 4, 2, 3, 5, 1, 3, 5, 1, 3,
     5, 3, 5, 2, 5, 3, 1, 3, 1, 3])

machine_choices = [
    [[1, 3, 4, 5, 6, 7]],
    [[3, 5]],
    [[1, 2, 4, 5, 6], [1, 5, 7], [1, 2, 3, 4, 6, 7], [1, 6, 7]],
    [[2, 3, 6, 7], [1, 3, 4, 5], [2, 3, 6, 7], [2, 3, 4, 5, 6, 7]],
    [[1, 6, 7], [3, 6], [1, 3, 5, 6]],
    [[1, 2, 3, 4, 6, 7], [2, 3, 5], [1, 2, 3, 5, 6, 7]],
    [[3, 6, 7], [5, 6], [1, 3, 5]],
    [[3, 4, 6, 7], [2, 3, 7], [1, 2, 4, 5, 6, 7], [3, 4, 5, 6], [1, 2, 4, 5, 6]],
    [[1, 3, 7]],
    [[1, 3], [1, 2, 3, 4, 6, 7], [1, 2, 3, 4, 6, 7]],
    [[1, 2, 3, 4, 5]],
    [[1, 3, 4, 6, 7], [1, 2, 3, 4, 5, 7], [1, 4, 5, 6], [3, 4, 5, 6, 7]],
    [[4, 5], [1, 3, 5, 6], [3, 7], [1, 3, 4, 5, 6, 7], [1, 3, 4, 5, 7]],
    [[4, 5, 7], [5, 7]],
    [[1, 3, 4, 6], [1, 2, 3, 5, 7], [1, 3, 4, 5, 6, 7], [1, 2, 3, 4, 5, 6]],
    [[1, 2, 3, 6, 7], [1, 3, 4, 6], [1, 4, 5, 7]],
    [[1, 3], [2, 4, 5, 6], [1, 2, 3, 4, 5, 6], [2, 3, 5, 6, 7]],
    [[1, 3, 4], [1, 2, 4, 6, 7]],
    [[2, 3, 4, 5, 6, 7], [1, 2, 3, 4, 5, 7], [2, 3, 4, 5, 6, 7], [1, 3, 5, 7]],
    [[1, 2]],
]

proc_times = [
    [[25, 17, 42, 24, 27, 36]],
    [[14, 16]],
    [[39, 41, 15, 36, 30], [25, 25, 25], [49, 31, 31, 28, 34, 43], [37, 24, 43]],
    [[38, 19, 47, 43], [19, 13, 23, 17], [28, 32, 10, 42], [29, 19, 20, 45, 38, 43]],
    [[25, 38, 45], [29, 39], [23, 28, 32, 15]],
    [[42, 39, 32, 42, 13, 12], [23, 49, 38], [37, 37, 42, 17, 46, 39]],
    [[22, 38, 14], [30, 50], [28, 27, 14]],
    [[45, 48, 43, 42], [17, 38, 44], [40, 20, 46, 49, 42, 38], [42, 36, 23, 41], [41, 41, 24, 43, 45]],
    [[38, 35, 41]],
    [[42, 17], [17, 10, 26, 23, 46, 38], [35, 29, 18, 23, 42, 12]],
    [[21, 37, 34, 11, 36]],
    [[47, 43, 12, 19, 43], [43, 40, 42, 23, 10, 26], [44, 50, 47, 47], [18, 30, 27, 48, 21]],
    [[35, 30], [28, 42, 12, 50], [35, 10], [33, 11, 40, 14, 14, 33], [31, 20, 32, 28, 42]],
    [[33, 40, 19], [44, 27]],
    [[13, 23, 46, 45], [25, 22, 17, 29, 24], [15, 23, 21, 21, 31, 21], [18, 19, 46, 28, 26, 32]],
    [[39, 37, 30, 44, 43], [46, 37, 46, 38], [33, 12, 43, 13]],
    [[46, 35], [35, 36, 50, 39], [49, 33, 48, 28, 10, 44], [10, 22, 45, 40, 50]],
    [[35, 22, 12], [14, 20, 46, 27, 11]],
    [[19, 36, 37, 38, 46, 29], [27, 16, 18, 31, 33, 10], [47, 37, 14, 10, 16, 48], [41, 50, 36, 14]],
    [[42, 35]],
]

worker_choices = [
    [1, 2, 5],
    [2, 3, 4, 5],
    [1, 3, 4],
    [1, 2, 3],
    [1, 3, 5],
    [2, 3],
    [4, 5]
]

# -------------------------- 2. 核心功能：匹配你的业务机器编号映射（0→1号、6→7号） --------------------------
class FlexibleShopRescheduling:
    def __init__(self, job_seq, machine_seq_orig, worker_seq_orig, machine_choices, proc_times, worker_choices):
        self.job_seq = job_seq
        self.machine_seq_orig = machine_seq_orig  # 原始机器数字序列（0→1号、6→7号）
        self.worker_seq_orig = worker_seq_orig
        self.machine_choices = machine_choices
        self.proc_times = proc_times
        self.worker_choices = worker_choices
        self.original_schedule = None
        self.before_fault_schedule = None
        self.after_fault_schedule = None
        self.fault_machine_original = None  # 故障机器对应的原始数字（如：真实7号→原始6）
        self.fault_machine_real = None      # 故障机器真实编号（如：7号）
        self.fault_time_idx = None
        self.fault_time = None
        self.final_job_seq = None
        self.final_machine_seq = None       # 最终原始机器数字序列（无故障对应的原始数字）
        self.final_worker_seq = None
        # 故障前/后序列拆分
        self.before_fault_job = None
        self.before_fault_machine = None
        self.before_fault_worker = None
        self.after_fault_job = None
        self.after_fault_machine = None
        self.after_fault_worker = None

    def _calculate_original_completion_time(self):
        """计算原始排产，标注真实机器编号"""
        machine_status = defaultdict(int)
        worker_status = defaultdict(int)
        job_status = defaultdict(int)
        original_schedule = []

        for idx in range(len(self.job_seq)):
            job_id = self.job_seq[idx]
            machine_original = self.machine_seq_orig[idx]  # 原始数字
            machine_real = machine_original + 1            # 真实机器编号（原始n→真实n+1）
            worker_id = self.worker_seq_orig[idx]
            proc_time = self._get_proc_time(job_id, machine_real)  # 传入真实机器编号

            start_time = max(machine_status[machine_original], worker_status[worker_id], job_status[job_id])
            end_time = start_time + proc_time

            machine_status[machine_original] = end_time
            worker_status[worker_id] = end_time
            job_status[job_id] = end_time

            original_schedule.append({
                '工序索引': idx,
                '工件ID': job_id,
                '机器原始数字': machine_original,
                '机器真实编号': machine_real,
                '工人ID': worker_id,
                '加工时间': proc_time,
                '开始时间': start_time,
                '完工时间': end_time
            })

        self.original_schedule = pd.DataFrame(original_schedule)
        self.original_makespan = max(machine_status.values()) if machine_status else 0
        return self.original_schedule, self.original_makespan

    def _get_proc_time(self, job_id, machine_real):
        """根据工件ID和真实机器编号，查找加工时间"""
        for op_machine_list in self.machine_choices[job_id]:
            if machine_real in op_machine_list:
                machine_idx = op_machine_list.index(machine_real)
                for op_time_list in self.proc_times[job_id]:
                    if len(op_time_list) == len(op_machine_list):
                        return op_time_list[machine_idx]
        return 0

    def _filter_available_machines(self, job_id):
        """
        过滤故障机器：
        1.  先将故障原始数字转换为真实编号（fault_machine_original→fault_machine_real）
        2.  过滤机器可选集中的真实故障机器编号
        3.  再将过滤后的真实编号转换为原始数字，用于后续分配
        """
        fault_machine_real = self.fault_machine_real
        available_machine_choices_original = []  # 存储过滤后的原始数字

        for op_machine_list in self.machine_choices[job_id]:
            # 第一步：过滤真实故障机器编号
            filtered_machine_real = [m for m in op_machine_list if m != fault_machine_real]
            if not filtered_machine_real:
                raise ValueError(f"工件{job_id}无可用机器（真实故障机器{fault_machine_real}号已占用所有可选机器）")
            # 第二步：将过滤后的真实编号转换为原始数字（真实n→原始n-1）
            filtered_machine_original = [m_real - 1 for m_real in filtered_machine_real]
            available_machine_choices_original.append(filtered_machine_original)

        return available_machine_choices_original

    def _get_machine_worker_map_idx(self, machine_original):
        """根据机器原始数字，映射工人可选集索引（匹配你的业务逻辑）"""
        # 机器原始数字→真实编号→工人集索引
        machine_real = machine_original + 1
        if machine_real == 1:  # 真实1号（原始0）
            return 0
        elif 2 <= machine_real <= 7:  # 真实2-7号（原始1-6）
            return machine_real - 1
        else:
            raise ValueError(f"机器原始数字{machine_original}（真实{machine_real}号）无对应的工人可选集映射")

    def _filter_available_workers(self, machine_original):
        """根据机器原始数字，获取可选工人"""
        map_idx = self._get_machine_worker_map_idx(machine_original)
        if map_idx >= len(self.worker_choices):
            machine_real = machine_original + 1
            raise ValueError(f"机器原始数字{machine_original}（真实{machine_real}号）映射后的工人集索引{map_idx}超出范围")
        return self.worker_choices[map_idx]

    def _select_best_worker(self, machine_original, job_id, worker_status):
        """为选定机器（原始数字）选择最优工人"""
        available_workers = self._filter_available_workers(machine_original)
        best_worker = None
        min_worker_available_time = float('inf')

        for worker_id in available_workers:
            worker_avail_time = worker_status.get(worker_id, 0)
            if worker_avail_time < min_worker_available_time:
                min_worker_available_time = worker_avail_time
                best_worker = worker_id

        if best_worker is None:
            machine_real = machine_original + 1
            raise ValueError(f"机器原始数字{machine_original}（真实{machine_real}号）的可选工人{available_workers}均不可用")
        return best_worker, min_worker_available_time

    def _reschedule_after_fault(self):
        """故障后重排产：过滤原始数字6（对应真实7号故障机器）"""
        fault_idx = self.fault_time_idx
        before_fault_df = self.original_schedule.iloc[:fault_idx+1] if fault_idx >=0 else None
        self.before_fault_schedule = before_fault_df

        # 记录故障发生时间
        if fault_idx >= 0 and not before_fault_df.empty:
            self.fault_time = before_fault_df.iloc[-1]['完工时间']
        else:
            self.fault_time = 0

        machine_status = defaultdict(int)
        worker_status = defaultdict(int)
        job_status = defaultdict(int)

        if fault_idx >= 0:
            for idx in range(fault_idx+1):
                row = self.original_schedule.iloc[idx]
                machine_original = row['机器原始数字']
                machine_status[machine_original] = row['完工时间']
                worker_status[row['工人ID']] = row['完工时间']
                job_status[row['工件ID']] = row['完工时间']
        # 移除故障机器（原始数字）的状态
        if self.fault_machine_original in machine_status:
            del machine_status[self.fault_machine_original]

        # 拆分故障前/后序列
        self.after_fault_job = self.job_seq[fault_idx+1:] if fault_idx >=0 else self.job_seq
        if fault_idx >= 0:
            self.before_fault_job = self.job_seq[:fault_idx+1]
            self.before_fault_machine = self.machine_seq_orig[:fault_idx+1]
            self.before_fault_worker = self.worker_seq_orig[:fault_idx+1]
        else:
            self.before_fault_job = np.array([])
            self.before_fault_machine = np.array([])
            self.before_fault_worker = np.array([])

        after_fault_schedule = []
        self.after_fault_machine = []
        self.after_fault_worker = []

        for seq_idx, job_id in enumerate(self.after_fault_job):
            original_idx = fault_idx + 1 + seq_idx
            available_machines_original = self._filter_available_machines(job_id)  # 已过滤故障原始数字

            # 选择最优机器（原始数字，无故障数字6）
            best_machine_original = None
            min_proc_time = float('inf')
            machine_proc_time_map = {}

            for op_machine_list in available_machines_original:
                for machine_original in op_machine_list:
                    # 二次校验：确保不选中故障机器原始数字
                    if machine_original == self.fault_machine_original:
                        continue
                    # 原始数字→真实编号，获取加工时间
                    machine_real = machine_original + 1
                    proc_time = self._get_proc_time(job_id, machine_real)
                    machine_proc_time_map[machine_original] = proc_time
                    if proc_time < min_proc_time:
                        min_proc_time = proc_time
                        best_machine_original = machine_original

            if best_machine_original is None:
                raise ValueError(f"工件{job_id}无可用机器（已过滤故障机器原始数字{self.fault_machine_original}）")

            # 选择最优工人
            best_worker, worker_avail_time = self._select_best_worker(best_machine_original, job_id, worker_status)
            proc_time = machine_proc_time_map[best_machine_original]

            # 计算时间
            machine_avail_time = machine_status.get(best_machine_original, 0)
            job_last_finish_time = job_status.get(job_id, 0)
            start_time = max(machine_avail_time, worker_avail_time, job_last_finish_time)
            end_time = start_time + proc_time

            # 更新状态
            machine_status[best_machine_original] = end_time
            worker_status[best_worker] = end_time
            job_status[job_id] = end_time

            # 记录详情
            machine_real = best_machine_original + 1
            after_fault_schedule.append({
                '原始工序索引': original_idx,
                '工件ID': job_id,
                '机器原始数字（无6）': best_machine_original,
                '机器真实编号（无7）': machine_real,
                '分配工人ID': best_worker,
                '加工时间': proc_time,
                '开始时间': start_time,
                '完工时间': end_time,
                '对应机器可选工人': self._filter_available_workers(best_machine_original),
                '备注': f'故障后重排产（已过滤原始数字{self.fault_machine_original}→真实{self.fault_machine_real}号机器）'
            })
            self.after_fault_machine.append(best_machine_original)
            self.after_fault_worker.append(best_worker)

        self.after_fault_schedule = pd.DataFrame(after_fault_schedule)
        self.after_fault_makespan = max(machine_status.values()) if machine_status else 0

        # 转换为numpy数组
        self.after_fault_machine = np.array(self.after_fault_machine)
        self.after_fault_worker = np.array(self.after_fault_worker)

        # 拼接最终序列
        if fault_idx >= 0:
            self.final_job_seq = np.concatenate([self.before_fault_job, self.after_fault_job])
            self.final_machine_seq = np.concatenate([self.before_fault_machine, self.after_fault_machine])
            self.final_worker_seq = np.concatenate([self.before_fault_worker, self.after_fault_worker])
        else:
            self.final_job_seq = self.after_fault_job
            self.final_machine_seq = self.after_fault_machine
            self.final_worker_seq = self.after_fault_worker

        # 强化校验：故障后序列中无故障机器原始数字
        if self.fault_machine_original in self.after_fault_machine:
            raise Exception(f"异常：故障后工序仍分配了故障机器原始数字{self.fault_machine_original}（对应真实{self.fault_machine_real}号）")
        else:
            print(f"✅ 校验通过：故障后工序中完全无原始数字{self.fault_machine_original}（对应真实{self.fault_machine_real}号故障机器）")
            print(f"📌 故障后序列中无6（真实7号），6已被成功过滤")

        return self.after_fault_schedule, self.after_fault_makespan

    def run_rescheduling(self, fault_machine_real, fault_time_idx):
        """
        主执行方法
        :param fault_machine_real: 故障机器真实编号（如7号）
        :param fault_time_idx: 故障发生在第index道工序之后
        :return: 最终序列+故障信息
        """
        if fault_time_idx >= len(self.job_seq):
            raise ValueError(f"故障工序索引超出范围，最大索引为{len(self.job_seq)-1}")

        # 真实故障机器编号→原始数字（真实n→原始n-1）
        self.fault_machine_real = fault_machine_real
        self.fault_machine_original = fault_machine_real - 1
        self.fault_time_idx = fault_time_idx

        # 1. 计算原始排产
        self._calculate_original_completion_time()

        # 2. 执行故障后重排产
        self._reschedule_after_fault()

        # 3. 打印详细信息（匹配你的业务逻辑）
        print("=" * 80)
        print("                    机器故障信息与重排产结果（匹配你的业务编号规则）")
        print("=" * 80)
        # 核心业务规则
        print(f"📢 业务机器编号规则：原始数字n = 真实机器编号n-1")
        print(f"📢 对应关系：0→1号、1→2号、2→3号、3→4号、4→5号、5→6号、6→7号")
        print(f"📢 故障机器：真实{self.fault_machine_real}号 → 原始数字{self.fault_machine_original}")
        print("=" * 40)
        # 故障信息
        print(f"🔴 故障机器真实编号：{self.fault_machine_real}号")
        print(f"🔴 故障机器原始数字：{self.fault_machine_original}")
        print(f"🔴 故障发生位置：第{self.fault_time_idx}道工序之后（工序索引从0开始）")
        print(f"🔴 故障发生时间：{self.fault_time}（对应前序工序完工时间）")
        print(f"🔴 原始总完工时间：{self.original_makespan}")
        print(f"🔴 重排产后总完工时间：{self.after_fault_makespan}")
        print("=" * 40)
        # 故障前序列信息
        print(f"📌 故障前工序（索引0~{self.fault_time_idx}）：")
        print(f"   故障前machine_seq包含原始数字{self.fault_machine_original}：{self.fault_machine_original in self.before_fault_machine}（保留原始分配，合法）")
        print(f"   故障前machine_seq：{self.before_fault_machine}")
        print("=" * 40)
        # 故障后序列信息
        print(f"📌 故障后工序（索引{self.fault_time_idx+1}~{len(self.final_job_seq)-1}）：")
        print(f"   故障后machine_seq包含原始数字{self.fault_machine_original}：{self.fault_machine_original in self.after_fault_machine}（已完全排除，符合要求）")
        print(f"   故障后machine_seq（无原始数字6，对应无真实7号）：{self.after_fault_machine}")
        print("=" * 40)
        # 最终序列信息
        print(f"📌 重排产后最终job_seq（工件序列）：")
        print(self.final_job_seq)
        print(f"📌 重排产后最终machine_seq（原始数字，无6）：")
        print(self.final_machine_seq)
        print(f"📌 重排产后最终worker_seq（工人序列）：")
        print(self.final_worker_seq)
        print("=" * 80)

        return (self.final_job_seq, self.final_machine_seq, self.final_worker_seq,
                {"fault_machine_real": self.fault_machine_real,
                 "fault_machine_original": self.fault_machine_original,
                 "fault_time_idx": self.fault_time_idx,
                 "fault_time": self.fault_time})

# -------------------------- 3. 调用示例（传入真实故障机器编号7，自动转换为原始数字6） --------------------------
if __name__ == "__main__":
    rescheduler = FlexibleShopRescheduling(
        job_seq=job_seq,
        machine_seq_orig=machine_seq_orig,
        worker_seq_orig=worker_seq_orig,
        machine_choices=machine_choices,
        proc_times=proc_times,
        worker_choices=worker_choices
    )

    # 故障参数：真实7号机器故障（自动转换为原始数字6），故障发生在第20道工序之后
    fault_machine_real = 5
    fault_time_idx = 20

    try:
        final_job, final_machine, final_worker, fault_info = rescheduler.run_rescheduling(
            fault_machine_real=fault_machine_real,
            fault_time_idx=fault_time_idx
        )


    except Exception as e:
        print(f"执行失败：{e}")