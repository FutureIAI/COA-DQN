import copy

class reSchedul():

    def split_given_array(self, split_index, fixed_array1):
        # 定义题目中给定的固定数组
        # fixed_array = [
        #     2, 2, 15, 17, 9, 5, 7, 4, 18, 3, 15, 16, 4, 14, 12, 16, 2, 6, 13, 8, 0, 18, 9, 16, 11, 7,
        #     2, 14, 12, 17, 3, 7, 3, 6, 11, 12, 11, 5, 6, 1, 18, 12, 16, 14, 7, 18, 5, 14, 12, 15, 11, 19,
        #     4, 10, 13, 7, 9, 3
        # ]
        fixed_array = copy.deepcopy(fixed_array1)
        # 可选：参数类型与范围校验，提升函数健壮性
        if not isinstance(split_index, int):
            raise TypeError("拆分序号必须为整数类型")
        # 处理负数序号（统一视为0，前半部分为空）
        if split_index < 0:
            split_index = 0
        # 处理超出数组长度的序号（后半部分为空）
        array_length = len(fixed_array)
        if split_index > array_length:
            split_index = array_length

        # 拆分数组：前半部分为[0:split_index]，后半部分为[split_index:]
        first_part = fixed_array[:split_index]
        second_part = fixed_array[split_index:]

        # 返回拆分后的两个部分（元组形式，便于接收）
        return first_part, second_part

    def modify_machine_choices(self, input_array1, machine_choices1):
        """
        根据一维数组修改机器可选集，支持整数和整数型浮点（如2.0）作为索引
        :param input_array1: 一维数组（元素为需要处理的索引x，支持int/整数型float）
        :param machine_choices1: 机器可选集（与题目中格式一致的嵌套列表）
        :return: 修改后的机器可选集（避免修改原列表，返回新列表副本）
        """
        # 先创建机器可选集的深拷贝，避免修改原始输入数据
        modified_machines = copy.deepcopy(machine_choices1)
        input_array = copy.deepcopy(input_array1)

        # 遍历一维数组中的每个数字x
        for x in input_array:
            try:
                # 新增：将x转换为整数（支持整数型浮点，如2.0 → 2；纯整数保持不变）
                if isinstance(x, float):
                    # 判断是否为整数型浮点（小数部分为0），非整数浮点直接跳过
                    if x.is_integer():
                        x = int(x)  # 转换为整数
                    else:
                        print(f"警告：元素{x}是非整数浮点，无法作为有效索引，跳过处理")
                        continue
                # 若x既不是int也不是float，直接跳过
                elif not isinstance(x, int):
                    print(f"警告：元素{x}不是整数或整数型浮点，跳过处理")
                    continue

                # 1. 校验x是否在machine_choices的有效索引范围内
                if x < 0 or x >= len(modified_machines):
                    print(f"警告：索引{x}超出机器可选集范围（0~{len(modified_machines) - 1}），跳过处理")
                    continue

                # 2. 校验modified_machines[x]是否为空列表（避免删除空列表的元素）
                if not modified_machines[x]:
                    print(f"警告：机器可选集索引{x}对应的列表为空，无法删除第一个元素，跳过处理")
                    continue

                # 3. 执行核心操作：删除modified_machines[x]的第一个元素（索引0）
                deleted_element = modified_machines[x].pop(0)
                # 可选：打印删除日志，便于调试
                # print(f"成功删除machine_choices[{x}][0]：{deleted_element}")

            except Exception as e:
                # 捕获其他意外异常，保证函数正常运行
                print(f"处理元素{x}时发生异常：{e}，跳过该元素")
                continue

        return modified_machines

    def update_both_constraints(self, finished_array, opt_m, opt_t):
        new_m = copy.deepcopy(opt_m)
        new_t = copy.deepcopy(opt_t)

        for x in finished_array:
            x_idx = int(x)
            # 确保 m 和 t 都有数据可以弹出
            if len(new_m[x_idx]) > 0 and len(new_t[x_idx]) > 0:
                new_m[x_idx].pop(0)
                new_t[x_idx].pop(0)
            else:
                print(f"数据不同步警告：工件 {x_idx} 无法同时在 m 和 t 集合中剔除")

        return new_m, new_t

    def delete_nested_elements_containing_x(self, x, machine_choices, proc_times):
        """
        深度删除machine_choices中所有包含x的嵌套子元素，同步删除proc_times对应层级元素
        :param x: 要匹配的目标数字（非索引）
        :param machine_choices: 机器可选集（嵌套列表）
        :param proc_times: 加工时间集（嵌套列表，与machine_choices结构完全一致）
        :return: (修改后的machine_choices, 修改后的proc_times)，不影响原始数据
        """
        def _remove_containing_item(nest_list, target, ref_list):
            """
            递归辅助函数：遍历嵌套列表，删除包含target的子元素，同步删除参考列表对应元素
            :param nest_list: 待处理的嵌套列表（machine_choices子列表）
            :param target: 目标数字x
            :param ref_list: 参考列表（proc_times对应子列表）
            :return: 无返回值，直接修改传入的副本列表
            """
            # 反向遍历嵌套列表，避免正向删除导致索引错乱（核心优化，保留你的逻辑）
            for idx in range(len(nest_list)-1, -1, -1):
                item = nest_list[idx]
                ref_item = ref_list[idx]

                if isinstance(item, list):
                    # 若当前元素是列表，先递归处理其子层级（确保深层嵌套同步删除）
                    _remove_containing_item(item, target, ref_item)
                    # 检查当前列表是否包含target（直接包含或子列表包含）
                    has_target = False
                    # 递归判断列表是否包含target（独立函数，逻辑清晰）
                    def _has_target(sub_list, t):
                        for i in sub_list:
                            if isinstance(i, list):
                                if _has_target(i, t):
                                    return True
                            elif i == t:
                                return True
                        return False
                    has_target = _has_target(item, target)

                    # 若当前子列表包含目标值，同步删除两个列表对应位置元素（核心需求）
                    if has_target:
                        nest_list.pop(idx)
                        ref_list.pop(idx)
                else:
                    # 若当前元素是数字，直接匹配目标值，同步删除
                    if item == target:
                        nest_list.pop(idx)
                        ref_list.pop(idx)

        # 深拷贝原始数据，避免修改外部传入的原始列表（关键保护，保留你的逻辑）
        modified_machines = copy.deepcopy(machine_choices)
        modified_procs = copy.deepcopy(proc_times)

        # 反向遍历一级索引，避免删除后索引错乱（优化点：原代码正向遍历，此处改为反向更健壮）
        for idx in range(len(modified_machines)-1, -1, -1):
            machine_sub = modified_machines[idx]
            proc_sub = modified_procs[idx]
            # 递归处理每个一级子列表，实现全层级同步删除
            _remove_containing_item(machine_sub, x, proc_sub)

        return modified_machines, modified_procs

    def count_inner_elements(self, nest_list1):
        """
        递归遍历嵌套列表，返回最内层元素（非列表类型）的总个数
        :param nest_list1: 任意嵌套深度的列表
        :return: 最内层元素数量
        """
        nest_list = copy.deepcopy(nest_list1)
        count = 0
        for item in nest_list:
            if isinstance(item, list):
                # 若当前元素是列表，递归统计其子列表的最内层元素
                count += self.count_inner_elements(item)
            else:
                # 若当前元素是非列表，即为最内层元素，计数+1
                count += 1
        return count

    # 核心函数：生成记录最内层元素数量的二维数组
    def generate_inner_count_2darray(self, nested_list1):
        """
        基于end_Machine_choices生成二维数组，记录每个二级列表对应的最内层元素数量
        二维数组结构：[[一级索引0的二级列表0内层数量, 一级索引0的二级列表1内层数量, ...], [...]]
        :param nested_list: end_Machine_choices（三级嵌套列表）
        :return: 二维计数数组
        """
        nested_list = copy.deepcopy(nested_list1)
        two_d_count_array = []
        # 遍历一级列表（对应end_Machine_choices的每个元素，二级列表集合）
        for first_level_item in nested_list:
            second_level_count = []
            # 遍历二级列表（对应每个一级元素下的子列表，即需要统计的对象）
            for second_level_item in first_level_item:
                # 统计当前二级列表的最内层元素数量
                inner_count = self.count_inner_elements(second_level_item)
                second_level_count.append(inner_count)
            # 将当前一级列表的统计结果加入二维数组
            two_d_count_array.append(second_level_count)
        return two_d_count_array

    def delete_elements_by_job(self, original_array1, job_array1):
        """
        按照job数组中的元素，逐个删除原始数组中的对应元素（job中有几个某元素，就删除几个）
        :param original_array: 原始待处理数组
        :param job_array: 参考删除数组（支持浮点型整数，如1.0、2.0）
        :return: 删除后的新数组
        """
        # 1. 深拷贝原始数组，避免修改原数组
        new_array = copy.deepcopy(original_array1)
        job_array = copy.deepcopy(job_array1)
        # 2. 处理job数组：转换为整数类型，并保留原始出现次数（不提前去重）
        job_int = []
        for item in job_array:
            # 兼容浮点型整数（如1.0→1），非整数浮点直接跳过（若有）
            if isinstance(item, float):
                if item.is_integer():
                    job_int.append(int(item))
                else:
                    continue
            elif isinstance(item, int):
                job_int.append(item)

        # 3. 遍历处理后的job数组，逐个删除原始数组中的对应元素（只删对应次数）
        for target in job_int:
            # 检查目标元素是否在新数组中，存在则删除第一个匹配项
            if target in new_array:
                new_array.remove(target)  # remove() 默认删除第一个出现的目标元素

        return new_array
# machine_choices = [
#     [[1, 3, 4, 5, 6, 7]],
#     [[3, 5]],
#     [[1, 2, 4, 5, 6], [1, 5, 7], [1, 2, 3, 4, 6, 7], [1, 6, 7]],
#     [[2, 3, 6, 7], [1, 3, 4, 5], [2, 3, 6, 7], [2, 3, 4, 5, 6, 7]],
#     [[1, 6, 7], [3, 6], [1, 3, 5, 6]],
#     [[1, 2, 3, 4, 6, 7], [2, 3, 5], [1, 2, 3, 5, 6, 7]],
#     [[3, 6, 7], [5, 6], [1, 3, 5]],
#     [[3, 4, 6, 7], [2, 3, 7], [1, 2, 4, 5, 6, 7], [3, 4, 5, 6], [1, 2, 4, 5, 6]],
#     [[1, 3, 7]],
#     [[1, 3], [1, 2, 3, 4, 6, 7], [1, 2, 3, 4, 6, 7]],
#     [[1, 2, 3, 4, 5]],
#     [[1, 3, 4, 6, 7], [1, 2, 3, 4, 5, 7], [1, 4, 5, 6], [3, 4, 5, 6, 7]],
#     [[4, 5], [1, 3, 5, 6], [3, 7], [1, 3, 4, 5, 6, 7], [1, 3, 4, 5, 7]],
#     [[4, 5, 7], [5, 7]],
#     [[1, 3, 4, 6], [1, 2, 3, 5, 7], [1, 3, 4, 5, 6, 7], [1, 2, 3, 4, 5, 6]],
#     [[1, 2, 3, 6, 7], [1, 3, 4, 6], [1, 4, 5, 7]],
#     [[1, 3], [2, 4, 5, 6], [1, 2, 3, 4, 5, 6], [2, 3, 5, 6, 7]],
#     [[1, 3, 4], [1, 2, 4, 6, 7]],
#     [[2, 3, 4, 5, 6, 7], [1, 2, 3, 4, 5, 7], [2, 3, 4, 5, 6, 7], [1, 3, 5, 7]],
#     [[1, 2]],
# ]
# proc_times = [
#     [[25, 17, 42, 24, 27, 36]],
#     [[14, 16]],
#     [[39, 41, 15, 36, 30], [25, 25, 25], [49, 31, 31, 28, 34, 43], [37, 24, 43]],
#     [[38, 19, 47, 43], [19, 13, 23, 17], [28, 32, 10, 42], [29, 19, 20, 45, 38, 43]],
#     [[25, 38, 45], [29, 39], [23, 28, 32, 15]],
#     [[42, 39, 32, 42, 13, 12], [23, 49, 38], [37, 37, 42, 17, 46, 39]],
#     [[22, 38, 14], [30, 50], [28, 27, 14]],
#     [[45, 48, 43, 42], [17, 38, 44], [40, 20, 46, 49, 42, 38], [42, 36, 23, 41], [41, 41, 24, 43, 45]],
#     [[38, 35, 41]],
#     [[42, 17], [17, 10, 26, 23, 46, 38], [35, 29, 18, 23, 42, 12]],
#     [[21, 37, 34, 11, 36]],
#     [[47, 43, 12, 19, 43], [43, 40, 42, 23, 10, 26], [44, 50, 47, 47], [18, 30, 27, 48, 21]],
#     [[35, 30], [28, 42, 12, 50], [35, 10], [33, 11, 40, 14, 14, 33], [31, 20, 32, 28, 42]],
#     [[33, 40, 19], [44, 27]],
#     [[13, 23, 46, 45], [25, 22, 17, 29, 24], [15, 23, 21, 21, 31, 21], [18, 19, 46, 28, 26, 32]],
#     [[39, 37, 30, 44, 43], [46, 37, 46, 38], [33, 12, 43, 13]],
#     [[46, 35], [35, 36, 50, 39], [49, 33, 48, 28, 10, 44], [10, 22, 45, 40, 50]],
#     [[35, 22, 12], [14, 20, 46, 27, 11]],
#     [[19, 36, 37, 38, 46, 29], [27, 16, 18, 31, 33, 10], [47, 37, 14, 10, 16, 48], [41, 50, 36, 14]],
#     [[42, 35]],
# ]
# f, e = split_given_array(5)
# reMachine_choices = modify_machine_choices(f,machine_choices)
# reProc_times = modify_machine_choices(f,proc_times)
# end_Machine_choices,end_Proc_times = delete_nested_elements_containing_x(7,reMachine_choices, reProc_times)
#
# print(f)
# print(e)
# print(reMachine_choices)
# print(reProc_times)
# print(end_Machine_choices)
# print(end_Proc_times)