import copy
import math

import numpy as np
from small_work import data_deal
import random
import matplotlib.pyplot as plt
from matplotlib.pylab import mpl
from matplotlib import patches as mpatches
from matplotlib.lines import Line2D


mpl.rcParams['font.sans-serif'] = ['SimHei']  # 添加这条可以让图形显示中文


class FJSP():
    def __init__(self, job_num, machine_num, parm_data, popsize):
        self.popsize = popsize  # 迭代次数
        self.job_num = job_num  # 工件数
        self.machine_num = machine_num  # 机器数
        # self.pi=pi  				#随机挑选机器的概率
        # all_num总工序数
        # Tmachine三维数组，工序可加工的机器号
        # Tmachinetime 三维数组工序在机器上的加工时间
        # tdx工序的可加工机器数
        self.Tmachine, self.Tmachinetime, self.tdx, self.work, self.M_dicr, self.tran_time, self.all_num, self.work_arr, self.work_num,self.efficiency = \
        parm_data[0], parm_data[1], parm_data[2], parm_data[3], parm_data[4], parm_data[5], parm_data[6], parm_data[7], \
        parm_data[8], parm_data[9]

    def axis(self):
        index = ['M2', 'M3', 'M4', 'M5', 'M6', 'M7', 'M1','M8', 'M9', 'M10', 'M11', 'M12',
                 'M13', 'M14', 'M15', 'M16', 'M17', 'M18', 'M19', 'M20']
        scale_ls, index_ls = [], []
        for i in range(self.machine_num):
            scale_ls.append(i + 1)
            index_ls.append(index[i])
        return index_ls, scale_ls  # 返回坐标轴信息，按照工件数返回，最多画20个机器，需要在后面添加

    def getind(self, list_T, job):
        ind = np.zeros((1, self.job_num))
        # print(job,len(job[0]))
        # print(self.job_num)
        # print(list_T)
        for i in range(len(job[0])):
            # print(i)
            if job[0][i] == list_T[0]:

                ind[0][list_T[0]] += 1
                # print(ind)
                # print("-----")

                if list_T[1] == ind[0][list_T[0]]:
                    break
        return i

    def gettran(self, job, machine):
        trantime = np.ones((1, job.shape[1]))
        index = []
        k = 0
        for i in range(self.job_num):
            for j in range(len(job[0])):
                if job[0][j] == i:
                    k += 1
                    index.append(j)
                    if k == 1:
                        trantime[0][j] = 0
                    else:
                        a = machine[0][j]  # 当前工序机器序号
                        b = machine[0][index[-2]]  # 该工件前一个工序机器编号
                        x = list(self.M_dicr[int(a)])[0] - 1
                        y = list(self.M_dicr[int(b)])[0] - 1
                        # print(x,y)
                        trantime[0][j] = self.tran_time[y][x]
            # 获取两个工序机器对应的车间

            index = []
            k = 0
        return trantime

    def generate_workpiece_schedule(self, random_numbers):
        """
        根据随机数的排序确定工件工序安排。
        (与您提供的原始函数功能一致, 增加了 workpieces_definition 参数)
        """
        workpieces_definition = copy.deepcopy(self.work)
        # 获取随机数从大到小排序后的索引（降序）
        sorted_indices = np.array(random_numbers).argsort()[::-1]
        # 根据排序后的索引重排工件工序
        scheduled_workpieces = [workpieces_definition[i] for i in sorted_indices]
        return scheduled_workpieces

    def _get_target_original_indices(self, target_schedule):
        """
        辅助函数：为目标调度中的每个工件，找到它在 workpieces_definition 中的原始索引。
        处理 workpieces_definition 中可能的重复工件。
        返回的列表 T 即为我们希望新的 random_numbers 经过 argsort()[::-1] 后得到的索引序列。
        """
        workpieces_definition = copy.deepcopy(self.work)
        n = len(workpieces_definition)
        if len(target_schedule) != n:
            raise ValueError("目标调度长度必须与工件定义长度一致。")

        target_original_indices_list = []
        # 追踪 workpieces_definition 中的索引是否已被使用
        used_original_indices_mask = [False] * n

        for item_in_target_schedule in target_schedule:
            found_match_for_current_item = False
            for original_idx in range(n):
                # 如果当前原始工件未被使用，并且与目标调度中的工件匹配
                if not used_original_indices_mask[original_idx] and \
                        workpieces_definition[original_idx] == item_in_target_schedule:
                    target_original_indices_list.append(original_idx)
                    used_original_indices_mask[original_idx] = True  # 标记为已使用
                    found_match_for_current_item = True
                    break  # 为当前目标工件找到匹配，跳到下一个目标工件
            if not found_match_for_current_item:
                raise ValueError(
                    f"无法为目标调度中的工件 '{item_in_target_schedule}' 找到匹配的原始工件，"
                    "或者所有实例都已被使用。请检查 target_schedule 与 workpieces_definition 的一致性。"
                )
        return target_original_indices_list

    def permute_random_numbers_for_schedule(self,
            target_schedule,
            source_random_numbers
    ):
        """
        找到 source_random_numbers 的一个排列，该排列通过 generate_workpiece_schedule
        函数可以生成 target_schedule。

        参数:
            target_schedule (list): 期望的工件加工顺序。
            workpieces_definition (list): 原始的工件定义列表。
            source_random_numbers (list): 包含原始随机数值的列表，其值将被重新排列。
                                         长度必须与 workpieces_definition 一致。

        返回:
            list: source_random_numbers 的一个排列。

        异常:
            ValueError: 如果找不到这样的排列 (例如，当 source_random_numbers 包含重复值，
                        并且这些重复值与 target_schedule 所需的排序因 argsort 的平局打破规则而冲突时)。
                        或者当列表长度不匹配或 target_schedule 无效时。
        """
        workpieces_definition = copy.deepcopy(self.work)
        n = len(workpieces_definition)
        if len(source_random_numbers) != n:
            raise ValueError("source_random_numbers 长度必须与 workpieces_definition 长度一致。")

        # 1. 计算 T_indices: target_schedule 中每个工序对应的 workpieces_definition 中的原始索引序列。
        #    T_indices[k] 是 target_schedule 中第 k 个工序在 workpieces_definition 中的原始索引。
        #    我们的目标是让 new_permuted_random_numbers.argsort()[::-1] == T_indices。
        T_indices = self._get_target_original_indices(target_schedule)

        # 2. 将 source_random_numbers 的值降序排序。
        #    这些是将要分配到新排列中的值。
        sorted_source_r_values = sorted(source_random_numbers, reverse=True)

        # 3. 构建新的随机数排列 (new_permuted_random_numbers)。
        #    sorted_source_r_values中的第k个值 (即第k大的原始随机数)
        #    应该被放置在 new_permuted_random_numbers[ T_indices[k] ] 的位置。
        new_permuted_random_numbers = [0.0] * n  # 初始化
        for k in range(n):
            new_permuted_random_numbers[T_indices[k]] = sorted_source_r_values[k]

        # 4. 验证：检查这个 new_permuted_random_numbers 是否真的能生成 target_schedule。
        #    这一步非常重要，特别是当 source_random_numbers 包含重复值时，
        #    因为 np.argsort()[::-1] 对于值相等的元素，会优先选择原始索引较大的那个。
        #    如果 T_indices 的顺序与这种平局打破规则冲突，则无法得到正确结果。

        # 通过重新生成调度并比较来进行最终验证。
        resulting_schedule_from_permutation = self.generate_workpiece_schedule(
            new_permuted_random_numbers,
        )

        if resulting_schedule_from_permutation != target_schedule:
            # 如果生成的调度与目标调度不符，说明 source_random_numbers 中的重复值
            # 与 T_indices 要求的顺序存在冲突。
            # 例如：如果 sorted_source_r_values[k] == sorted_source_r_values[k+1] (值相同),
            #       那么 new_permuted_random_numbers[T_indices[k]] == new_permuted_random_numbers[T_indices[k+1]].
            #       为了让 argsort()[::-1] 的输出中 T_indices[k] 在 T_indices[k+1] 之前,
            #       必须满足 T_indices[k] > T_indices[k+1].
            #       如果实际情况是 T_indices[k] < T_indices[k+1], 则排序结果会是 T_indices[k+1] 在前,
            #       导致与 target_schedule 不符。
            raise ValueError(
                "无法找到 source_random_numbers 的有效排列来生成 target_schedule。\n"
                "这可能是因为 source_random_numbers 包含重复值，这些重复值因 numpy.argsort 的平局打破规则 "
                "而与 target_schedule 所需的顺序冲突。\n"
                f"期望的索引顺序 (T_indices): {T_indices}\n"
                f"构建的排列随机数: {new_permuted_random_numbers}\n"
                f"由此排列生成的调度: {resulting_schedule_from_permutation}\n"
                f"期望的目标调度: {target_schedule}"
            )

        return new_permuted_random_numbers
    def creat_job(self):
        # print(self.Tmachinetime)
        work_F, work_tran, work_job, work_M, work_T = np.zeros((self.popsize, len(self.work))), np.zeros(
            (self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work))), np.zeros(
            (self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work)))
        job_init = np.zeros((self.popsize, len(self.work)))
        work_W = np.zeros((self.popsize, len(self.work)))
        for size in range(self.popsize):
            # len(self.work)工序数
            initial_a = np.random.rand(len(self.work))  # 通过本函数可以返回一个或一组服从“0~1”均匀分布的随机样本值。随机样本取值范围是[0,1)，不包括1
            job = self.generate_workpiece_schedule(initial_a)  # 将随机样本值由小到大排列，排列出其对应的索引 job是根据index_work改变的work的结果


            initial_a = self.permute_random_numbers_for_schedule(job, initial_a)
            job = np.array(job).reshape(1, len(self.work))
            # 将job一维数组转变成二维一行数据
            factor = np.zeros((1, self.all_num))
            machine = np.zeros((1, self.all_num))
            machine_time = np.zeros((1, self.all_num))

            # GLR
            # print(self.popsize)
            rate_G, rate_L, rate_R = 0, 0, 1
            # print("self.job_num",self.job_num)
            indx = np.zeros((1, self.job_num))
            print("轮次：", size)
            # print(self.Tmachinetime)
            if (size + 1) <= self.popsize * rate_G:  # 全局选择
                Time = np.zeros((1, self.machine_num))  # 机器时间轴
                T = np.zeros((1, self.machine_num))  # 临时时间轴
                for j in range(self.job_num):  # 工件

                    for z in range(len(job[0])):  # 工序

                        if job[0, z] == j:
                            # 选择最小时间的机器
                            min_index = 0
                            # 存机器号
                            min_mt = 0
                            for m in range(len(self.Tmachine[j][int(indx[0, j])])):
                                T[0][self.Tmachine[j][int(indx[0, j])][m] - 1] += self.Tmachinetime[j][int(indx[0, j])][
                                    m]
                                if min_index == 0:
                                    min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
                                    min_mt = m
                                elif min_index > T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]:
                                    min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
                                    min_mt = m
                                else:
                                    min_index = min_index
                            # 找到当前最小时间机器的索引
                            min_wh = np.argwhere(T[0] == min_index)

                            # 选择对应的机器并更新
                            machine[0, z] = self.Tmachine[j][int(indx[0, j])][min_mt] - 1
                            # 更新当前工序的因子。
                            factor[0, z] = self.M_dicr[machine[0, z]][0]
                            # 更新机器时间
                            machine_time[0, z] = self.Tmachinetime[j][int(indx[0, j])][min_mt]
                            # 更新机器的总时间
                            Time[0][min_wh[0, 0]] = T[0][min_wh[0, 0]]
                            # 将当前的时间更新到T数组中。
                            T = np.copy(Time)
                            # 更新工件的索引
                            indx[0, j] = indx[0, j] + 1
            # print("机器排序",machine)


            elif ((size + 1) > self.popsize * rate_G) and ((size + 1) <= self.popsize * (rate_G + rate_L)):
                for j in range(self.job_num):
                    Time = np.zeros((1, self.machine_num))  # 时间轴
                    T = np.zeros((1, self.machine_num))  # 临时时间轴
                    for z in range(len(job[0])):
                        if job[0, z] == j:
                            min_index = 0
                            min_mt = 0
                            for m in range(len(self.Tmachine[j][int(indx[0, j])])):
                                T[0][self.Tmachine[j][int(indx[0, j])][m] - 1] += self.Tmachinetime[j][int(indx[0, j])][
                                    m]
                                if min_index == 0:
                                    min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
                                    min_mt = m
                                elif min_index > T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]:
                                    min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
                                    min_mt = m
                                else:
                                    min_index = min_index

                            min_wh = np.argwhere(T[0] == min_index)
                            # print("索引",min_wh)
                            # print("T", T)
                            # print("min_index", min_index)
                            # min_wh = np.argwhere(T[0] == min_index)
                            # print("Tmachine[j][int(indx[0,j])] = ", len(self.Tmachine[j][int(indx[0, j])]))
                            # print("min_mt =", min_mt)
                            # print("min_wh =", min_wh)
                            # print(j)
                            # print("indx =", int(indx[0, j]))
                            machine[0, z] = self.Tmachine[j][int(indx[0, j])][min_mt] - 1
                            factor[0, z] = self.M_dicr[machine[0, z]][0]
                            machine_time[0, z] = self.Tmachinetime[j][int(indx[0, j])][min_mt]
                            Time[0][min_wh[0, 0]] = T[0][min_wh[0, 0]]
                            T = np.copy(Time)
                            indx[0, j] = indx[0, j] + 1
            # print("机器排序2", machine)
            else:
                for j in range(self.job_num):
                    for z in range(len(job[0])):
                        if job[0, z] == j:
                            x = self.Tmachine[j][int(indx[0, j])]
                            y = random.choice(x)
                            machine[0][z] = y - 1
                            factor[0][z] = self.M_dicr[machine[0, z]][0]
                            for min_mt in range(len(self.Tmachine[j][int(indx[0, j])])):
                                if self.Tmachine[j][int(indx[0, j])][min_mt] == y:
                                    machine_time[0][z] = self.Tmachinetime[j][int(indx[0, j])][min_mt]
                            indx[0, j] = indx[0, j] + 1
            # print("机器排序3", machine)
            # print(job)
            # print(machine)
            # print(machine_time)
            # print(factor)
            trantime = self.gettran(job, machine)
            index = []
            k = 0
            for i in range(self.job_num):

                for j in range(len(job[0])):
                    if job[0][j] == i:
                        k += 1
                        index.append(j)
                        if k == 1:
                            trantime[0][j] = 0
                        else:
                            a = machine[0][j]  # 当前工序机器序号
                            b = machine[0][index[-2]]  # 该工件前一个工序机器编号
                            x = list(self.M_dicr[int(a)])[0] - 1
                            y = list(self.M_dicr[int(b)])[0] - 1
                            # print(x,y)

                            trantime[0][j] = self.tran_time[y][x]
                # 获取两个工序机器对应的车间

                index = []
                k = 0
            work_F[size], work_tran[size], work_job[size], work_M[size], work_T[size] = factor[0], trantime[0], job[0], \
                                                                                        machine[0], machine_time[0]
            job_init[size] = initial_a
        # work_job,每个工序对应的工件
        # work_M，每个工序加工的机器
        # work_T，每个工序加工的时间
        # job，每个工序所属的工件
        # machine，每个工序加工的机器
        # print("Tmachine",self.Tmachine)
        # print("HFUJ", work_job[size])
        # print("work_M", work_M[size])
        # print("work_T",work_T[size])
        # print("job_init",job_init[size])
        # print("machine",machine)
        # print("trantime",trantime)
        # WS根据MS生成人员编码
        WC = np.zeros((self.popsize, work_job.shape[1]))
        for i in range(self.popsize):
            for j in range(work_job.shape[1]):
                if j == 1:
                    WC[i][j] = np.random.choice(self.work_arr[int(work_M[i][j])])
                else:
                    WC[i][j] = self.select_different_number1(self.work_arr[int(work_M[i][j])], WC[i][j - 1])  # 连续不相同
        # print("WC",WC)
        return work_job, work_M, work_T, work_tran, work_F, job_init, WC
    def creat_job1(self):
        # print(self.Tmachinetime)
        work_F, work_tran, work_job, work_M, work_T = np.zeros((self.popsize, len(self.work))), np.zeros(
            (self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work))), np.zeros(
            (self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work)))
        job_init = np.zeros((self.popsize, len(self.work)))
        work_W = np.zeros((self.popsize, len(self.work)))
        for size in range(self.popsize):
            # len(self.work)工序数
            initial_a = np.random.rand(len(self.work))  # 通过本函数可以返回一个或一组服从“0~1”均匀分布的随机样本值。随机样本取值范围是[0,1)，不包括1
            job = self.generate_workpiece_schedule(initial_a)  # 将随机样本值由小到大排列，排列出其对应的索引 job是根据index_work改变的work的结果


            initial_a = self.permute_random_numbers_for_schedule(job, initial_a)
            job = np.array(job).reshape(1, len(self.work))
            # 将job一维数组转变成二维一行数据
            factor = np.zeros((1, self.all_num))
            machine = np.zeros((1, self.all_num))
            machine_time = np.zeros((1, self.all_num))

            # GLR
            # print(self.popsize)
            rate_G, rate_L, rate_R = 0.2, 0.2, 0.6
            # print("self.job_num",self.job_num)
            indx = np.zeros((1, self.job_num))
            print("轮次：", size)
            # print(self.Tmachinetime)
            if (size + 1) <= self.popsize * rate_G:  # 全局选择
                Time = np.zeros((1, self.machine_num))  # 机器时间轴
                T = np.zeros((1, self.machine_num))  # 临时时间轴
                for j in range(self.job_num):  # 工件

                    for z in range(len(job[0])):  # 工序

                        if job[0, z] == j:
                            # 选择最小时间的机器
                            min_index = 0
                            # 存机器号
                            min_mt = 0
                            for m in range(len(self.Tmachine[j][int(indx[0, j])])):
                                T[0][self.Tmachine[j][int(indx[0, j])][m] - 1] += self.Tmachinetime[j][int(indx[0, j])][
                                    m]
                                if min_index == 0:
                                    min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
                                    min_mt = m
                                elif min_index > T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]:
                                    min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
                                    min_mt = m
                                else:
                                    min_index = min_index
                            # 找到当前最小时间机器的索引
                            min_wh = np.argwhere(T[0] == min_index)

                            # 选择对应的机器并更新
                            machine[0, z] = self.Tmachine[j][int(indx[0, j])][min_mt] - 1
                            # 更新当前工序的因子。
                            factor[0, z] = self.M_dicr[machine[0, z]][0]
                            # 更新机器时间
                            machine_time[0, z] = self.Tmachinetime[j][int(indx[0, j])][min_mt]
                            # 更新机器的总时间
                            Time[0][min_wh[0, 0]] = T[0][min_wh[0, 0]]
                            # 将当前的时间更新到T数组中。
                            T = np.copy(Time)
                            # 更新工件的索引
                            indx[0, j] = indx[0, j] + 1
            # print("机器排序",machine)


            elif ((size + 1) > self.popsize * rate_G) and ((size + 1) <= self.popsize * (rate_G + rate_L)):
                for j in range(self.job_num):
                    Time = np.zeros((1, self.machine_num))  # 时间轴
                    T = np.zeros((1, self.machine_num))  # 临时时间轴
                    for z in range(len(job[0])):
                        if job[0, z] == j:
                            min_index = 0
                            min_mt = 0
                            for m in range(len(self.Tmachine[j][int(indx[0, j])])):
                                T[0][self.Tmachine[j][int(indx[0, j])][m] - 1] += self.Tmachinetime[j][int(indx[0, j])][
                                    m]
                                if min_index == 0:
                                    min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
                                    min_mt = m
                                elif min_index > T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]:
                                    min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
                                    min_mt = m
                                else:
                                    min_index = min_index

                            min_wh = np.argwhere(T[0] == min_index)
                            # print("索引",min_wh)
                            # print("T", T)
                            # print("min_index", min_index)
                            # min_wh = np.argwhere(T[0] == min_index)
                            # print("Tmachine[j][int(indx[0,j])] = ", len(self.Tmachine[j][int(indx[0, j])]))
                            # print("min_mt =", min_mt)
                            # print("min_wh =", min_wh)
                            # print(j)
                            # print("indx =", int(indx[0, j]))
                            machine[0, z] = self.Tmachine[j][int(indx[0, j])][min_mt] - 1
                            factor[0, z] = self.M_dicr[machine[0, z]][0]
                            machine_time[0, z] = self.Tmachinetime[j][int(indx[0, j])][min_mt]
                            Time[0][min_wh[0, 0]] = T[0][min_wh[0, 0]]
                            T = np.copy(Time)
                            indx[0, j] = indx[0, j] + 1
            # print("机器排序2", machine)
            else:
                for j in range(self.job_num):
                    for z in range(len(job[0])):
                        if job[0, z] == j:
                            x = self.Tmachine[j][int(indx[0, j])]
                            y = random.choice(x)
                            machine[0][z] = y - 1
                            factor[0][z] = self.M_dicr[machine[0, z]][0]
                            for min_mt in range(len(self.Tmachine[j][int(indx[0, j])])):
                                if self.Tmachine[j][int(indx[0, j])][min_mt] == y:
                                    machine_time[0][z] = self.Tmachinetime[j][int(indx[0, j])][min_mt]
                            indx[0, j] = indx[0, j] + 1
            # print("机器排序3", machine)
            # print(job)
            # print(machine)
            # print(machine_time)
            # print(factor)
            trantime = self.gettran(job, machine)
            index = []
            k = 0
            for i in range(self.job_num):

                for j in range(len(job[0])):
                    if job[0][j] == i:
                        k += 1
                        index.append(j)
                        if k == 1:
                            trantime[0][j] = 0
                        else:
                            a = machine[0][j]  # 当前工序机器序号
                            b = machine[0][index[-2]]  # 该工件前一个工序机器编号
                            x = list(self.M_dicr[int(a)])[0] - 1
                            y = list(self.M_dicr[int(b)])[0] - 1
                            # print(x,y)

                            trantime[0][j] = self.tran_time[y][x]
                # 获取两个工序机器对应的车间

                index = []
                k = 0
            work_F[size], work_tran[size], work_job[size], work_M[size], work_T[size] = factor[0], trantime[0], job[0], \
                                                                                        machine[0], machine_time[0]
            job_init[size] = initial_a
        # work_job,每个工序对应的工件
        # work_M，每个工序加工的机器
        # work_T，每个工序加工的时间
        # job，每个工序所属的工件
        # machine，每个工序加工的机器
        # print("Tmachine",self.Tmachine)
        # print("HFUJ", work_job[size])
        # print("work_M", work_M[size])
        # print("work_T",work_T[size])
        # print("job_init",job_init[size])
        # print("machine",machine)
        # print("trantime",trantime)
        # WS根据MS生成人员编码
        WC = np.zeros((self.popsize, work_job.shape[1]))
        for i in range(self.popsize):
            for j in range(work_job.shape[1]):
                if j == 1:
                    WC[i][j] = np.random.choice(self.work_arr[int(work_M[i][j])])
                else:
                    WC[i][j] = self.select_different_number1(self.work_arr[int(work_M[i][j])], WC[i][j - 1])  # 连续不相同
        # print("WC",WC)
        return work_job, work_M, work_T, work_tran, work_F, job_init, WC

    def select_os(self):
        processing_order = {1: 4, 2: 4, 3: 4, 6: 10, 8: 10, 9: 10, 12: 16, 13: 16, 14: 16, 15: 16, 18: 19}
        # 工件列表，包含各工件及其工序数量
        workpieces = self.work

        # 构建依赖图和入度字典
        dependency_graph = {i: [] for i in set(workpieces)}
        in_degree = {i: 0 for i in set(workpieces)}

        for pre, post in processing_order.items():
            dependency_graph[pre].append(post)
            in_degree[post] += 1

        # 存储每个时刻可加工的工件
        available_workpieces_at_each_time = []
        # 存储最终加工顺序
        final_order = []

        # 记录每个工件剩余的工序数量
        remaining_operations = {i: workpieces.count(i) for i in set(workpieces)}

        while any(remaining_operations.values()):
            # 找出当前入度为 0 且还有工序未完成的工件
            available_workpieces = [i for i in in_degree if in_degree[i] == 0 and remaining_operations[i] > 0]
            if not available_workpieces:
                print("出现死锁，无法继续安排加工顺序。")
                break

            available_workpieces_at_each_time.append(available_workpieces)
            # 随机选择一个工件
            chosen_workpiece = random.choice(available_workpieces)
            final_order.append(chosen_workpiece)
            # 减少该工件的剩余工序数量
            remaining_operations[chosen_workpiece] -= 1
            # 如果该工件所有工序完成，更新其后续工件的入度
            if remaining_operations[chosen_workpiece] == 0:
                for next_workpiece in dependency_graph[chosen_workpiece]:
                    in_degree[next_workpiece] -= 1
        return final_order

    # # 输出每个时刻可加工的工件
    # 		# for i, available in enumerate(available_workpieces_at_each_time):
    # 		# 	print(f"时刻 {i + 1} 可加工的工件: {available}")
    # 		#
    # 		# # 输出最终加工顺序
    # 		# print("最终加工顺序:", final_order)

        # def creat_asjob(self):
        #     work_F, work_tran, work_job, work_M, work_T = np.zeros((self.popsize, len(self.work))), np.zeros(
        #         (self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work))), np.zeros(
        #         (self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work)))
        #     job_init = np.zeros((self.popsize, len(self.work)))
        #     machine_inits = np.zeros((self.popsize, len(self.work)))
        #     worker_inits = np.zeros((self.popsize, len(self.work)))
        #     work_W = np.zeros((self.popsize, len(self.work)))
        #     for size in range(self.popsize):
        #         # len(self.work)工序数
        #         initial_a = np.random.rand(len(self.work))  # 通过本函数可以返回一个或一组服从“0~1”均匀分布的随机样本值。随机样本取值范围是[0,1)，不包括1
        #         machine_init = np.random.rand(len(self.work))
        #         worker_init = np.random.rand(len(self.work))
        #         # index_work = np.array(initial_a).argsort()  # 将随机样本值由小到大排列，排列出其对应的索引
        #         # job = []
        #         # # print("work",self.work)
        #         # for i in range(len(self.work)):
        #         # 	job.append(self.work[index_work[i]])
        #         processing_order = {1: 4, 2: 4, 3: 4, 6: 10, 8: 10, 9: 10, 12: 16, 13: 16, 14: 16, 15: 16, 18: 19}
        #         job = self.select_os()
        #         self.is_sequence_valid(job,processing_order)
        #         # job是根据index_work改变的work的结果
        #         # print("job", job)
        #         job = np.array(job).reshape(1, len(self.work))
        #         # 将job一维数组转变成二维一行数据
        #         factor = np.zeros((1, self.all_num))
        #         machine = np.zeros((1, self.all_num))
        #         machine_time = np.zeros((1, self.all_num))
        #
        #         # GLR
        #         # print(self.popsize)
        #         rate_G, rate_L, rate_R = 0.0, 0.0, 1
        #         # print("self.job_num",self.job_num)
        #         indx = np.zeros((1, self.job_num))
        #         print("轮次：", size)
        #         # print(self.Tmachinetime)
        #         if (size + 1) <= self.popsize * rate_G:  # 全局选择
        #             Time = np.zeros((1, self.machine_num))  # 机器时间轴
        #             T = np.zeros((1, self.machine_num))  # 临时时间轴
        #             for j in range(self.job_num):  # 工件
        #
        #                 for z in range(len(job[0])):  # 工序
        #
        #                     if job[0, z] == j:
        #                         # 选择最小时间的机器
        #                         min_index = 0
        #                         # 存机器号
        #                         min_mt = 0
        #                         for m in range(len(self.Tmachine[j][int(indx[0, j])])):
        #                             T[0][self.Tmachine[j][int(indx[0, j])][m] - 1] += self.Tmachinetime[j][int(indx[0, j])][
        #                                 m]
        #                             if min_index == 0:
        #                                 min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
        #                                 min_mt = m
        #                             elif min_index > T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]:
        #                                 min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
        #                                 min_mt = m
        #                             else:
        #                                 min_index = min_index
        #                         # 找到当前最小时间机器的索引
        #                         min_wh = np.argwhere(T[0] == min_index)
        #
        #                         # 选择对应的机器并更新
        #                         machine[0, z] = self.Tmachine[j][int(indx[0, j])][min_mt] - 1
        #                         # 更新当前工序的因子。
        #                         factor[0, z] = self.M_dicr[machine[0, z]][0]
        #                         # 更新机器时间
        #                         machine_time[0, z] = self.Tmachinetime[j][int(indx[0, j])][min_mt]
        #                         # 更新机器的总时间
        #                         Time[0][min_wh[0, 0]] = T[0][min_wh[0, 0]]
        #                         # 将当前的时间更新到T数组中。
        #                         T = np.copy(Time)
        #                         # 更新工件的索引
        #                         indx[0, j] = indx[0, j] + 1
        #         # print("机器排序",machine)
        #
        #
        #         elif ((size + 1) > self.popsize * rate_G) and ((size + 1) <= self.popsize * (rate_G + rate_L)):
        #             for j in range(self.job_num):
        #                 Time = np.zeros((1, self.machine_num))  # 时间轴
        #                 T = np.zeros((1, self.machine_num))  # 临时时间轴
        #                 for z in range(len(job[0])):
        #                     if job[0, z] == j:
        #                         min_index = 0
        #                         min_mt = 0
        #                         for m in range(len(self.Tmachine[j][int(indx[0, j])])):
        #                             T[0][self.Tmachine[j][int(indx[0, j])][m] - 1] += self.Tmachinetime[j][int(indx[0, j])][
        #                                 m]
        #                             if min_index == 0:
        #                                 min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
        #                                 min_mt = m
        #                             elif min_index > T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]:
        #                                 min_index = T[0][self.Tmachine[j][int(indx[0, j])][m] - 1]
        #                                 min_mt = m
        #                             else:
        #                                 min_index = min_index
        #
        #                         min_wh = np.argwhere(T[0] == min_index)
        #                         # print("索引",min_wh)
        #                         # print("T", T)
        #                         # print("min_index", min_index)
        #                         # min_wh = np.argwhere(T[0] == min_index)
        #                         # print("Tmachine[j][int(indx[0,j])] = ", len(self.Tmachine[j][int(indx[0, j])]))
        #                         # print("min_mt =", min_mt)
        #                         # print("min_wh =", min_wh)
        #                         # print(j)
        #                         # print("indx =", int(indx[0, j]))
        #                         machine[0, z] = self.Tmachine[j][int(indx[0, j])][min_mt] - 1
        #                         factor[0, z] = self.M_dicr[machine[0, z]][0]
        #                         machine_time[0, z] = self.Tmachinetime[j][int(indx[0, j])][min_mt]
        #                         Time[0][min_wh[0, 0]] = T[0][min_wh[0, 0]]
        #                         T = np.copy(Time)
        #                         indx[0, j] = indx[0, j] + 1
        #         # print("机器排序2", machine)
        #         else:
        #             for j in range(self.job_num):
        #                 for z in range(len(job[0])):
        #                     if job[0, z] == j:
        #                         x = self.Tmachine[j][int(indx[0, j])]
        #                         y = random.choice(x)
        #                         machine[0][z] = y - 1
        #                         factor[0][z] = self.M_dicr[machine[0, z]][0]
        #                         for min_mt in range(len(self.Tmachine[j][int(indx[0, j])])):
        #                             if self.Tmachine[j][int(indx[0, j])][min_mt] == y:
        #                                 machine_time[0][z] = self.Tmachinetime[j][int(indx[0, j])][min_mt]
        #                         indx[0, j] = indx[0, j] + 1
        #         # print("机器排序3", machine)
        #         # print(job)
        #         # print(machine)
        #         # print(machine_time)
        #         # print(factor)
        #         trantime = self.gettran(job, machine)
        #         index = []
        #         k = 0
        #         for i in range(self.job_num):
        #
        #             for j in range(len(job[0])):
        #                 if job[0][j] == i:
        #                     k += 1
        #                     index.append(j)
        #                     if k == 1:
        #                         trantime[0][j] = 0
        #                     else:
        #                         a = machine[0][j]  # 当前工序机器序号
        #                         b = machine[0][index[-2]]  # 该工件前一个工序机器编号
        #                         x = list(self.M_dicr[int(a)])[0] - 1
        #                         y = list(self.M_dicr[int(b)])[0] - 1
        #                         # print(x,y)
        #
        #                         trantime[0][j] = self.tran_time[y][x]
        #             # 获取两个工序机器对应的车间
        #
        #             index = []
        #             k = 0
        #         work_F[size], work_tran[size], work_job[size], work_M[size], work_T[size] = factor[0], trantime[0], job[0], \
        #                                                                                     machine[0], machine_time[0]
        #         job_init[size] = initial_a
        #         machine_inits[size] = machine_init
        #         worker_inits[size] = worker_init
        #     # work_job,每个工序对应的工件
        #     # work_M，每个工序加工的机器
        #     # work_T，每个工序加工的时间
        #     # job，每个工序所属的工件
        #     # machine，每个工序加工的机器
        #     # print("Tmachine",self.Tmachine)
        #     # print("HFUJ", work_job[size])
        #     # print("work_M", work_M[size])
        #     # print("work_T",work_T[size])
        #     # print("job_init",job_init[size])
        #     # print("machine",machine)
        #     # print("trantime",trantime)
        #     # WS根据MS生成人员编码
        #     WC = np.zeros((self.popsize, work_job.shape[1]))
        #     for i in range(self.popsize):
        #         for j in range(work_job.shape[1]):
        #             if j == 1:
        #                 WC[i][j] = np.random.choice(self.work_arr[int(work_M[i][j])])
        #             else:
        #                 WC[i][j] = self.select_different_number1(self.work_arr[int(work_M[i][j])], WC[i][j - 1])  # 连续不相同
        #     # print("WC",WC)
        #     return work_job, work_M, work_T, work_tran, work_F, job_init, WC, machine_inits, worker_inits

    def is_sequence_valid(self, sequence, processing_order):
        """
        判断给定的序列是否满足工件加工先后顺序
        :param sequence: 待判断的工件加工序列
        :param processing_order: 工件加工先后顺序字典
        :return: 如果满足顺序返回 True，否则返回 False
        """
        for post, pre_list in processing_order.items():
            post_index = None
            pre_index = None
            try:
                post_index = sequence.index(post)
                if isinstance(pre_list, int):
                    pre_list = [pre_list]
                for pre in pre_list:
                    try:
                        pre_index = sequence.index(pre)
                        if pre_index > post_index:
                            return False
                    except ValueError:
                        return False
            except ValueError:
                continue
        return True

    def select_machine(self, machine_init):
        process_order = np.zeros(self.job_num)
        job_machine = np.zeros((1, self.all_num))
        machine_time = np.zeros((1, self.all_num))
        for job_order in range(len(self.work)):
            index1 = int(self.work[job_order])
            index2 = int(process_order[index1])
            n = len(self.Tmachine[index1][index2])

            interval = 1 / n
            for i in range(n):
                start = i * interval
                end = (i + 1) * interval
                if start <= machine_init[job_order] < end:
                    job_machine[0, job_order] = self.Tmachine[index1][index2][i]
                    machine_time[0, job_order] = self.Tmachinetime[index1][index2][i]
                    break
            else:
                job_machine[0, job_order] = self.Tmachine[index1][index2][-1]  # 如果 r == 1，选择最后一个元素
                machine_time[0, job_order] = self.Tmachinetime[index1][index2][-1]
            process_order[self.work[job_order]] += 1
        return job_machine, machine_time

    def select_worker(self, worker_init, job_machine):
        machine_worker = np.zeros((1, job_machine.shape[1]))
        # machine_time = np.zeros((1, self.all_num))
        for job_order in range(job_machine.shape[1]):
            n = len(self.work_arr[int(job_machine[0, job_order] - 1)])
            index1 = int(job_machine[0, job_order] - 1)
            interval = 1 / n
            for i in range(n):
                start = i * interval
                end = (i + 1) * interval
                if start <= worker_init[job_order] < end:
                    machine_worker[0, job_order] = self.work_arr[index1][i]
                    break
            else:
                machine_worker[0, job_order] = self.work_arr[index1][-1]
        return machine_worker

    def to_MT(self, W1, M1, T1, WC):  # 把加工机器编码和加工时间编码转化为对应列表，目的是记录工件的加工时间和加工机器
        Ma_W1, Tm_W1, WCross, WC_W1 = [], [], [], []
        for i in range(self.job_num):  # 添加工件个数的空列表
            Ma_W1.append([]), Tm_W1.append([]), WCross.append([]), WC_W1.append([])

        for i in range(W1.shape[1]):
            signal1 = int(W1[0, i])
            #
            # print("111",signal1)
            # print(Ma_W1[signal1])

            Ma_W1[signal1].append(M1[0, i]), Tm_W1[signal1].append(T1[0, i]), WC_W1[signal1].append(
                WC[0, i]);  # 记录每个工件【】的加工机器,时间，人员
            index = np.random.randint(0, 2, 1)[0]
            WCross[signal1].append(index)  # 随机生成一个为0或者1的列表，用于后续的机器的均匀交叉
        return Ma_W1, Tm_W1, WCross, WC_W1  # 工件的加工机器和加工时间 分为20个数列

    def back_MT(self, W1, Ma_W1, Tm_W1, WC1):  # 列表返回机器及加工时间编码
        memory1 = np.zeros((1, self.job_num), dtype=int)
        # print("W1",W1)
        # print("Ma_W1",Ma_W1)
        # print("Tm_W1",Tm_W1)
        # print("WC1",WC1)
        m1, t1, wc = np.zeros((1, W1.shape[1])), np.zeros((1, W1.shape[1])), np.zeros((1, W1.shape[1]))
        for i in range(W1.shape[1]):
            signal1 = int(W1[0, i])
            # print(signal1)
            # print(Tr_W1[signal1][memory1[0,signal1]])
            m1[0, i] = Ma_W1[signal1][memory1[0, signal1]]  # 读取对应工序的加工机器             一个工件的多个工序加工机器    得出机器和加工时间的序列
            t1[0, i] = Tm_W1[signal1][memory1[0, signal1]]
            wc[0][i] = WC1[signal1][memory1[0, signal1]]
            # r1[0,i]=Tr_W1[signal1][memory1[0,signal1]]
            memory1[0, signal1] += 1
        # print("m1",m1)
        return m1, t1, wc



    def new_creat_job(self):
        # print(self.Tmachinetime)
        work_F, work_tran, work_job, work_M, work_T = np.zeros((self.popsize, len(self.work))), np.zeros(
            (self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work))), np.zeros(
            (self.popsize, len(self.work))), np.zeros((self.popsize, len(self.work)))
        job_init = np.zeros((self.popsize, len(self.work)))
        machine_inits = np.zeros((self.popsize, len(self.work)))
        worker_inits = np.zeros((self.popsize, len(self.work)))
        work_W = np.zeros((self.popsize, len(self.work)))
        for size in range(self.popsize):
            # len(self.work)工序数
            initial_a = np.random.rand(len(self.work))  # 通过本函数可以返回一个或一组服从“0~1”均匀分布的随机样本值。随机样本取值范围是[0,1)，不包括1
            machine_init = np.random.rand(len(self.work))
            worker_init = np.random.rand(len(self.work))
            machine, machine_time = self.select_machine(machine_init)
            machine_worker = self.select_worker(worker_init, machine)
            index_work = np.array(initial_a).argsort()  # 将随机样本值由小到大排列，排列出其对应的索引
            result_init = copy.deepcopy(self.work)
            result_init = np.array(result_init).reshape(1, len(self.work))
            machine = np.array(machine).reshape(1, len(self.work))
            machine_time = np.array(machine_time).reshape(1, len(self.work))
            machine_worker = np.array(machine_worker).reshape(1, len(self.work))
            Ma_W1, Tm_W1, WCross, WC_W1 = self.to_MT(result_init, machine, machine_time, machine_worker)
            job = []
            # machine_sort = []
            # worker_sort = []
            # machine_time_sort = []
            # print("work",self.work)
            for i in range(len(self.work)):
                job.append(self.work[index_work[i]])
            # machine_sort.append(machine[0,index_work[i]])
            # worker_sort.append(machine_worker[0,index_work[i]])
            # machine_time_sort.append(machine_time[0,index_work[i]])
            # job是根据index_work改变的work的结果
            # print("job", job)
            job = np.array(job).reshape(1, len(self.work))
            machine_new, time_new, wc = self.back_MT(job, Ma_W1, Tm_W1, WC_W1)

            machine_sort = np.array(machine_new).reshape(1, len(self.work))
            worker_sort = np.array(wc).reshape(1, len(self.work))
            machine_time_sort = np.array(time_new).reshape(1, len(self.work))
            # 将job一维数组转变成二维一行数据
            factor = np.zeros((1, self.all_num))
            # machine = np.zeros((1, self.all_num))
            # machine_time = np.zeros((1, self.all_num))

            # trantime =self.gettran(job,machine)
            trantime = np.zeros((1, len(self.work)))
            # index = []
            # k = 0
            # for i in range(self.job_num):
            #
            # 	for j in range(len(job[0])):
            # 		if job[0][j] == i:
            # 			k += 1
            # 			index.append(j)
            # 			if k == 1:
            # 				trantime[0][j] = 0
            # 			else:
            # 				a = machine[0][j]  # 当前工序机器序号
            # 				b = machine[0][index[-2]]  # 该工件前一个工序机器编号
            # 				x = list(self.M_dicr[int(a)])[0] - 1
            # 				y = list(self.M_dicr[int(b)])[0] - 1
            # 				# print(x,y)
            #
            # 				trantime[0][j] = self.tran_time[y][x]
            # 	# 获取两个工序机器对应的车间
            #
            # 	index = []
            # 	k=0
            work_F[size], work_tran[size], work_job[size], work_M[size], work_T[size], work_W[size] = factor[0], \
                                                                                                      trantime[0], job[
                                                                                                          0], \
                                                                                                      machine_sort[0], \
                                                                                                      machine_time_sort[
                                                                                                          0], \
                                                                                                      worker_sort[0]
            job_init[size] = initial_a
            machine_inits[size] = machine_init
            worker_inits[size] = worker_init
        # work_job,每个工序对应的工件
        # work_M，每个工序加工的机器
        # work_T，每个工序加工的时间
        # job，每个工序所属的工件
        # machine，每个工序加工的机器
        # print("Tmachine",self.Tmachine)
        # print("HFUJ", work_job[size])
        # print("work_M", work_M[size])
        # print("work_T",work_T[size])
        # print("job_init",job_init[size])
        # print("machine",machine)
        # print("trantime",trantime)
        # WS根据MS生成人员编码
        # 	WC = np.zeros((self.popsize, work_job.shape[1]))
        # 	for i in range(self.popsize):
        # 		for j in range(work_job.shape[1]):
        # 			if j == 1:
        # 				WC[i][j] = np.random.choice(self.work_arr[int(work_M[i][j])])
        # 			else:
        # 				WC[i][j] = self.select_different_number1(self.work_arr[int(work_M[i][j])],WC[i][j - 1])  # 连续不相同
        # print("WC",WC)
        return work_job, work_M, work_T, work_tran, work_F, job_init, work_W, machine_inits, worker_inits

    def select_different_number1(self, list, number):
        while True:
            if len(list) == 1:
                return list[0]
            else:
                random_number = np.random.choice(list)
                if random_number != number:
                    return random_number

    def caculate(self, job, machine, machine_time, trantime, WC):
        # print(job)
        # print(p1,p2)
        jobtime = np.zeros((1, self.job_num))  # 工件对应的完成时间
        tmm = np.zeros((1, self.machine_num))  # 各个机器实际完成工件总时长
        work_time = np.zeros((1, self.work_num))  # 每个工人工作结束时间
        # print(tmm)
        # print(machine)
        tmmw = np.zeros((1, self.machine_num))  # 各个机器理论工作时间
        startime = 0  # 工序开始时间
        list_M, list_S, list_W, list_WO = [], [], [], []  # S:所有开始时间列表，W：完成时间列表,M:所用机器列表;
        list_T = [[] for range in tmm[0]]
        # svg:第i个工序所属的工件号  sig：第i个工序所对应的机器
        inde = np.zeros((1, self.job_num))
        for i in range(job.shape[1]):
            svg, sig, swg = int(job[0, i]), int(machine[0, i]) - 1, int(
                WC[0, i] - 1)  # svg 第i个工序所属的工件号，sig机器号 job为工序加工编码 machine为机器编码,swg工人序号

            # print(sig)
            inde[0, int(job[0][i])] += 1  # 工件已完成的工序个数
            if (jobtime[0, svg] > 0):
                startime = max(jobtime[0, svg], tmm[0, sig], work_time[0, swg]) + trantime[0, i]
                tmm[0, sig] = startime + machine_time[0, i]
                jobtime[0, svg] = startime + machine_time[0, i]
                work_time[0, swg] = startime + machine_time[0, i]

            if (jobtime[0, svg] == 0):
                startime = max(tmm[0, sig], work_time[0, swg])
                tmm[0, sig] = startime + machine_time[0, i]
                jobtime[0, svg] = startime + machine_time[0, i]
                work_time[0, swg] = startime + machine_time[0, i]

            list_M.append(machine[0, i])
            list_S.append(startime)
            list_W.append(machine_time[0, i])
            list_T[sig].append([svg, int(inde[0, int(job[0][i])]), int(startime), int(machine_time[0, i]),
                                int(trantime[0, i])])  # list _T :工件号（同一工件的各个工序一样），已完成工序数，开始时间，加工时间，转移时间
            tmmw[0, sig] += (machine_time[0, i] + trantime[0, i])
            list_WO.append(swg)

        tmax = np.argmax(tmm[0]) + 1  # 结束最晚的机器
        Wmax = np.argmax(work_time[0])
        C_finish = max(tmm[0])  # 最晚完工时间
        # print(list_T)

        return C_finish, tmax, list_T, list_M, list_S, list_W, tmmw, Wmax

    def caculate1(self, job, machine, machine_time, trantime, WC):
        jobtime = np.zeros((1, self.job_num))
        tmm = np.zeros((1, self.machine_num))
        work_time = np.zeros((1, self.work_num))  # 工人完成上个任务时间（资源约束用）
        tmmw = np.zeros((1, self.machine_num))  # 机器加工时间累计（机器“运行”时间）

        list_M, list_S, list_W, list_WO = [], [], [], []
        list_T = [[] for _ in range(self.machine_num)]
        inde = np.zeros((1, self.job_num))

        for i in range(job.shape[1]):
            svg = int(job[0, i])  # 工件编号
            sig = int(machine[0, i])  # 机器编号（你的代码里直接用作索引）
            swg = int(WC[0, i] - 1)  # 工人编号（0-based）

            # 加工时间直接用 machine_time
            op_duration = machine_time[0, i]

            # 把 gettran 改为全0
            transfer_t = trantime[0, i]

            op_seq = int(inde[0, svg] + 1)

            last_finish_time = work_time[0, swg]
            startime = max(jobtime[0, svg] + transfer_t, tmm[0, sig], last_finish_time)
            endtime = startime + op_duration

            inde[0, svg] += 1
            tmm[0, sig] = endtime
            jobtime[0, svg] = endtime
            work_time[0, swg] = endtime

            list_M.append(sig)
            list_S.append(startime)
            list_W.append(op_duration)
            list_T[sig].append([svg, op_seq,
                                int(round(startime)),
                                int(round(op_duration)),
                                int(round(transfer_t)),
                                swg + 1])

            tmmw[0, sig] += op_duration
            list_WO.append(swg)

        # --- 目标1：Cmax ---
        C_finish = np.max(tmm[0]) if tmm[0].size > 0 else 0

        # --- 机器加工总时长（Twork） ---
        Twork = np.sum(tmmw[0])

        # --- 目标2：总能耗（加工+空载+转运）---
        p1 = np.array([self.M_dicr[m][1] for m in range(self.machine_num)])  # 加工功率
        p2 = np.array([self.M_dicr[m][2] for m in range(self.machine_num)])  # 空载功率

        machine_idle_time = np.zeros_like(tmmw)
        for m in range(self.machine_num):
            machine_finish_time = tmm[0, m]
            # processing_time_on_m = tmmw[0, m]
            # processing_time_on_m = sum(item[3] for item in list_T[m])  # 仍使用 round 后时长（保持原行为）
            # machine_idle_time[0, m] = max(0, machine_finish_time - processing_time_on_m)
            processing_time_on_m = tmmw[0, m]
            machine_idle_time[0, m] = max(0.0, tmm[0, m] - processing_time_on_m)

        trest = machine_idle_time

        # 已设置转运时间为0，这里 transfer_energy 会自然为0
        total_transfer_time_sum = np.sum(trantime[0])
        transfer_energy = total_transfer_time_sum * 1.5

        E_all = np.sum(tmmw * p1) + np.sum(trest * p2) + transfer_energy

        tmax = np.argmax(tmm[0]) + 1
        Wmax = np.argmax(work_time[0])

        # --- 目标3：机器负荷 = 所有机器运行时间总和 ---
        machine_load = Twork

        return (C_finish, tmax, list_T, list_M, list_S, list_W, tmmw[0], Wmax, Twork,
                machine_load, E_all)

    import numpy as np
    import math

    def calculate_total_metrics1(self, data):
        """
        考虑特殊嵌套结构的效率修正计算

        参数:
        data: {'t': 理论时间, 'm': 机器ID, 'w': 工人ID}
        power_params: {m_id: [p_base, p_work, p_idle]}
        allowed_workers: [[机器0工人], [机器1工人], ...] -> [[2, 3, 1], [3, 2], ...]
        efficiency_values: [[机器0效率], [机器1效率], ...] -> [[0.99, 0.98, 0.98], ...]
        """

        # 1. 初始化机器负载记录 (整数)
        m_loads = {m: 0 for m in self.M_dicr.keys()}
        actual_durations = []

        # 2. 遍历工序计算实际加工时间
        for t_base, m_id, w_id in zip(data['t'], data['m'], data['w']):
            m_id = int(m_id)
            w_id = int(w_id)

            # --- 核心逻辑：在嵌套结构中查找效率 ---
            try:
                # 第一步：找到机器 m_id 允许的工人列表
                worker_list_for_machine = self.work_arr[m_id]

                # 第二步：找到当前工人 w_id 在该列表中的索引位置
                # 如果你的数据中 w_id 是从1开始而列表也是[2,3,1]，直接使用 index
                idx = worker_list_for_machine.index(w_id)

                # 第三步：根据索引从效率值列表中取出对应的效率
                efficiency = self.efficiency[m_id][idx]

            except (ValueError, IndexError):
                # 如果找不到工人或机器索引越界，给一个默认效率 1.0
                efficiency = 1.0
                print(f"警告: 机器 {m_id} 不允许工人 {w_id} 操作或索引越界")

            # 3. 实际加工时间 = 理论时间 * 效率，并向上取整为整数
            t_actual = int(math.ceil(t_base * efficiency))
            actual_durations.append(t_actual)

            if m_id in m_loads:
                m_loads[m_id] += t_actual

        # 3. 计算完工时间 (Makespan) 和总负载
        makespan = int(max(m_loads.values())) if m_loads else 0
        total_load = int(sum(actual_durations))

        # 4. 计算总能耗
        total_energy = 0.0
        for m_id, load in m_loads.items():
            p_work = self.M_dicr[m_id][1]
            p_idle = self.M_dicr[m_id][2]

            # 该机器加工能耗 + 空闲能耗
            work_e = load * p_work
            idle_e = (makespan - load) * p_idle
            total_energy += (work_e + idle_e)

        return makespan, total_load, total_energy
    def plugin(self, list_T, list_M, list_S, list_W, job, tmmw, trantime):  # 插件规则
        # print(job)
        p1, p2 = [], []
        # p1每个机器的工作能耗，p2为空闲能耗
        # print(type(job))
        job = job.tolist()
        # print(self.M_dicr)
        for i in range(self.machine_num):
            p1.append(self.M_dicr[i][1])
            p2.append(self.M_dicr[i][2])
        # print(p1)
        # print(list_T)
        for i in range(self.machine_num):
            for j in range(len(list_T[i])):

                if (list_T[i][j][1] > 1) and (j > 0):  # list_T[i][j][1] 工件完成的工序数   15 2 177 17 0
                    a, b = int(list_T[i][j][0]), int(list_T[i][j][1])  # 工件号 工序号

                    # print("-----------------------")
                    for x in range(len(list_T)):
                        for y in range(len(list_T[x])):
                            if (list_T[x][y][0] == a) and (list_T[x][y][1] == b):
                                for z in range(j - 1):
                                    if (list_T[x][y][2] + list_T[x][y][3] + list_T[i][j][4] <= list_T[i][z][2] +
                                        list_T[i][z][3]) and (
                                            list_T[i][z][2] + list_T[i][z][3] + list_T[i][j][3] <= list_T[i][z + 1][2]):

                                        list_T[i][j][2] = list_T[i][z][2] + list_T[i][z][3]
                                        list_T[i].insert(z + 1, list_T[i][j])
                                        # print(list_T[i][j+1])
                                        del list_T[i][j + 1]

                                        this_job = self.getind(list_T[i][z + 1], job)
                                        next_job = self.getind(list_T[i][z + 2], job)

                                        # print(this_job, next_job)
                                        # print("---")
                                        job[0].insert(next_job, job[0][this_job])
                                        del job[0][this_job + 1]
                                        # print(z)
                                        # print(j)
                                        #
                                        # print(list_T)
                                        # print("------------------")
                                        break
                                    elif (list_T[x][y][2] + list_T[x][y][3] <= list_T[i][z][2] + list_T[i][z][3]) and (
                                            list_T[x][y][2] + list_T[x][y][3] + list_T[i][j][4] >= list_T[i][z][2] +
                                            list_T[i][z][3]) and (
                                            list_T[x][y][2] + list_T[x][y][3] + list_T[i][j][4] + list_T[i][j][3] <=
                                            list_T[i][z + 1][2]):
                                        list_T[i][j][2] = list_T[x][y][2] + list_T[x][y][3] + list_T[i][j][4]
                                        # print(list_T[i][j])
                                        # print("------------------")
                                        list_T[i].insert(z + 1, list_T[i][j])

                                        del list_T[i][j + 1]
                                        this_job = self.getind(list_T[i][z + 1], job)
                                        next_job = self.getind(list_T[i][z + 2], job)
                                        job[0].insert(next_job, job[0][this_job])
                                        del job[0][this_job + 1]

                                        break
                                    elif (list_T[x][y][2] + list_T[x][y][3] >= list_T[i][z][2] + list_T[i][z][3]) and (
                                            list_T[x][y][2] + list_T[x][y][3] + list_T[i][j][4] + list_T[i][j][3] <=
                                            list_T[i][z + 1][2]):
                                        list_T[i][j][2] = list_T[x][y][2] + list_T[x][y][3] + list_T[i][j][4]
                                        # print(list_T[i][j])
                                        # print(list_T[x][y])
                                        # print("------------------")
                                        list_T[i].insert(z + 1, list_T[i][j])

                                        del list_T[i][j + 1]
                                        this_job = self.getind(list_T[i][z + 1], job)
                                        next_job = self.getind(list_T[i][z + 2], job)

                                        job[0].insert(next_job, job[0][this_job])

                                        del job[0][this_job + 1]

                                        # print(list_T)
                                        break
                                    elif (j == len(list_T[i]) and list_T[x][y][2] + list_T[x][y][3] + list_T[i][j][4] >=
                                          list_T[i][z][2] + list_T[i][z][3]):
                                        list_T[i][j][2] = list_T[x][y][2] + list_T[x][y][3]
                                        break
                                    elif (j == len(list_T[i]) and list_T[x][y][2] + list_T[x][y][3] + list_T[i][j][4] <=
                                          list_T[i][z][2] + list_T[i][z][3]):
                                        list_T[i][j][2] = list_T[i][z][2] + list_T[i][z][3]
                                        break

        job = np.array(job)

        tmm = np.zeros((1, self.machine_num))
        ind = np.zeros((1, self.job_num))
        list_M, list_S, list_W, = [], [], []
        for i in range(job.shape[1]):
            x = int(job[0, i])
            ind[0, int(job[0][i])] += 1
            y = int(ind[0, int(job[0][i])])
            # print(type(y))
            # print(y)
            # print(x)
            for j in range(len(list_T)):
                for k in range(len(list_T[j])):
                    if (list_T[j][k][0] == x) and (list_T[j][k][1] == y):
                        list_S.append(list_T[j][k][2])
                        list_M.append(j)
                        list_W.append(list_T[j][k][3])
                        tmm[0, j] = max(list_T[j][k][2] + list_T[j][k][3], tmm[0, j])

        trest = tmm - tmmw
        E_all = sum((tmmw * p1)[0]) + sum((trest * p2)[0 - 1]) + sum((trantime * 1.5)[0])  # 加工功率+空载功率+运输功率
        tmax = np.argmax(tmm[0])  # 结束最晚的机器

        C_finish = max(tmm[0])  # 最晚完工时间
        Twork = sum(tmmw[0])  # 机器负荷

        # print("C_finish",C_finish)
        # print("Twork",Twork)
        # print("E_all",E_all)
        # print("list_M",list_M)
        # print("list_S",list_S)
        # print("list_W",list_W)
        # print("tmax",tmax)
        # print("list_T",list_T)

        # list_M所用机器列表
        # list_S,所有开始时间列表
        # list_W 使用时间列表
        # print("-----------------")
        # print(job)
        #
        # E_all总能耗
        return C_finish, Twork, E_all, list_M, list_S, list_W, tmax, list_T

    def draw(self, job, machine, machine_time, trantime, Wc, WC_W1):  # 画图
        # print(job)
        # print(machine)
        # print(trantime)
        _, _, T, M, S, W, tmmw, Wmax = self.caculate(job, machine, machine_time, trantime, Wc)
        # print(c)
        # print(T)
        C_finish, Twork, E_all, list_M, list_S, list_W, tmax, list_T = self.plugin(T, M, S, W, job, tmmw, trantime)
        # print(C_finish)
        # print(tmax)
        # print(list_T)
        # print(list_T[4])
        plt.figure(figsize=(20, 10))
        fa = [[] for i in range(len(self.tran_time))]  # fa = 55个[]
        for i in range(self.machine_num):
            fa[self.M_dicr[i][0] - 1].append(i)
        # print("fa=",fa)
        ga = []

        for i in range(len(fa)):
            for j in range(len(fa[i])):
                ga.append(fa[i][j])

        # print(ga)
        tran2 = [0]
        zz = 0
        for i in range(len(fa) - 1):
            zz = zz + len(fa[i])
            tran2.append(zz)
        # print(tran2)
        colors = ['red', 'Navy', 'grey', 'yellow', 'Violet', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral',
                  'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon', 'Tomato',
                  'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal',
                  'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod', 'red', 'Navy', 'grey', 'yellow', 'Violet',
                  'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral', 'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen',
                  'OliveDrab', 'Orange', 'LightSalmon', 'Tomato', 'RosyBrown', 'Linen', 'Wheat', 'Turquoise',
                  'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal', 'MintCream', 'Chartreuse', 'OliveDrab',
                  'Goldenrod', 'red', 'Navy', 'grey', 'yellow', 'Violet', 'Cyan', 'Green', 'LightYellow', 'Tan',
                  'Coral', 'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon',
                  'Tomato', 'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle',
                  'Teal', 'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod']

        for i in range(self.job_num):  # list _T :工件号（同一工件的各个工序一样），已完成工序数，开始时间，加工时间，转移时间
            for j in range(len(list_T)):
                for z in range(len(list_T[j])):  # i工件 j 机器 z这个机器加工工件数量
                    if list_T[j][z][0] == i:
                        ind = ga.index(j)
                        # print(ind)
                        plt.bar(x=list_T[j][z][2], bottom=ind, height=0.5, width=list_T[j][z][3],
                                orientation="horizontal", color=colors[i], edgecolor='black')
                        plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind, '%.0f' % (i + 1), color='black',
                                 verticalalignment='top', fontsize=12, weight='bold')
                        plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind,
                                 '%.0f' % (WC_W1[i][int(list_T[j][z][1] - 1)]), color='black',
                                 verticalalignment='bottom', fontsize=12, weight='bold')  # 12是矩形框里字体的大小，可修改
                        if list_T[j][z][4] != 0:
                            plt.bar(x=list_T[j][z][2] - list_T[j][z][4], bottom=ind + 0.3, height=0.1,
                                    width=list_T[j][z][4], orientation="horizontal", color=colors[i], edgecolor='black')

        for i in range(len(fa)):
            plt.text(C_finish + 1, tran2[i], color='black', verticalalignment='center',
                     fontsize=20, weight='bold')  # 12是矩形框里字体的大小，可修改
        # plt.bar(x=C_finish+1, bottom=tran2[i], height=0.5, width=50, orientation="horizontal",color='white', edgecolor='blue')
        # plt.plot([C_finish, C_finish], [0, tran2[i]], c='black', linestyle='-.',label='Factory%.1f' % (i+1))  # 用虚线画出最晚完工时间
        font1 = {'weight': 'bold', 'size': 22}  # 汉字字体大小，可以修改

        plt.xlabel("Time", font1)
        # plt.title("of1", font1)
        plt.ylabel("Machine", font1)
        scale_ls, index_ls = self.axis()
        tran = []
        aaa = 0
        for i in range(len(fa) - 1):
            aaa = aaa + len(fa[i])
            tran.append(aaa)
        yticks = [scale_ls[i] for i in ga]
        # print(yticks)
        plt.yticks([i for i in range(0, self.machine_num)], yticks)

        plt.hlines([float(i - 0.5) for i in tran], 0, C_finish, color="blue")  # 横线
        plt.tick_params(labelsize=22)  # 坐标轴刻度字体大小，可以修改
        plt.plot([C_finish, C_finish], [0, tmax + 1], c='black', linestyle='-.',
                 label='Finish time=%.1f' % (C_finish))  # 用虚线画出最晚完工时间

        ax = plt.gca()
        labels = ax.get_xticklabels()
        [label.set_fontname('Times New Roman') for label in labels]
        plt.legend(prop={'family': ['SimHei'], 'size': 16})  # 标签字体大小，可以修改
        plt.xlabel("Time", font1)
        plt.savefig('GTT.png')
        plt.show()

    import matplotlib.pyplot as plt
    from matplotlib import patches as mpatches
    from matplotlib.lines import Line2D
    def draw_noFactory_failure_forever(self, before, after, fail_m, fail_time, WC_W1):
        """
        逻辑修改：故障机器从 fail_time 起永久失效
        样式保持：完全遵循原有的 bar、text 和颜色逻辑
        """
        plt.figure(figsize=(20, 10))

        # 1. 颜色列表（保持不变）
        colors = ['red', 'Violet', 'grey', 'yellow', 'Navy', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral',
                  'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon', 'Tomato',
                  'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal',
                  'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod'] * 4

        m_clocks = {}
        w_clocks = {}
        list_T = [[] for _ in range(self.machine_num)]
        job_op_counter = {}

        # --- A. 计算故障前已完成任务的起止时间 ---
        for k in range(len(before['j'])):
            j_id, m_id, dur, w_id = int(before['j'][k]), int(before['m'][k]), before['t'][k], int(before['w'][k])
            job_op_counter[j_id] = job_op_counter.get(j_id, 0) + 1
            op_num = job_op_counter[j_id]

            start_t = max(m_clocks.get(m_id, 0), w_clocks.get(w_id, 0))
            end_t = start_t + dur

            list_T[m_id].append([j_id, op_num, start_t, dur, 0])
            m_clocks[m_id] = end_t
            w_clocks[w_id] = end_t

        # --- B. 关键逻辑：锁定故障机器 ---
        # 故障机器在 fail_time 之后不再接收任何任务，将它的可用时间设为无穷大
        # 同时确保其他机器和工人在故障后从 fail_time 开始后续任务
        for m in range(self.machine_num):
            if m == fail_m:
                m_clocks[m] = float('inf')  # 永久失效
            else:
                m_clocks[m] = max(m_clocks.get(m, 0), fail_time)

        for w in np.unique(np.concatenate([before['w'], after['w']])):
            w_clocks[w] = max(w_clocks.get(w, 0), fail_time)

        # --- C. 计算故障后重调度的起止时间 ---
        for k in range(len(after['j'])):
            j_id, m_id, dur, w_id = int(after['j'][k]), int(after['m'][k]), after['t'][k], int(after['w'][k])
            job_op_counter[j_id] = job_op_counter.get(j_id, 0) + 1
            op_num = job_op_counter[j_id]

            # 这里的 m_id 应该是重调度后分配的新机器
            start_t = max(m_clocks.get(m_id, 0), w_clocks.get(w_id, 0))
            end_t = start_t + dur

            list_T[m_id].append([j_id, op_num, start_t, dur, 0])
            m_clocks[m_id] = end_t
            w_clocks[w_id] = end_t

        # 3. 绘图循环（完全保留样式）
        C_finish = 0
        # 先计算总完工时间，用于绘制故障区域
        for m_list in list_T:
            for item in m_list:
                C_finish = max(C_finish, item[2] + item[3])

        for i in range(self.job_num):
            for j in range(len(list_T)):
                for z in range(len(list_T[j])):
                    if list_T[j][z][0] == i:
                        ind = j
                        start_x, duration = list_T[j][z][2], list_T[j][z][3]
                        op_idx = int(list_T[j][z][1] - 1)

                        # 绘制加工任务块
                        plt.bar(x=start_x, bottom=ind, height=0.5, width=duration,
                                orientation="horizontal", color=colors[i], edgecolor='black')

                        # 工件号 (Top)
                        plt.text(start_x + duration / 32, ind, '%.0f' % (i + 1), color='black',
                                 verticalalignment='top', fontsize=12, weight='bold')

                        # 工序号或工人ID (Bottom)
                        plt.text(start_x + duration / 32, ind,
                                 '%.0f' % (WC_W1[i][op_idx]), color='black',
                                 verticalalignment='bottom', fontsize=12, weight='bold')

        # --- D. 绘制“永久故障”视觉标识 ---
        # 在故障机器对应的行，从故障点划红线区域直到 C_finish
        plt.bar(x=fail_time, bottom=fail_m, height=0.5, width=C_finish - fail_time,
                color='red', alpha=0.2, hatch='///', label='Machine Failed')

        # 4. 设置样式（完全保留原样）
        font1 = {'weight': 'bold', 'size': 22}
        plt.xlabel("Time", font1)
        plt.ylabel("Machine", font1)

        scale_ls, _ = self.axis()
        plt.yticks([k for k in range(0, self.machine_num)], [scale_ls[k] for k in range(self.machine_num)])
        plt.tick_params(labelsize=22)

        # 绘制故障时间红虚线
        plt.axvline(x=fail_time, color='red', linestyle='--', linewidth=3)

        # 完工时间虚线
        plt.plot([C_finish, C_finish], [0, self.machine_num], c='black', linestyle='-.',
                 label='Finish time=%.1f' % (C_finish))

        ax = plt.gca()
        [label.set_fontname('Times New Roman') for label in ax.get_xticklabels()]

        plt.legend(prop={'family': ['SimHei'], 'size': 16})
        plt.savefig('permanent_failure.png', bbox_inches='tight')
        plt.show()

    def draw_noFactory(self, job, machine, machine_time, trantime, Wc, WC_W1):  # 画图
        # 计算相关参数
        _, _, T, M, S, W, tmmw, Wmax = self.caculate(job, machine, machine_time, trantime, Wc)
        C_finish, Twork, E_all, list_M, list_S, list_W, tmax, list_T = self.plugin(T, M, S, W, job, tmmw, trantime)

        plt.figure(figsize=(20, 10))

        # ========== 关键修改1：移除工厂相关的fa、ga、tran2变量 ==========
        # 直接使用机器编号顺序，不再按工厂分组
        # 原代码中fa/ga/tran2都是工厂分组相关，全部删除

        # 颜色列表（保持不变，用于区分不同工件）
        colors = ['red',  'Violet', 'grey', 'yellow', 'Navy', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral',
                  'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon', 'Tomato',
                  'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal',
                  'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod', 'red', 'Navy', 'grey', 'yellow', 'Violet',
                  'Cyan',
                  'Green', 'LightYellow', 'Tan', 'Coral', 'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen',
                  'OliveDrab',
                  'Orange', 'LightSalmon', 'Tomato', 'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue',
                  'CornflowerBlue',
                  'Thistle', 'Teal', 'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod', 'red', 'Navy', 'grey',
                  'yellow',
                  'Violet', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral', 'SlateBlue', 'DeepSkyBlue', 'DarkCyan',
                  'SeaGreen',
                  'OliveDrab', 'Orange', 'LightSalmon', 'Tomato', 'RosyBrown', 'Linen', 'Wheat', 'Turquoise',
                  'PowderBlue',
                  'CornflowerBlue', 'Thistle', 'Teal', 'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod']

        # ========== 关键修改2：简化机器索引逻辑 ==========
        for i in range(self.job_num):  # list_T :工件号，已完成工序数，开始时间，加工时间，转移时间
            for j in range(len(list_T)):  # j是机器编号
                for z in range(len(list_T[j])):  # z是该机器加工的工件数量
                    if list_T[j][z][0] == i:
                        # 直接使用机器编号j作为y轴位置，不再通过ga映射
                        ind = j
                        # 绘制加工任务甘特图块
                        plt.bar(x=list_T[j][z][2], bottom=ind, height=0.5, width=list_T[j][z][3],
                                orientation="horizontal", color=colors[i], edgecolor='black')
                        # 工件编号文本
                        plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind, '%.0f' % (i + 1), color='black',
                                 verticalalignment='top', fontsize=12, weight='bold')
                        # 工序参数文本
                        plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind,
                                 '%.0f' % (WC_W1[i][int(list_T[j][z][1] - 1)]), color='black',
                                 verticalalignment='bottom', fontsize=12, weight='bold')
                        # 绘制转移时间块（如果有）
                        if list_T[j][z][4] != 0:
                            plt.bar(x=list_T[j][z][2] - list_T[j][z][4], bottom=ind + 0.3, height=0.1,
                                    width=list_T[j][z][4], orientation="horizontal", color=colors[i], edgecolor='black')

        # ========== 关键修改3：移除工厂相关的文本标注和横线 ==========
        # 原代码中绘制工厂分隔线、工厂编号的部分全部删除

        # 设置图表样式
        font1 = {'weight': 'bold', 'size': 22}
        plt.xlabel("Time", font1)
        plt.ylabel("Machine", font1)

        # ========== 关键修改4：简化y轴刻度设置 ==========
        scale_ls, index_ls = self.axis()
        # 直接使用机器编号作为y轴刻度，不再通过ga映射
        yticks = [scale_ls[i] for i in range(self.machine_num)]
        plt.yticks([i for i in range(0, self.machine_num)], yticks)

        # ========== 关键修改5：移除工厂分隔线 ==========
        # 原代码中plt.hlines绘制工厂分隔线的部分删除

        # 设置刻度字体大小
        plt.tick_params(labelsize=22)

        # 绘制完工时间虚线
        plt.plot([C_finish, C_finish], [0, self.machine_num], c='black', linestyle='-.',
                 label='Finish time=%.1f' % (C_finish))

        # 设置坐标轴字体
        ax = plt.gca()
        labels = ax.get_xticklabels()
        [label.set_fontname('Times New Roman') for label in labels]

        # 设置图例
        plt.legend(prop={'family': ['SimHei'], 'size': 16})

        # 保存并显示图表
        # plt.savefig('schduleinit.png', bbox_inches='tight')  # 添加bbox_inches防止标签被截断
        plt.show()

    def draw_noFactory1(self, job, machine, machine_time, trantime, Wc, WC_W1):  # 画图
        # 计算相关参数
        _, _, T, M, S, W, tmmw, Wmax = self.caculate(job, machine, machine_time, trantime, Wc)
        C_finish, Twork, E_all, list_M, list_S, list_W, tmax, list_T = self.plugin(T, M, S, W, job, tmmw, trantime)

        plt.figure(figsize=(20, 10))

        # 颜色列表（用于区分不同工件）
        colors = ['red', 'Violet',  'yellow', 'Green', 'Navy', 'Cyan',  'LightYellow', 'Tan', 'Coral',
                  'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon', 'Tomato',
                  'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal',
                  'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod', 'red', 'Navy', 'grey', 'yellow', 'Violet',
                  'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral', 'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen',
                  'OliveDrab', 'Orange', 'LightSalmon', 'Tomato', 'RosyBrown', 'Linen', 'Wheat', 'Turquoise',
                  'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal', 'MintCream', 'Chartreuse', 'OliveDrab',
                  'Goldenrod']

        # ========== 先绘制故障块（工件号为 -1） ==========
        for j in range(len(list_T)):  # 机器索引
            for z in range(len(list_T[j])):  # 该机器上的任务索引
                if list_T[j][z][0] == -1:  # 故障
                    ind = j
                    # 故障加工块
                    plt.bar(x=list_T[j][z][2], bottom=ind, height=0.5, width=list_T[j][z][3],
                            orientation="horizontal", color='gray', edgecolor='black')
                    plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind, '故障', color='black',
                             verticalalignment='top', fontsize=12, weight='bold')
                    # 故障块的转移时间（如有）
                    if list_T[j][z][4] != 0:
                        plt.bar(x=list_T[j][z][2] - list_T[j][z][4], bottom=ind + 0.3, height=0.1,
                                width=list_T[j][z][4], orientation="horizontal", color='gray', edgecolor='black')

        # ========== 再绘制正常工件（工件号 ≥ 0） ==========
        for i in range(self.job_num):  # 工件编号
            for j in range(len(list_T)):  # 机器索引
                for z in range(len(list_T[j])):  # 该机器上的任务
                    if list_T[j][z][0] == i:
                        ind = j
                        # 加工块
                        plt.bar(x=list_T[j][z][2], bottom=ind, height=0.5, width=list_T[j][z][3],
                                orientation="horizontal", color=colors[i], edgecolor='black')
                        # 工件编号（显示为 i+1）
                        plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind, '%.0f' % (i + 1), color='black',
                                 verticalalignment='top', fontsize=12, weight='bold')
                        # 工序参数文本（增加索引越界保护）
                        op_idx = int(list_T[j][z][1] - 1)  # 工序索引从0开始
                        if i < len(WC_W1) and op_idx < len(WC_W1[i]):
                            plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind,
                                     '%.0f' % (WC_W1[i][op_idx]), color='black',
                                     verticalalignment='bottom', fontsize=12, weight='bold')
                        else:
                            # 索引越界时打印警告并显示“?”
                            print(
                                f"Warning: 工件{i}的工序{op_idx + 1}超出WC_W1[{i}]范围 (长度={len(WC_W1[i]) if i < len(WC_W1) else 'N/A'})")
                            plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind,
                                     '?', color='black',
                                     verticalalignment='bottom', fontsize=12, weight='bold')
                        # 转移时间块（如有）
                        if list_T[j][z][4] != 0:
                            plt.bar(x=list_T[j][z][2] - list_T[j][z][4], bottom=ind + 0.3, height=0.1,
                                    width=list_T[j][z][4], orientation="horizontal", color=colors[i], edgecolor='black')

        # 图表样式设置
        font1 = {'weight': 'bold', 'size': 22}
        plt.xlabel("Time", font1)
        plt.ylabel("Machine", font1)

        # y轴刻度（直接使用机器编号）
        scale_ls, index_ls = self.axis()
        yticks = [scale_ls[i] for i in range(self.machine_num)]
        plt.yticks([i for i in range(0, self.machine_num)], yticks)

        plt.tick_params(labelsize=22)

        # 完工时间虚线
        plt.plot([C_finish, C_finish], [0, self.machine_num], c='black', linestyle='-.',
                 label='Finish time=%.1f' % (C_finish))

        # 坐标轴字体
        ax = plt.gca()
        labels = ax.get_xticklabels()
        [label.set_fontname('Times New Roman') for label in labels]

        plt.legend(prop={'family': ['SimHei'], 'size': 16})

        # plt.savefig('ight_reSchdule.png', bbox_inches='tight')
        plt.show()

    def draw_noFactory2(self, job, machine, machine_time, trantime, Wc, WC_W1):  # 画图
        # 计算相关参数
        _, _, T, M, S, W, tmmw, Wmax = self.caculate(job, machine, machine_time, trantime, Wc)
        C_finish, Twork, E_all, list_M, list_S, list_W, tmax, list_T = self.plugin(T, M, S, W, job, tmmw, trantime)

        print('C_finish',C_finish)

        plt.figure(figsize=(20, 10))

        # 颜色列表
        colors = ['red', 'Violet', 'grey', 'yellow', 'Navy', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral',
                  'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon', 'Tomato',
                  'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal',
                  'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod', 'red', 'Navy', 'grey', 'yellow', 'Violet',
                  'Cyan',
                  'Green', 'LightYellow', 'Tan', 'Coral', 'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen',
                  'OliveDrab',
                  'Orange', 'LightSalmon', 'Tomato', 'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue',
                  'CornflowerBlue',
                  'Thistle', 'Teal', 'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod', 'red', 'Navy', 'grey',
                  'yellow',
                  'Violet', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral', 'SlateBlue', 'DeepSkyBlue', 'DarkCyan',
                  'SeaGreen',
                  'OliveDrab', 'Orange', 'LightSalmon', 'Tomato', 'RosyBrown', 'Linen', 'Wheat', 'Turquoise',
                  'PowderBlue',
                  'CornflowerBlue', 'Thistle', 'Teal', 'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod']

        # 绘制工序甘特图
        for i in range(self.job_num):
            for j in range(len(list_T)):
                for z in range(len(list_T[j])):
                    if list_T[j][z][0] == i:
                        ind = j
                        plt.bar(x=list_T[j][z][2], bottom=ind, height=0.5, width=list_T[j][z][3],
                                orientation="horizontal", color=colors[i], edgecolor='black')
                        plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind, '%.0f' % (i + 1), color='black',
                                 verticalalignment='top', fontsize=12, weight='bold')
                        plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind,
                                 '%.0f' % (WC_W1[i][int(list_T[j][z][1] - 1)]), color='black',
                                 verticalalignment='bottom', fontsize=12, weight='bold')
                        if list_T[j][z][4] != 0:
                            plt.bar(x=list_T[j][z][2] - list_T[j][z][4], bottom=ind + 0.3, height=0.1,
                                    width=list_T[j][z][4], orientation="horizontal", color=colors[i], edgecolor='black')

        # ==================== M7 故障块 + 中间显示“故障”文字 ====================
        m7_index = 4  # M7 对应的Y轴位置
        fault_start = 30  # 故障开始时间
        fault_duration = C_finish - 30  # 故障持续时长

        # 绘制灰色故障块
        plt.bar(x=fault_start, bottom=m7_index, height=0.5, width=fault_duration,
                orientation="horizontal", color='gray', edgecolor='black', alpha=0.7)

        # 在故障块正中间显示 “故障” 两个字
        plt.text(fault_start + fault_duration / 2, m7_index, '故障',
                 ha='center', va='center', fontsize=16, weight='bold', color='black')

        # 设置坐标轴
        font1 = {'weight': 'bold', 'size': 22}
        plt.xlabel("Time", font1)
        plt.ylabel("Machine", font1)

        scale_ls, index_ls = self.axis()
        yticks = [scale_ls[i] for i in range(self.machine_num)]
        plt.yticks([i for i in range(0, self.machine_num)], yticks)

        plt.tick_params(labelsize=22)

        # 完工时间虚线
        plt.plot([C_finish, C_finish], [0, self.machine_num], c='black', linestyle='-.',
                 label='Finish time=%.1f' % (C_finish))

        ax = plt.gca()
        labels = ax.get_xticklabels()
        [label.set_fontname('Times New Roman') for label in labels]

        # 图例只保留完工时间
        plt.legend(prop={'family': ['SimHei'], 'size': 16})

        # plt.savefig('schdule_all.png', bbox_inches='tight', dpi=300)
        plt.show()
    def draw1(self, job, machine, machine_time, trantime, Wc, WC_W1):
        # 画图
        _, _, T, M, S, W, tmmw, Wmax = self.caculate(job, machine, machine_time, trantime, Wc)
        C_finish, Twork, E_all, list_M, list_S, list_W, tmax, list_T = self.plugin(T, M, S, W, job, tmmw, trantime)

        plt.figure(figsize=(20, 10))

        fa = [[] for i in range(len(self.tran_time))]  # 工厂对应的机器列表
        for i in range(self.machine_num):
            fa[self.M_dicr[i][0] - 1].append(i)

        ga = []  # 机器显示顺序列表
        for i in range(len(fa)):
            for j in range(len(fa[i])):
                ga.append(fa[i][j])

        # 计算工厂分隔线位置
        tran2 = [0]
        zz = 0
        for i in range(len(fa) - 1):
            zz += len(fa[i])
            tran2.append(zz)

        # 定义工件颜色列表
        colors = ['red', 'Navy', 'grey', 'yellow', 'Violet', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral',
                  'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon',
                  'Tomato', 'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue',
                  'Thistle', 'Teal', 'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod'] * 3  # 重复确保足够

        # 绘制每个工件的工序
        for i in range(self.job_num):
            for j in range(len(list_T)):
                for z in range(len(list_T[j])):
                    if list_T[j][z][0] == i:
                        ind = ga.index(j)
                        # 绘制加工时间条
                        plt.bar(x=list_T[j][z][2], bottom=ind, height=0.5, width=list_T[j][z][3],
                                orientation="horizontal", color=colors[i], edgecolor='black')
                        # 显示工件号
                        plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind,
                                 f'{i + 1}', color='black', verticalalignment='top',
                                 fontsize=12, weight='bold')
                        # 显示工人信息
                        plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind,
                                 f'{WC_W1[i][int(list_T[j][z][1] - 1)]}', color='black',
                                 verticalalignment='bottom', fontsize=12, weight='bold')
                        # 绘制运输时间（如果有）
                        if list_T[j][z][4] != 0:
                            plt.bar(x=list_T[j][z][2] - list_T[j][z][4], bottom=ind + 0.3,
                                    height=0.1, width=list_T[j][z][4], orientation="horizontal",
                                    color=colors[i], edgecolor='black')

        # 标记工厂
        for i in range(len(fa)):
            plt.text(C_finish + 1, tran2[i], f'FACTORY{i + 1}', color='black',
                     verticalalignment='center', fontsize=20, weight='bold')

        # 设置坐标轴
        font1 = {'weight': 'bold', 'size': 22}
        plt.xlabel("Time", font1)
        plt.ylabel("Machine", font1)

        # 获取并调整坐标轴刻度 - 关键修改：确保machine中的0对应M1
        scale_ls, index_ls = self.axis()

        # 创建正确的机器编号映射：0->M1, 1->M2, 2->M3...
        # 直接使用ga中的原始机器编号（0,1,2...）并转换为M1,M2,M3格式
        yticks = [f'M{int(ga[i]) + 1}' for i in range(len(ga))]

        plt.yticks([i for i in range(0, self.machine_num)], yticks)

        # 绘制工厂分隔线
        plt.hlines([float(i - 0.5) for i in tran2], 0, C_finish, color="blue")

        # 设置刻度字体大小
        plt.tick_params(labelsize=22)

        # 绘制完工时间线
        plt.plot([C_finish, C_finish], [0, tmax + 1], c='black', linestyle='-.',
                 label=f'Finish time={C_finish:.1f}')

        # 设置字体
        ax = plt.gca()
        labels = ax.get_xticklabels()
        [label.set_fontname('Times New Roman') for label in labels]

        # 设置图例
        plt.legend(prop={'family': ['SimHei'], 'size': 16})
        plt.xlabel("Time", font1)

        # 保存并显示图像
        plt.savefig('GTT.png')
        plt.show()

    def draw_Schedule(self, job, machine, machine_time, trantime, Wc, WC_W1, faulty_machine):
        # 画图
        _, _, T, M, S, W, tmmw, Wmax = self.caculate(job, machine, machine_time, trantime, Wc)
        C_finish, Twork, E_all, list_M, list_S, list_W, tmax, list_T = self.plugin(T, M, S, W, job, tmmw, trantime)

        plt.figure(figsize=(20, 10))

        fa = [[] for i in range(len(self.tran_time))]  # fa = 55个[]
        for i in range(self.machine_num):
            fa[self.M_dicr[i][0] - 1].append(i)

        ga = []  # 机器显示顺序列表
        for i in range(len(fa)):
            for j in range(len(fa[i])):
                ga.append(fa[i][j])

        # 计算工厂分隔线位置
        tran2 = [0]
        zz = 0
        for i in range(len(fa) - 1):
            zz = zz + len(fa[i])
            tran2.append(zz)

        # 定义工件颜色列表
        colors = ['red', 'Navy', 'grey', 'yellow', 'Violet', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral',
                  'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon', 'Tomato',
                  'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal',
                  'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod', 'red', 'Navy', 'grey', 'yellow', 'Violet',
                  'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral', 'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen',
                  'OliveDrab', 'Orange', 'LightSalmon', 'Tomato', 'RosyBrown', 'Linen', 'Wheat', 'Turquoise',
                  'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal', 'MintCream', 'Chartreuse', 'OliveDrab',
                  'Goldenrod'] * 3  # 重复确保足够

        last_job_end_time = {}  # 用来记录每个机器加工的最后一个工件结束时间

        # 绘制每个工件的工序
        for i in range(self.job_num):
            for j in range(len(list_T)):
                for z in range(len(list_T[j])):
                    if list_T[j][z][0] == i:
                        ind = ga.index(j)

                        # 记录每个机器的最后一个工件的结束时间
                        if ind not in last_job_end_time or list_T[j][z][2] + list_T[j][z][3] > last_job_end_time[ind]:
                            last_job_end_time[ind] = list_T[j][z][2] + list_T[j][z][3]

                        # 绘制加工时间条
                        if ind == faulty_machine:  # 如果是故障机器
                            plt.bar(x=list_T[j][z][2], bottom=ind, height=0.5, width=list_T[j][z][3],
                                    orientation="horizontal", color=colors[i], edgecolor='black')
                        else:
                            plt.bar(x=list_T[j][z][2], bottom=ind, height=0.5, width=list_T[j][z][3],
                                    orientation="horizontal", color=colors[i], edgecolor='black')

                        plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind, '%.0f' % (i + 1), color='black',
                                 verticalalignment='top', fontsize=12, weight='bold')
                        plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind,
                                 '%.0f' % (WC_W1[i][int(list_T[j][z][1] - 1)]), color='black',
                                 verticalalignment='bottom', fontsize=12, weight='bold')

                        if list_T[j][z][4] != 0:
                            plt.bar(x=list_T[j][z][2] - list_T[j][z][4], bottom=ind + 0.3, height=0.1,
                                    width=list_T[j][z][4], orientation="horizontal", color=colors[i], edgecolor='black')

        # 绘制故障机器整行
        for ind, end_time in last_job_end_time.items():
            if ind == faulty_machine:
                # 故障时间段为最后一个工件结束后5个单位时间内
                plt.bar(x=end_time + 5, bottom=ind, height=0.5, width=C_finish - (end_time + 5),
                        orientation="horizontal",
                        color='red', edgecolor='black')  # 红色条形表示机器故障
                plt.text(end_time + 5 + (C_finish - (end_time + 5)) / 2, ind, '故障', color='white',
                         verticalalignment='center', fontsize=12, weight='bold')

        # 标记工厂
        for i in range(len(fa)):
            plt.text(C_finish + 1, tran2[i], 'FACTORY%.0f' % (i + 1), color='black', verticalalignment='center',
                     fontsize=20, weight='bold')

        # 设置坐标轴
        font1 = {'weight': 'bold', 'size': 22}  # 汉字字体大小，可以修改
        plt.xlabel("Time", font1)
        plt.ylabel("Machine", font1)
        scale_ls, index_ls = self.axis()
        tran = []
        aaa = 0
        for i in range(len(fa) - 1):
            aaa = aaa + len(fa[i])
            tran.append(aaa)
        yticks = [scale_ls[i] for i in ga]
        plt.yticks([i for i in range(0, self.machine_num)], yticks)

        # 绘制工厂分隔线
        plt.hlines([float(i - 0.5) for i in tran], 0, C_finish, color="blue")  # 横线
        plt.tick_params(labelsize=22)  # 坐标轴刻度字体大小，可以修改
        plt.plot([C_finish, C_finish], [0, tmax + 1], c='black', linestyle='-.',
                 label='Finish time=%.1f' % (C_finish))  # 用虚线画出最晚完工时间

        ax = plt.gca()
        labels = ax.get_xticklabels()
        [label.set_fontname('Times New Roman') for label in labels]
        plt.legend(prop={'family': ['SimHei'], 'size': 16})  # 标签字体大小，可以修改
        plt.xlabel("Time", font1)

        plt.savefig('GTT.png')
        plt.show()



    def draw2(self, job, machine, machine_time, trantime, Wc, WC_W1):
            # 计算相关数据
            _, _, T, M, S, W, tmmw, Wmax = self.caculate(job, machine, machine_time, trantime, Wc)
            C_finish, Twork, E_all, list_M, list_S, list_W, tmax, list_T = self.plugin(T, M, S, W, job, tmmw, trantime)

            plt.figure(figsize=(20, 10))

            fa = [[] for i in range(len(self.tran_time))]  # 工厂对应的机器列表
            for i in range(self.machine_num):
                fa[self.M_dicr[i][0] - 1].append(i)

            ga = []  # 机器显示顺序列表
            for i in range(len(fa)):
                for j in range(len(fa[i])):
                    ga.append(fa[i][j])

            # 计算工厂分隔线位置
            tran2 = [0]
            zz = 0
            for i in range(len(fa) - 1):
                zz += len(fa[i])
                tran2.append(zz)

            # 定义工件颜色列表
            colors = ['red', 'Navy', 'grey', 'yellow', 'Violet', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral',
                      'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon',
                      'Tomato', 'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue',
                      'Thistle', 'Teal', 'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod'] * 3  # 重复确保足够

            # 绘制每个工件的工序
            for i in range(self.job_num):
                for j in range(len(list_T)):
                    for z in range(len(list_T[j])):
                        if list_T[j][z][0] == i:
                            ind = ga.index(j)
                            # 绘制加工时间条
                            plt.bar(x=list_T[j][z][2], bottom=ind, height=0.5, width=list_T[j][z][3],
                                    orientation="horizontal", color=colors[i], edgecolor='black')
                            # 显示工件号
                            plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind,
                                     f'{i + 1}', color='black', verticalalignment='top',
                                     fontsize=12, weight='bold')
                            # 显示工人信息
                            plt.text(list_T[j][z][2] + list_T[j][z][3] / 32, ind,
                                     f'{WC_W1[i][int(list_T[j][z][1] - 1)]}', color='black',
                                     verticalalignment='bottom', fontsize=12, weight='bold')
                            # 绘制运输时间（如果有）
                            if list_T[j][z][4] != 0:
                                plt.bar(x=list_T[j][z][2] - list_T[j][z][4], bottom=ind + 0.3,
                                        height=0.1, width=list_T[j][z][4], orientation="horizontal",
                                        color=colors[i], edgecolor='black')

            # 标记工厂
            for i in range(len(fa)):
                plt.text(C_finish + 1, tran2[i], f'FACTORY{i + 1}', color='black',
                         verticalalignment='center', fontsize=20, weight='bold')

            # 设置坐标轴
            font1 = {'weight': 'bold', 'size': 22}
            plt.xlabel("Time", font1)
            plt.ylabel("Machine", font1)

            # 获取并调整坐标轴刻度 - 关键修改：确保machine中的0对应M1
            scale_ls, index_ls = self.axis()

            # 创建正确的机器编号映射：0->M1, 1->M2, 2->M3...
            # 直接使用ga中的原始机器编号（0,1,2...）并转换为M1,M2,M3格式
            yticks = [f'M{int(i + 1)}' for i in range(len(ga))]  # 改成依次递增的机器编号

            # 设置yticks为机器编号
            plt.yticks([i for i in range(0, self.machine_num)], yticks)

            # 绘制工厂分隔线
            plt.hlines([float(i - 0.5) for i in tran2], 0, C_finish, color="blue")

            # 设置刻度字体大小
            plt.tick_params(labelsize=22)

            # 绘制完工时间线
            plt.plot([C_finish, C_finish], [0, tmax + 1], c='black', linestyle='-.',
                     label=f'Finish time={C_finish:.1f}')

            # 设置字体
            ax = plt.gca()
            labels = ax.get_xticklabels()
            [label.set_fontname('Times New Roman') for label in labels]

            # 设置图例
            plt.legend(prop={'family': ['SimHei'], 'size': 16})
            plt.xlabel("Time", font1)

            # 保存并显示图像
            plt.savefig('GTT.png')
            plt.show()

# oj=data_deal()
# # Tmachine,Tmachinetime,tdx,work,tom=oj.cacu()
# Tmachine,Tmachinetime,tdx,work,tom,int1,int2,M,M_dicr, tran_time=oj.cacu()
# # #print(Tmachine)
# # # # # print(Tmachinetime)
# parm_data=[Tmachine,Tmachinetime,tdx,work,M_dicr, tran_time,int1]
# # # # to=FJSP(10,6,0.5,parm_data)
# # # print(parm_data)
# to=FJSP(25,10,parm_data,10)
# #
# # # #
# # # print(trantime)
# work_job, work_M, work_T, work_tran, work_F, job_init = to.creat_job()
# # print(work_job)
# for i in range(1):
# 	# print(work_job[i:i + 1], work_M[i:i + 1], work_T[i:i + 1], work_tran[i:i + 1])
# 	_, _, list_T, list_M, list_S, list_W, tmmw = to.caculate(work_job[i:i+1], work_M[i:i+1], work_T[i:i+1], work_tran[i:i+1])
# 	C_finish, Twork, E_all, _, _, _, _,list_T = to.plugin(list_T, list_M, list_S, list_W, work_job[i:i+1], tmmw,work_tran[i:i+1])
# 	print(work_job[i:i+1])
# 	print(work_M[i:i+1])
# 	print(work_T[i:i+1])
# 	to.draw(work_job[i:i+1], work_M[i:i+1], work_T[i:i+1], work_tran[i:i+1])
# 	# print(C_finish)
# # print(list_M)
# # print(job)
# # to.draw(job,machine,machine_time,trantime)


# print(C_finish)
