
from DQN_test1 import DQN_RL

from small_work import data_deal
from fjsp import FJSP
from multi_opt import mul_op

from GWO4_1 import gwo4_1
import numpy as np
import  math


def distanse(x, y):
    return math.sqrt(sum([pow(a - b, 2) for a, b in zip(x, y)]))


def get_IGD(c, a):
    # IGD=0
    # for i in range(len(c)):
    #     c1=
    # print(min([distanse(i, j) for j in a]) for i in c)
    return sum([min([distanse(i, j) for j in a]) for i in c]) #遍历所有距离


def str_to_numpy_array(str_data):
    """
    将NumPy打印格式的字符串转换为NumPy数组
    :param str_data: 如 "[[46. 50. 16. ...]]" 的字符串
    :return: numpy.ndarray
    """
    # 清理括号和空格，转换为数值列表
    clean_str = str_data.replace('[', '').replace(']', '').strip()
    if not clean_str:
        return np.array([])
    num_list = [float(x) for x in clean_str.split()]
    # 还原为二维数组（如果原始是二维）
    return np.array([num_list])

def tmain():
    oj = data_deal()
    item_ = oj.item
    job_num = item_["int2"]
    machine_num = item_["M"]


    Tmachine, Tmachinetime, tdx, work, tom, int1, int2, M, M_dicr, tran_time, worker, work_num, efficiency = oj.cacu()


    parm_data = [Tmachine, Tmachinetime, tdx, work, M_dicr, tran_time,int1,worker,work_num,efficiency]
    # to=FJSP(10,6,0.5,parm_data)      #工件数，机器数，选择最短机器的概率和mk01的数据
    to = FJSP(job_num, machine_num, parm_data,100)
    dqn = DQN_RL(Tmachine, Tmachinetime, worker,machine_num,work_num)

    oh = mul_op()
    ho = gwo4_1(100,100,to, oh, work, job_num,tran_time,M_dicr,parm_data[7])  # 数50,100,10分别代表迭代的次数、种群的规模、机器数
    work_job, work_M, work_T, work_tran, work_F, job_init, work_wc = to.creat_job()
    pareto, pareto_job,pareto_machine,pareto_time,pareto_tran,fit_every,pareto_Wc, _, hv, answer = ho.gwo_total(work_job, work_M, work_T, work_tran, work_F, job_init,
                                                             work_wc, dqn, Tmachine,Tmachinetime)

    return pareto,oh,to,pareto_job, pareto_machine, pareto_time, pareto_tran, fit_every,IGD,HV


paretoture,_,_,_,_,_,_,F,_,_=tmain()
# PFture.extend(paretoture)



