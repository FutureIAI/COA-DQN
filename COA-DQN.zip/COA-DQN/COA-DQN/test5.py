import matplotlib.pyplot as plt
import numpy as np




def str_to_numpy_array(str_data):
    """
    将NumPy打印格式的字符串转换为NumPy数组
    :param str_data: 如 "[[46. 50. 16. ...]]" 的字符串
    :return: numpy.ndarray
    """
    # 清理括号和空格，转换为数值列表
    clean_str = str_data.replace('[', '').replace(']', '').strip()
    if not clean_str:
        return np.array([])
    num_list = [float(x) for x in clean_str.split()]
    # 还原为二维数组（如果原始是二维）
    return np.array([num_list])

job = "[[1. 0. 2. 3. 1. 2. 0. 1. 0. 2. 3. 1. 1. 0. 2. 0.]]"
machine = "[[0. 1. 2. 1. 0. 1. 2. 0. 2. 0. 0. 2. 1. 0. 0. 0.]]"
machine_time = "[[46. 50. 16. 36. 73. 49. 39. 10. 37. 40. 46. 11. 12. 22. 63. 31.]]"
wc = "[[2. 1. 2. 2. 1. 1. 2. 1. 2. 1. 1. 2. 2. 2. 1. 1.]]"
WC_W = [[1.0, 2.0, 2.0, 2.0, 1.0], [2.0, 1.0, 1.0, 2.0, 2.0], [2.0, 1.0, 1.0, 1.0], [2.0, 1.0]]

job_np =str_to_numpy_array(job)
machine_np =str_to_numpy_array(machine)
machine_time_np =str_to_numpy_array(machine_time)
wc_np =str_to_numpy_array(wc)

