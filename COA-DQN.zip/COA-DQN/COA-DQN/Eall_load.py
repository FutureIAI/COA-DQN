import math

import numpy as np

class eall_load:
    def calculate_total_metrics(self, data, power_params):
        """
        计算系统的总负载和总能耗

        参数:
        data: 调度数据字典
        power_params: 机器功率参数字典

        返回:
        total_load: float, 总负载 (所有加工时间之和)
        total_energy: float, 系统总能耗 (加工能耗 + 空闲能耗)
        """
        # 1. 计算总负载 (Total Workload)
        # 即所有工序的加工时间 t 之和
        total_load = np.sum(data['t'])

        # 2. 计算每台机器的个体负载，用于计算空闲时间和能耗
        m_loads = {m: 0.0 for m in power_params.keys()}
        for m_id, duration in zip(data['m'], data['t']):
            m_id = int(m_id)
            if m_id in m_loads:
                m_loads[m_id] += duration

        # 3. 确定系统最大完工时间 (Makespan)
        makespan = max(m_loads.values()) if m_loads else 0

        # 4. 计算总能耗 (Total Energy)
        total_energy = 0.0
        for m_id, load in m_loads.items():
            p_work = power_params[m_id][1]  # 加工功率
            p_idle = power_params[m_id][2]  # 空闲功率

            # 该机器的加工能耗
            work_e = load * p_work
            # 该机器的空闲能耗 (总时间 - 加工时间)
            idle_e = (makespan - load) * p_idle

            total_energy += (work_e + idle_e)

        return total_load, total_energy

    import numpy as np
    import math

    def calculate_total_metrics1(self, data, power_params, worker_effs):
        """
        计算系统的总负载、完工时间及总能耗（考虑工人效率修正）

        参数:
        data: 调度数据字典，需包含 't'(理论加工时间), 'm'(机器ID), 'w'(工人ID)
        power_params: 机器功率参数字典 {m_id: [待机功率, 加工功率, 空闲功率]}
        worker_effs: 工人效率矩阵 (例如 worker_effs[worker_id][machine_id])

        返回:
        makespan: int, 最大完工时间
        total_load: int, 系统总负载 (考虑效率后的实际加工时间之和)
        total_energy: float, 系统总能耗 (加工能耗 + 空闲能耗)
        """

        # 1. 初始化机器负载记录 (使用整数 0 确保时间属性)
        m_loads = {m: 0 for m in power_params.keys()}
        actual_durations = []

        # 2. 计算考虑工人效率后的实际加工时间
        # 遍历每一道工序，t_base:理论时间, m_id:机器ID, w_id:工人ID
        for t_base, m_id, w_id in zip(data['t'], data['m'], data['w']):
            m_id = int(m_id)
            w_id = int(w_id)

            # 获取该工人在该机器上的效率系数
            # 注意：此处假设 worker_effs[工人ID][机器ID]
            efficiency = worker_effs[w_id][m_id]

            # 逻辑：实际加工时间 = 理论时间 * 效率，执行向上取整并转为整数
            t_actual = int(math.ceil(t_base * efficiency))
            actual_durations.append(t_actual)

            # 累加到对应机器的负载上
            if m_id in m_loads:
                m_loads[m_id] += t_actual

        # 3. 计算总负载 (Total Workload)
        # 所有修正后的实际加工时间之和
        total_load = int(sum(actual_durations))

        # 4. 确定系统最大完工时间 (Makespan)
        # 基于各机器负载的最大值（整数）
        makespan = int(max(m_loads.values())) if m_loads else 0

        # 5. 计算总能耗 (Total Energy)
        total_energy = 0.0
        for m_id, load in m_loads.items():
            # [1]是加工功率，[2]是空闲功率
            p_work = power_params[m_id][1]
            p_idle = power_params[m_id][2]

            # 该机器的加工能耗 (实际整数负载 * 加工功率)
            work_e = load * p_work
            # 该机器的空闲能耗 (总完工时间 - 实际加工时长) * 空闲功率
            idle_e = (makespan - load) * p_idle

            total_energy += (work_e + idle_e)

        # 返回完工时间、总负载、总能耗
        return makespan, total_load, total_energy


# # --- 测试数据 ---
# power_data = {
#     0: (3, 15, 2.4173149527911657),
#     1: (1, 11, 1.7455475526379913),
#     2: (2, 15, 1.5260069870528417),
#     3: (3, 11, 1.7236441596332701),
#     4: (3, 18, 2.4495542254485674),
#     5: (1, 17, 1.8146067070053364),
#     6: (1, 18, 1.8650349490212748)
# }
#
# before_failue = {
#     'j': np.array([12., 7., 11., 18., 3., 2.]),
#     'm': np.array([3., 2., 0., 4., 6., 3.]),
#     't': np.array([35., 45., 47., 38., 43., 15.]),
#     'w': np.array([3., 1., 2., 5., 4., 3.])
# }
#
# # --- 调用并输出 ---
# total_load, total_energy = calculate_total_metrics(before_failue, power_data)
#
# print(f"系统总负载: {total_load}")
# print(f"系统总能耗: {total_energy:.2f}")