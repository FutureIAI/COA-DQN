import os
from datetime import datetime

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from numpy import array

# --- 1. 原始数据 ---
before_failue =  {'j': array([12.,  7., 11., 18.,  3.,  2.]), 'm': array([3., 2., 0., 4., 6., 3.]), 't': array([35., 45., 47., 38., 43., 15.]), 'w': array([3., 1., 2., 5., 4., 3.])}
pareto_after =  {'j': array([ 7., 16.,  5., 12.,  4., 13., 17., 19.,  4., 14.,  0., 12., 15.,
        2.,  6., 11.,  3.,  7.,  9., 18., 16.,  5., 13.,  1., 16.,  6.,
        3.,  8.,  7., 16., 11., 17., 12.,  9., 14.,  5., 12., 18.,  3.,
        7., 18.,  9.,  2., 15.,  6.,  2., 10., 15., 14.,  4., 11., 14.]), 'm': array([1., 2., 5., 4., 0., 3., 3., 1., 2., 0., 2., 3., 2., 4., 2., 4., 4.,
       1., 2., 1., 3., 1., 4., 2., 4., 4., 5., 0., 4., 2., 4., 1., 2., 1.,
       2., 4., 2., 4., 3., 3., 4., 3., 2., 5., 4., 5., 0., 3., 0., 0., 2.,
       0.]), 't': array([17., 35., 13., 12., 25., 33., 12., 35., 29., 13., 17., 35., 30.,
       25., 22., 10., 17., 20., 17., 16., 36., 23., 44., 14., 10., 30.,
       10., 38., 23., 22., 47., 20., 11., 10., 17., 17., 20., 10., 20.,
       24., 36., 23., 31., 38., 14., 24., 21., 12., 15., 23., 18., 18.]), 'w': array([5., 4., 2., 1., 5., 3., 3., 2., 4., 1., 4., 2., 4., 1., 1., 1., 3.,
       2., 4., 2., 2., 5., 5., 3., 1., 1., 3., 1., 5., 4., 1., 4., 1., 3.,
       3., 5., 3., 1., 1., 3., 1., 3., 1., 3., 3., 2., 2., 2., 5., 5., 4.,
       5.])}

# 用户指定颜色列表


# FAULT_TIME = 50
# BROKEN_M_IDX = 6  # 对应显示中的 M7


def draw_dual_resource_gantt(before, after,BROKEN_M_IDX = 6, FAULT_TIME = 50):
    colors_pool = ['red', 'Violet', 'grey', 'yellow', 'Navy', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral',
                   'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon', 'Tomato',
                   'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal',
                   'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod', 'red', 'Navy', 'grey', 'yellow', 'Violet',
                   'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral', 'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen',
                   'OliveDrab', 'Orange', 'LightSalmon', 'Tomato', 'RosyBrown', 'Linen', 'Wheat', 'Turquoise',
                   'PowderBlue',
                   'CornflowerBlue', 'Thistle', 'Teal', 'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod']
    # 确定资源范围
    num_m = int(max(np.max(before['m']), np.max(after['m']))) + 1
    # 工人数据本身是从1开始的，所以最大值即为工人总数
    max_w_id = int(max(np.max(before['w']), np.max(after['w'])))

    # 初始化空闲时间追踪
    m_free = {m: 0 for m in range(num_m)}
    j_free = {}
    w_free = {w: 0 for w in range(1, max_w_id + 1)}  # 工人追踪器从1开始

    tasks = []

    # 1. 计算故障前工序 (同时受机器、工件顺序、工人可用性约束)
    for i in range(len(before['j'])):
        job, m, t, w = int(before['j'][i]), int(before['m'][i]), before['t'][i], int(before['w'][i])
        start = max(m_free[m], j_free.get(job, 0), w_free[w])
        end = start + t
        tasks.append({'m': m, 's': start, 'e': end, 'j': job, 'w': w})
        # 更新三个资源的释放时间
        m_free[m] = end
        j_free[job] = end
        w_free[w] = end

    # 机器6 (M7) 故障：在50之后不可用
    m_free[BROKEN_M_IDX] = 999999

    # 2. 计算故障后重调度工序
    for i in range(len(after['j'])):
        job, m, t, w = int(after['j'][i]), int(after['m'][i]), after['t'][i], int(after['w'][i])
        # 重调度工序起始点：max(机器空闲, 工件空闲, 工人空闲, 故障时刻50)
        start = max(m_free[m], j_free.get(job, 0), w_free[w], FAULT_TIME)
        end = start + t
        tasks.append({'m': m, 's': start, 'e': end, 'j': job, 'w': w})
        m_free[m] = end
        j_free[job] = end
        w_free[w] = end

    makespan = max([tk['e'] for tk in tasks])

    # 3. 绘图
    plt.figure(figsize=(15, 8))
    plt.rcParams['axes.unicode_minus'] = False

    # 确保同一工件颜色相同
    unique_jobs = sorted(list(set(np.concatenate([before['j'], after['j']]))))
    job_colors = {int(job): colors_pool[i % len(colors_pool)] for i, job in enumerate(unique_jobs)}

    for tk in tasks:
        m_label = tk['m'] + 1
        j_label = tk['j'] + 1
        w_label = tk['w']  # 原始数据就是从1开始，不加1
        dur = tk['e'] - tk['s']

        plt.barh(m_label, dur, left=tk['s'], color=job_colors[tk['j']],
                 edgecolor='black', alpha=0.8, linewidth=0.6)

        # 内部数字标注：上方工人编号，下方工件编号
        plt.text(tk['s'] + dur / 2, m_label + 0.15, f"{w_label}", va='center', ha='center', fontsize=12,
                 fontweight='bold')
        plt.text(tk['s'] + dur / 2, m_label - 0.15, f"{j_label}", va='center', ha='center', fontsize=12)

    # 4. 故障背景标注
    plt.barh(BROKEN_M_IDX + 1, makespan - FAULT_TIME, left=FAULT_TIME, color='red', alpha=0.15, hatch='///')
    plt.axvline(x=FAULT_TIME, color='red', linestyle='--', linewidth=2)

    # 5. 坐标轴与Makespan图注
    plt.yticks(range(1, num_m + 1), [f"M{i}" for i in range(1, num_m + 1)])
    plt.xlabel("Time")
    plt.ylabel("Machine")


    # 核心：图注仅显示最大完工时间
    makespan_legend = [Line2D([0], [0], color='white', label=f'Makespan: {makespan:.1f}')]
    plt.legend(handles=makespan_legend, loc='upper right', handlelength=0, fontsize=12)

    plt.grid(axis='x', linestyle=':', alpha=0.5)
    plt.tight_layout()
    plt.show()


# 执行绘图
draw_dual_resource_gantt(before_failue, pareto_after)

import matplotlib.pyplot as plt
import numpy as np

# --- 配置中文字体，确保“故障”二字能正常显示 ---
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


def plot_failure_gantt(data, FAULT_MACHINE_ID=6, FAULT_START=50, FAULT_DURATION=80):
    import matplotlib.pyplot as plt
    import numpy as np
    import os
    from datetime import datetime
    from matplotlib.lines import Line2D

    # 设置中文字体
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False

    COLORS = ['red', 'Violet', 'grey', 'yellow', 'Navy', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral',
              'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon', 'Tomato',
              'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal',
              'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod']

    FAULT_END = FAULT_START + FAULT_DURATION
    j_arr, m_arr, t_arr, w_arr = data['j'], data['m'], data['t'], data['w']

    num_m = int(np.max(m_arr) + 1)
    max_w = int(np.max(w_arr))
    m_free = {m: 0 for m in range(num_m)}
    w_free = {w: 0 for w in range(1, max_w + 1)}
    j_free = {}

    gantt_tasks = []

    for i in range(len(j_arr)):
        job, m, dur, worker = int(j_arr[i]), int(m_arr[i]), t_arr[i], int(w_arr[i])

        # 基础开始时间：机器、工件、工人都准备好
        start = max(m_free[m], j_free.get(job, 0), w_free[worker])

        # --- 核心逻辑修改点：确保故障机器在故障期间完全排空 ---
        if m == FAULT_MACHINE_ID:
            # 如果该工序计划在故障结束前完成，且会进入故障时间段
            # 或者该工序本来就计划在故障期间开始
            if start < FAULT_END and (start + dur) > FAULT_START:
                # 强制右移：该工序必须等机器修好（FAULT_END）后才能开始
                start = max(start, FAULT_END)

        end = start + dur
        gantt_tasks.append({'m': m, 's': start, 'e': end, 'j': job, 'w': worker, 'd': dur})

        # 更新资源释放时刻（这会产生连锁反应，推迟后续工序）
        m_free[m] = end
        j_free[job] = end
        w_free[worker] = end

    # 计算最大完工时间（包含推迟后的）
    makespan = max([t['e'] for t in gantt_tasks])

    plt.figure(figsize=(14, 7))
    unique_jobs = sorted(list(set(j_arr)))
    job_colors = {int(job): COLORS[i % len(COLORS)] for i, job in enumerate(unique_jobs)}

    # 绘制工序块
    for t in gantt_tasks:
        m_label = t['m'] + 1
        j_num, w_num = int(t['j']) + 1, int(t['w'])

        plt.barh(m_label, t['d'], left=t['s'],
                 color=job_colors[t['j']], edgecolor='black', alpha=0.8, linewidth=0.5)

        # 内部数字：上方工人(1-indexed), 下方工件(1-indexed)
        plt.text(t['s'] + t['d'] / 2, m_label + 0.18, f"{w_num}",
                 va='center', ha='center', fontsize=10, fontweight='bold')
        plt.text(t['s'] + t['d'] / 2, m_label - 0.18, f"{j_num}",
                 va='center', ha='center', fontsize=10)

    # --- 绘制故障区域 ---
    plt.barh(FAULT_MACHINE_ID + 1, FAULT_DURATION, left=FAULT_START,
             color='red', alpha=0.4, hatch='///', edgecolor='red')

    plt.text(FAULT_START + FAULT_DURATION / 2, FAULT_MACHINE_ID + 1, "故障",
             va='center', ha='center', fontsize=12, color='white', fontweight='bold',
             bbox=dict(facecolor='red', alpha=0.6, edgecolor='none', boxstyle='round,pad=0.2'))

    # 绘制故障时间轴辅助线
    plt.axvline(x=FAULT_START, color='red', linestyle='--', linewidth=1.5)
    plt.axvline(x=FAULT_END, color='red', linestyle='--', linewidth=1.5)

    # --- 坐标轴设置 ---
    plt.xlim(0, makespan + 10)

    # 强制在X轴显示故障的起止时刻
    xticks = list(plt.xticks()[0])
    xticks.extend([FAULT_START, FAULT_END])
    plt.xticks(sorted(list(set(xticks))))
    # 图注：仅显示 Makespan
    makespan_legend = [Line2D([0], [0], color='white', label=f'Makespan: {makespan:.1f}')]
    plt.legend(handles=makespan_legend, loc='upper right', handlelength=0, fontsize=12)

    # 突出显示故障时刻的标签颜色
    ax = plt.gca()
    for tick in ax.get_xticklabels():
        try:
            val = float(tick.get_text())
            if val == FAULT_START or val == FAULT_END:
                tick.set_color('red')
                tick.set_fontweight('bold')
        except:
            pass

    plt.yticks(range(1, num_m + 1), [f"M{i}" for i in range(1, num_m + 1)])
    plt.xlabel("时间 (Time)")
    plt.ylabel("机器 (Machines)")
    # plt.title(f"机器故障重调度甘特图 | Makespan: {makespan:.1f}", fontsize=14)

    # 保存图片
    base_dir = os.path.dirname(os.path.abspath(__file__))
    save_folder = os.path.join(base_dir, "重调度甘特图")
    if not os.path.exists(save_folder):
        os.makedirs(save_folder)

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'Gantt_Failure_{timestamp}.png'
    filepath = os.path.join(save_folder, filename)

    plt.grid(axis='x', linestyle=':', alpha=0.5)
    plt.tight_layout()
    plt.savefig(filepath, bbox_inches='tight', dpi=300)
    plt.show()
    plt.close()


# --- 数据 ---
orig_arrays = {
    'j': np.array(
        [4, 18, 9, 16, 6, 12, 11, 15, 5, 11, 2, 9, 8, 2, 13, 16, 15, 14, 3, 12, 3, 7, 5, 12, 17, 6, 18, 11, 4, 14, 19,
         18, 10, 15, 2, 7, 5, 16, 14, 17, 7, 3, 11, 18, 2, 1, 16, 7, 3, 9, 0, 14, 12, 7, 4, 6, 13, 12]),
    'm': np.array(
        [0, 1, 2, 2, 6, 4, 3, 1, 6, 4, 3, 0, 2, 4, 6, 1, 5, 0, 2, 4, 0, 5, 1, 6, 3, 4, 6, 5, 2, 6, 1, 4, 3, 6, 2, 1, 4,
         4, 0, 6, 1, 5, 2, 6, 5, 2, 1, 4, 3, 6, 2, 4, 5, 3, 5, 4, 6, 2]),
    't': np.array(
        [25, 19, 17, 35, 14, 30, 12, 37, 12, 10, 15, 17, 35, 25, 19, 35, 38, 13, 19, 12, 19, 43, 23, 10, 12, 30, 10, 47,
         29, 24, 35, 10, 11, 13, 31, 17, 17, 10, 15, 11, 20, 10, 18, 14, 24, 14, 10, 23, 20, 12, 17, 26, 14, 24, 15, 14,
         27, 20]),
    'w': np.array(
        [5, 2, 4, 4, 5, 1, 3, 3, 4, 5, 1, 5, 1, 3, 5, 4, 2, 5, 3, 1, 1, 2, 3, 4, 2, 5, 4, 2, 1, 4, 3, 3, 1, 5, 4, 3, 1,
         1, 5, 5, 3, 2, 1, 5, 2, 1, 4, 5, 1, 4, 4, 5, 2, 2, 3, 5, 4, 1])
}

plot_failure_gantt(orig_arrays)

import matplotlib.pyplot as plt
import numpy as np
import os
from datetime import datetime
from matplotlib.lines import Line2D

# 解决负号和中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


def plot_original_gantt(data):
    """
    绘制原始甘特图（无故障）
    """
    COLORS = ['red', 'Violet', 'grey', 'yellow', 'Navy', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral',
              'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon', 'Tomato',
              'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal',
              'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod']

    j_arr, m_arr, t_arr, w_arr = data['j'], data['m'], data['t'], data['w']

    # 1. 资源追踪初始化
    num_m = int(np.max(m_arr) + 1)
    max_w = int(np.max(w_arr))
    m_free = {m: 0 for m in range(num_m)}
    w_free = {w: 0 for w in range(1, max_w + 1)}  # 原始数据工人从1开始
    j_free = {}

    gantt_tasks = []

    # 2. 模拟正常排产逻辑
    for i in range(len(j_arr)):
        job, m, dur, worker = int(j_arr[i]), int(m_arr[i]), t_arr[i], int(w_arr[i])

        # 核心逻辑：机器、工件工序、工人三方同时空闲才开始
        start = max(m_free[m], j_free.get(job, 0), w_free[worker])
        end = start + dur

        gantt_tasks.append({'m': m, 's': start, 'e': end, 'j': job, 'w': worker, 'd': dur})

        # 更新状态
        m_free[m] = end
        j_free[job] = end
        w_free[worker] = end

    # 计算最大完工时间
    makespan = max([t['e'] for t in gantt_tasks])

    # 3. 绘图配置
    plt.figure(figsize=(14, 7))
    unique_jobs = sorted(list(set(j_arr)))
    job_colors = {int(job): COLORS[i % len(COLORS)] for i, job in enumerate(unique_jobs)}

    # 图注：仅显示 Makespan
    makespan_legend = [Line2D([0], [0], color='white', label=f'Original Makespan: {makespan:.1f}')]
    plt.legend(handles=makespan_legend, loc='upper right', handlelength=0, fontsize=12)

    for t in gantt_tasks:
        m_label = t['m'] + 1
        j_num, w_num = int(t['j']) + 1, int(t['w'])  # 工件+1转1-indexed，工人保持原样

        plt.barh(m_label, t['d'], left=t['s'],
                 color=job_colors[t['j']], edgecolor='black', alpha=0.8, linewidth=0.5)

        # 内部数字标注：上方工人，下方工件
        plt.text(t['s'] + t['d'] / 2, m_label + 0.18, f"{w_num}",
                 va='center', ha='center', fontsize=12, fontweight='bold')
        plt.text(t['s'] + t['d'] / 2, m_label - 0.18, f"{j_num}",
                 va='center', ha='center', fontsize=12)

    # 4. 坐标轴及布局优化
    plt.xlim(0, makespan + 5)  # 消除右侧空白
    plt.yticks(range(1, num_m + 1), [f"M{i}" for i in range(1, num_m + 1)])
    plt.xlabel("时间 (Time)")
    plt.ylabel("机器 (Machines)")
    # plt.title("原始生产调度甘特图", fontsize=14)
    plt.grid(axis='x', linestyle=':', alpha=0.5)
    plt.tight_layout()

    # 5. 自动保存路径处理
    base_dir = os.path.dirname(os.path.abspath(__file__))
    save_folder = os.path.join(base_dir, "重调度甘特图")
    if not os.path.exists(save_folder):
        os.makedirs(save_folder)

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'Gantt_Failure_{timestamp}.png'
    filepath = os.path.join(save_folder, filename)

    # 6. 保存与展示
    plt.savefig(filepath, bbox_inches='tight', dpi=300)
    plt.show()
    plt.close()
    print(f"原始甘特图已保存至: {filepath}")

# --- 调用 ---
plot_original_gantt(orig_arrays)