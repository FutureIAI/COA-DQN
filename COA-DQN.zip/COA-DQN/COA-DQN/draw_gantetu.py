import os
from datetime import datetime

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from numpy import array

class draw_gantetu:
    import numpy as np
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    import os
    from datetime import datetime

    import numpy as np
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    import os
    from datetime import datetime

    def draw_dual_resource_gantt(self, before, after, BROKEN_M_IDX=6, FAULT_TIME=50):
        colors_pool = ['red', 'Violet', 'grey', 'yellow', 'Navy', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral',
                       'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon',
                       'Tomato', 'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle',
                       'Teal', 'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod', 'red', 'Navy', 'grey', 'yellow']

        # 确定资源范围
        num_m = int(max(np.max(before['m']), np.max(after['m']))) + 1
        max_w_id = int(max(np.max(before['w']), np.max(after['w'])))

        # 初始化空闲时间追踪
        m_free = {m: 0 for m in range(num_m)}
        j_free = {}
        w_free = {w: 0 for w in range(1, max_w_id + 1)}

        tasks = []

        # 1. 计算故障前工序 (仅保留在故障时刻前已经开始的任务)
        for i in range(len(before['j'])):
            job, m, t, w = int(before['j'][i]), int(before['m'][i]), before['t'][i], int(before['w'][i])
            start = max(m_free[m], j_free.get(job, 0), w_free[w])

            # 核心逻辑：如果原计划的工序在故障时还没开始，则不绘制，由重调度接管
            if start >= FAULT_TIME:
                continue

            end = start + t
            tasks.append({'m': m, 's': start, 'e': end, 'j': job, 'w': w})

            # 更新释放时间
            m_free[m] = end
            j_free[job] = end
            w_free[w] = end

        # --- 重调度准备阶段 ---
        # 核心逻辑：将所有资源的可用时间至少推移到 FAULT_TIME，确保 after 任务不早产
        for m in range(num_m):
            m_free[m] = max(m_free[m], FAULT_TIME)
        for w in w_free:
            w_free[w] = max(w_free[w], FAULT_TIME)
        for j in j_free:
            j_free[j] = max(j_free[j], FAULT_TIME)

        # 故障机器封锁：在故障时刻后不可用
        m_free[BROKEN_M_IDX] = 999999

        # 2. 计算故障后重调度工序 (完全来自 after 参数)
        for i in range(len(after['j'])):
            job, m, t, w = int(after['j'][i]), int(after['m'][i]), after['t'][i], int(after['w'][i])

            # 起始点：max(机器, 工件, 工人, FAULT_TIME)。注意：j_free.get(job, FAULT_TIME) 处理新出现的工件
            start = max(m_free[m], j_free.get(job, FAULT_TIME), w_free[w])
            end = start + t

            tasks.append({'m': m, 's': start, 'e': end, 'j': job, 'w': w})

            m_free[m] = end
            j_free[job] = end
            w_free[w] = end

        # 计算总完工时间 (剔除封锁机器的极大值)
        makespan = max([tk['e'] for tk in tasks if tk['e'] < 999999])

        # 3. 绘图
        plt.figure(figsize=(15, 8))
        plt.rcParams['axes.unicode_minus'] = False

        unique_jobs = sorted(list(set(np.concatenate([before['j'], after['j']]))))
        job_colors = {int(job): colors_pool[i % len(colors_pool)] for i, job in enumerate(unique_jobs)}

        for tk in tasks:
            m_label = tk['m'] + 1
            j_label = tk['j'] + 1
            w_label = tk['w']
            dur = tk['e'] - tk['s']

            plt.barh(m_label, dur, left=tk['s'], color=job_colors[tk['j']],
                     edgecolor='black', alpha=0.8, linewidth=0.6)

            plt.text(tk['s'] + dur / 2, m_label + 0.15, f"{w_label}", va='center', ha='center', fontsize=14,
                     fontweight='bold')
            plt.text(tk['s'] + dur / 2, m_label - 0.15, f"{j_label}", va='center', ha='center', fontsize=14)

        # 4. 故障背景标注
        plt.barh(BROKEN_M_IDX + 1, makespan - FAULT_TIME, left=FAULT_TIME, color='red', alpha=0.15, hatch='///')
        plt.axvline(x=FAULT_TIME, color='red', linestyle='--', linewidth=2)
        plt.text(FAULT_TIME, num_m + 0.5, 'Fault Time', color='red', ha='center')

        # 5. 坐标轴与图注
        plt.yticks(range(1, num_m + 1), [f"M{i}" for i in range(1, num_m + 1)], fontsize=16)
        plt.xlabel("Time")
        plt.xticks(fontsize=16)
        plt.ylabel("Machine")

        makespan_legend = [Line2D([0], [0], color='white', label=f'Makespan: {makespan:.1f}')]
        plt.legend(handles=makespan_legend, loc='upper right', handlelength=0, fontsize=14)

        plt.grid(axis='x', linestyle=':', alpha=0.5)
        plt.tight_layout()

        # 保存文件
        base_dir = os.path.dirname(os.path.abspath(__file__))
        save_folder = os.path.join(base_dir, "重调度甘特图1")
        if not os.path.exists(save_folder):
            os.makedirs(save_folder)

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'Gantt_All_{timestamp}.png'
        filepath = os.path.join(save_folder, filename)
        plt.savefig(filepath, bbox_inches='tight', dpi=300)
        plt.close()
    def plot_failure_gantt(self, data, FAULT_MACHINE_ID=6, FAULT_START=50, FAULT_DURATION=30):
        import matplotlib.pyplot as plt
        import numpy as np
        import os
        from datetime import datetime
        from matplotlib.lines import Line2D

        # 设置中文字体
        plt.rcParams['font.sans-serif'] = ['SimHei']
        plt.rcParams['axes.unicode_minus'] = False

        COLORS = ['red', 'Violet', 'grey', 'yellow', 'Navy', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral',
                  'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon', 'Tomato',
                  'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal',
                  'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod']

        FAULT_END = FAULT_START + FAULT_DURATION
        j_arr, m_arr, t_arr, w_arr = data['j'], data['m'], data['t'], data['w']

        num_m = int(np.max(m_arr) + 1)
        max_w = int(np.max(w_arr))
        m_free = {m: 0 for m in range(num_m)}
        w_free = {w: 0 for w in range(1, max_w + 1)}
        j_free = {}

        gantt_tasks = []

        for i in range(len(j_arr)):
            job, m, dur, worker = int(j_arr[i]), int(m_arr[i]), t_arr[i], int(w_arr[i])

            # 基础开始时间：机器、工件、工人都准备好
            start = max(m_free[m], j_free.get(job, 0), w_free[worker])

            # --- 核心逻辑修改点：确保故障机器在故障期间完全排空 ---
            if m == FAULT_MACHINE_ID:
                # 如果该工序计划在故障结束前完成，且会进入故障时间段
                # 或者该工序本来就计划在故障期间开始
                if start < FAULT_END and (start + dur) > FAULT_START:
                    # 强制右移：该工序必须等机器修好（FAULT_END）后才能开始
                    start = max(start, FAULT_END)

            end = start + dur
            gantt_tasks.append({'m': m, 's': start, 'e': end, 'j': job, 'w': worker, 'd': dur})

            # 更新资源释放时刻（这会产生连锁反应，推迟后续工序）
            m_free[m] = end
            j_free[job] = end
            w_free[worker] = end

        # 计算最大完工时间（包含推迟后的）
        makespan = max([t['e'] for t in gantt_tasks])

        plt.figure(figsize=(14, 7))
        unique_jobs = sorted(list(set(j_arr)))
        job_colors = {int(job): COLORS[i % len(COLORS)] for i, job in enumerate(unique_jobs)}
        # 图注：仅显示 Makespan
        makespan_legend = [Line2D([0], [0], color='white', label=f'Makespan: {makespan:.1f}')]
        plt.legend(handles=makespan_legend, loc='upper right', handlelength=0, fontsize=14)
        # 绘制工序块
        for t in gantt_tasks:
            m_label = t['m'] + 1
            j_num, w_num = int(t['j']) + 1, int(t['w'])

            plt.barh(m_label, t['d'], left=t['s'],
                     color=job_colors[t['j']], edgecolor='black', alpha=0.8, linewidth=0.5)

            # 内部数字：上方工人(1-indexed), 下方工件(1-indexed)
            plt.text(t['s'] + t['d'] / 2, m_label + 0.18, f"{w_num}",
                     va='center', ha='center', fontsize=14, fontweight='bold')
            plt.text(t['s'] + t['d'] / 2, m_label - 0.18, f"{j_num}",
                     va='center', ha='center', fontsize=14)

        # --- 绘制故障区域 ---
        plt.barh(FAULT_MACHINE_ID + 1, FAULT_DURATION, left=FAULT_START,
                 color='red', alpha=0.4, hatch='///', edgecolor='red')

        plt.text(FAULT_START + FAULT_DURATION / 2, FAULT_MACHINE_ID + 1, "故障",
                 va='center', ha='center', fontsize=14, color='white', fontweight='bold',
                 bbox=dict(facecolor='red', alpha=0.6, edgecolor='none', boxstyle='round,pad=0.2'))

        # 绘制故障时间轴辅助线
        plt.axvline(x=FAULT_START, color='red', linestyle='--', linewidth=1.5)
        plt.axvline(x=FAULT_END, color='red', linestyle='--', linewidth=1.5)

        # --- 坐标轴设置 ---
        plt.xlim(0, makespan + 10)

        # 强制在X轴显示故障的起止时刻
        xticks = list(plt.xticks()[0])
        xticks.extend([FAULT_START, FAULT_END])
        plt.xticks(sorted(list(set(xticks))))

        # 突出显示故障时刻的标签颜色
        ax = plt.gca()
        for tick in ax.get_xticklabels():
            try:
                val = float(tick.get_text())
                if val == FAULT_START or val == FAULT_END:
                    tick.set_color('red')
                    tick.set_fontweight('bold')
            except:
                pass

        plt.yticks(range(1, num_m + 1), [f"M{i}" for i in range(1, num_m + 1)], fontsize=16)
        plt.xlabel("时间 (Time)")
        plt.xticks(fontsize=16)
        plt.ylabel("机器 (Machines)")
        # plt.title(f"机器故障重调度甘特图 | Makespan: {makespan:.1f}", fontsize=14)

        # 保存图片
        base_dir = os.path.dirname(os.path.abspath(__file__))
        save_folder = os.path.join(base_dir, "重调度甘特图1")
        if not os.path.exists(save_folder):
            os.makedirs(save_folder)

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'Gantt_right_{timestamp}.png'
        filepath = os.path.join(save_folder, filename)

        plt.grid(axis='x', linestyle=':', alpha=0.5)
        plt.tight_layout()
        plt.savefig(filepath, bbox_inches='tight', dpi=300)
        # plt.show()
        plt.close()
        return makespan

    def plot_failure_gantt_list(self, data, FAULT_MACHINE_IDS=[6], FAULT_STARTS=[50], FAULT_DURATIONS=[30]):
        import matplotlib.pyplot as plt
        import numpy as np
        import os
        from datetime import datetime
        from matplotlib.lines import Line2D

        # 设置中文字体
        plt.rcParams['font.sans-serif'] = ['SimHei']
        plt.rcParams['axes.unicode_minus'] = False

        COLORS = ['red', 'Violet', 'grey', 'yellow', 'Navy', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral',
                  'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon', 'Tomato',
                  'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal',
                  'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod']

        # 将故障信息转为列表处理（以防传入单值）
        f_m_ids = list(FAULT_MACHINE_IDS)
        f_starts = list(FAULT_STARTS)
        f_durs = list(FAULT_DURATIONS)
        f_ends = [s + d for s, d in zip(f_starts, f_durs)]

        j_arr, m_arr, t_arr, w_arr = data['j'], data['m'], data['t'], data['w']

        num_m = int(np.max(m_arr) + 1)
        max_w = int(np.max(w_arr))
        m_free = {m: 0 for m in range(num_m)}
        w_free = {w: 0 for w in range(1, max_w + 1)}
        j_free = {}

        gantt_tasks = []

        for i in range(len(j_arr)):
            job, m, dur, worker = int(j_arr[i]), int(m_arr[i]), t_arr[i], int(w_arr[i])

            # 基础开始时间：机器、工件、工人都准备好
            start = max(m_free[m], j_free.get(job, 0), w_free[worker])

            # --- 核心逻辑修改点：多故障机器区间检测 ---
            # 使用循环检测，因为右移后可能进入另一个故障区间
            moved = True
            while moved:
                moved = False
                for f_idx in range(len(f_m_ids)):
                    if m == f_m_ids[f_idx]:
                        f_s = f_starts[f_idx]
                        f_e = f_ends[f_idx]
                        # 判定重叠：任务在故障结束前必须开始，且在故障开始后才能结束
                        if start < f_e and (start + dur) > f_s:
                            new_start = max(start, f_e)
                            if new_start != start:
                                start = new_start
                                moved = True  # 标记发生了移动，重新检查所有故障区间

            end = start + dur
            gantt_tasks.append({'m': m, 's': start, 'e': end, 'j': job, 'w': worker, 'd': dur})

            # 更新资源释放时刻
            m_free[m] = end
            j_free[job] = end
            w_free[worker] = end

        # 计算最大完工时间
        makespan = max([t['e'] for t in gantt_tasks])

        plt.figure(figsize=(14, 7))
        unique_jobs = sorted(list(set(j_arr)))
        job_colors = {int(job): COLORS[i % len(COLORS)] for i, job in enumerate(unique_jobs)}

        # 图注
        makespan_legend = [Line2D([0], [0], color='white', label=f'Makespan: {makespan:.1f}')]
        plt.legend(handles=makespan_legend, loc='upper right', handlelength=0, fontsize=14)

        # 绘制工序块
        for t in gantt_tasks:
            m_label = t['m'] + 1
            j_num, w_num = int(t['j']) + 1, int(t['w'])

            plt.barh(m_label, t['d'], left=t['s'],
                     color=job_colors[t['j']], edgecolor='black', alpha=0.8, linewidth=0.5)

            plt.text(t['s'] + t['d'] / 2, m_label + 0.18, f"{w_num}",
                     va='center', ha='center', fontsize=14, fontweight='bold')
            plt.text(t['s'] + t['d'] / 2, m_label - 0.18, f"{j_num}",
                     va='center', ha='center', fontsize=14)

        # --- 绘制所有故障区域 ---
        for f_idx in range(len(f_m_ids)):
            f_m = f_m_ids[f_idx]
            f_s = f_starts[f_idx]
            f_d = f_durs[f_idx]
            f_e = f_ends[f_idx]

            plt.barh(f_m + 1, f_d, left=f_s,
                     color='red', alpha=0.4, hatch='///', edgecolor='red')

            plt.text(f_s + f_d / 2, f_m + 1, "故障",
                     va='center', ha='center', fontsize=14, color='white', fontweight='bold',
                     bbox=dict(facecolor='red', alpha=0.6, edgecolor='none', boxstyle='round,pad=0.2'))

            # 绘制辅助线
            plt.axvline(x=f_s, color='red', linestyle='--', linewidth=1.2, alpha=0.6)
            plt.axvline(x=f_e, color='red', linestyle='--', linewidth=1.2, alpha=0.6)

        # --- 坐标轴设置 ---
        plt.xlim(0, makespan + 10)

        # 处理 X 轴刻度，添加故障点
        xticks = list(plt.xticks()[0])
        xticks.extend(f_starts)
        xticks.extend(f_ends)
        plt.xticks(sorted(list(set(xticks))),fontsize=16)

        # 突出显示故障时刻标签颜色
        ax = plt.gca()
        fault_points = set(f_starts) | set(f_ends)
        for tick in ax.get_xticklabels():
            try:
                val = float(tick.get_text())
                if any(abs(val - p) < 1e-5 for p in fault_points):
                    tick.set_color('red')
                    tick.set_fontweight('bold')
            except:
                pass

        plt.yticks(range(1, num_m + 1), [f"M{i}" for i in range(1, num_m + 1)], fontsize=16)
        plt.xlabel("时间 (Time)")
        plt.xticks(fontsize=16)
        plt.ylabel("机器 (Machines)")

        # 保存图片逻辑
        base_dir = os.path.dirname(os.path.abspath(__file__))
        save_folder = os.path.join(base_dir, "重调度甘特图1")
        if not os.path.exists(save_folder):
            os.makedirs(save_folder)

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'Gantt_multi_fault_{timestamp}.png'
        filepath = os.path.join(save_folder, filename)

        plt.grid(axis='x', linestyle=':', alpha=0.5)
        plt.tight_layout()
        plt.savefig(filepath, bbox_inches='tight', dpi=300)
        plt.close()
        return makespan
    def plot_original_gantt(self, data):
        """
        绘制原始甘特图（无故障）
        """
        COLORS = ['red', 'Violet', 'grey', 'yellow', 'Navy', 'Cyan', 'Green', 'LightYellow', 'Tan', 'Coral',
                  'SlateBlue', 'DeepSkyBlue', 'DarkCyan', 'SeaGreen', 'OliveDrab', 'Orange', 'LightSalmon', 'Tomato',
                  'RosyBrown', 'Linen', 'Wheat', 'Turquoise', 'PowderBlue', 'CornflowerBlue', 'Thistle', 'Teal',
                  'MintCream', 'Chartreuse', 'OliveDrab', 'Goldenrod']

        j_arr, m_arr, t_arr, w_arr = data['j'], data['m'], data['t'], data['w']

        # 1. 资源追踪初始化
        num_m = int(np.max(m_arr) + 1)
        max_w = int(np.max(w_arr))
        m_free = {m: 0 for m in range(num_m)}
        w_free = {w: 0 for w in range(1, max_w + 1)}  # 原始数据工人从1开始
        j_free = {}

        gantt_tasks = []

        # 2. 模拟正常排产逻辑
        for i in range(len(j_arr)):
            job, m, dur, worker = int(j_arr[i]), int(m_arr[i]), t_arr[i], int(w_arr[i])

            # 核心逻辑：机器、工件工序、工人三方同时空闲才开始
            start = max(m_free[m], j_free.get(job, 0), w_free[worker])
            end = start + dur

            gantt_tasks.append({'m': m, 's': start, 'e': end, 'j': job, 'w': worker, 'd': dur})

            # 更新状态
            m_free[m] = end
            j_free[job] = end
            w_free[worker] = end

        # 计算最大完工时间
        makespan = max([t['e'] for t in gantt_tasks])

        # 3. 绘图配置
        plt.figure(figsize=(14, 7))
        unique_jobs = sorted(list(set(j_arr)))
        job_colors = {int(job): COLORS[i % len(COLORS)] for i, job in enumerate(unique_jobs)}

        # 图注：仅显示 Makespan
        makespan_legend = [Line2D([0], [0], color='white', label=f'Makespan: {makespan:.1f}')]
        plt.legend(handles=makespan_legend, loc='upper right', handlelength=0, fontsize=14)

        for t in gantt_tasks:
            m_label = t['m'] + 1
            j_num, w_num = int(t['j']) + 1, int(t['w'])  # 工件+1转1-indexed，工人保持原样

            plt.barh(m_label, t['d'], left=t['s'],
                     color=job_colors[t['j']], edgecolor='black', alpha=0.8, linewidth=0.5)

            # 内部数字标注：上方工人，下方工件
            plt.text(t['s'] + t['d'] / 2, m_label + 0.18, f"{w_num}",
                     va='center', ha='center', fontsize=14, fontweight='bold')
            plt.text(t['s'] + t['d'] / 2, m_label - 0.18, f"{j_num}",
                     va='center', ha='center', fontsize=14)

        # 4. 坐标轴及布局优化
        plt.xlim(0, makespan + 5)  # 消除右侧空白
        plt.yticks(range(1, num_m + 1), [f"M{i}" for i in range(1, num_m + 1)], fontsize=16)
        plt.xticks(fontsize=16)
        plt.xlabel("Time")
        plt.ylabel("Machines")
        # plt.title("原始生产调度甘特图", fontsize=14)
        plt.grid(axis='x', linestyle=':', alpha=0.5)
        plt.tight_layout()

        # 5. 自动保存路径处理
        base_dir = os.path.dirname(os.path.abspath(__file__))
        save_folder = os.path.join(base_dir, "重调度甘特图2")
        if not os.path.exists(save_folder):
            os.makedirs(save_folder)

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'Gantt_{timestamp}.png'
        filepath = os.path.join(save_folder, filename)

        # 6. 保存与展示
        plt.savefig(filepath, bbox_inches='tight', dpi=300)
        # plt.show()
        plt.close()
        print(f"原始甘特图已保存至: {filepath}")

