
from DQN_test1 import DQN_RL


from GWO4_1_reSchedule import gwo4_1_schedule

from small_work import data_deal
from fjsp import FJSP
from multi_opt import mul_op

import  math

def distanse(x, y):
    return math.sqrt(sum([pow(a - b, 2) for a, b in zip(x, y)]))


def get_IGD(c, a):
    # IGD=0
    # for i in range(len(c)):
    #     c1=
    # print(min([distanse(i, j) for j in a]) for i in c)
    return sum([min([distanse(i, j) for j in a]) for i in c]) #遍历所有距离
def tmain():
    oj = data_deal()
    item_ = oj.item
    job_num = item_["int2"]
    machine_num = item_["M"]

    # oj=data_deal(10,6)               #工件数，机器数
    # "job":每个工件的工序在不同机器上处理的时间
    # "daoda_time"：到达时间
    # "jiezhi_time"：截止日期
    # "M"：机器数量
    # "job_num"：每个工件工序数量
    # "job_dicr"：每个工件对应的工序数字典
    # "int1"：总工序数
    # "int2"：总工件数
    # "M_dicr"：机器编号与所属车间,机器加工功率,空载功率的字典
    # "tran_time"：车间之间的运输时间
    # "worker":可参与机器
    # "work_num"：工人数量
    # Tmachine二维数组，统计i工件的j工序可加工机器序号
    # Tmachinetime三维数组，统计i工件的j工序可由k机器加工的时间
    # [i][j].append(data[i][j][k])
    Tmachine, Tmachinetime, tdx, work, tom, int1, int2, M, M_dicr, tran_time, worker, work_num, efficiency = oj.cacu()


    parm_data = [Tmachine, Tmachinetime, tdx, work, M_dicr, tran_time, int1, worker, work_num, efficiency]
    # to=FJSP(10,6,0.5,parm_data)      #工件数，机器数，选择最短机器的概率和mk01的数据
    to = FJSP(job_num, machine_num, parm_data,100)
    dqn = DQN_RL(Tmachine, Tmachinetime, worker,machine_num,work_num)

    #_, _, _, _, _,_,_= to.creat_job()
    work_job, work_M, work_T, work_tran, work_F, job_init, work_wc = to.creat_job()
    oh = mul_op()
    ho = gwo4_1_schedule(100, 100, to, oh, work, job_num, tran_time, M_dicr, parm_data[7], oj)

    # to是柔性车间模块，oh是多目标模块
    for i in range(1):
        # a = copy.deepcopy(ql.q_table)
        # q_tables.append(a)
        work_job, work_M, work_T, work_tran, work_F, job_init, work_wc = to.creat_job()

        result_2 = []

        pareto, _, _, _, _, fit_every, _, _, _ = ho.gwo_total(work_job, work_M, work_T, work_tran, work_F, job_init,
                                                             work_wc, dqn, Tmachine,Tmachinetime)
        result_2.append(fit_every)  # 将结果放入队列







    return pareto,fit_every,


paretoture,fit_every =tmain()
# PFture.extend(paretoture)
        #print(A)
        # print(paretoture)
        # for i in range(101):
        #     plt.plot(i,F[2][i],marker='o',linestyle='-', color='blue')
        #     if i == 0:
        #         plt.xlabel('轮')
        #         plt.ylabel('完成时间')
        #
        # plt.show()




# IGD1 = []
# HV1 = []
# temp1,temp2 = 0,0
# for i in range(10):
#     paretoture, _, _, _, _, _, _, F,IGD,HV = tmain()
#     IGD1.append(IGD)
#     HV1.append(HV)
#     temp1 = temp1+ IGD
#     temp2 = temp2 +HV
# print("IGD=",temp1/10)
#
# print("HV=",temp2/10)

# def levy_pdf(x) :
#     return 1.0 / (x *np.sqrt(2 * np.pi)) * np.exp(-1.0 / (2*x))
#
# def levy_flight( beta=1.5):
#     sigma = np.power(np.math.gamma(1 + beta) * np.sin(np.pi * beta / 2) / np.math.gamma((1 + beta) / 2) * beta * np.power(2,(beta-1)/2,1/beta))
#     u = np.random.normal(0, sigma)
#     v = np.random.normal(0,1)
#     step = u / np.power(np.abs(v), 1 / beta)
#     return step
#
# def levy_flight_search(objective_function,bounds,n_iterations,n_pop):
#     best_solution = None
#     best_fitness = np.inf
#     pop_size = (n_pop,len(bounds))
#     pop = np.random.uniform(bounds[ : , 0], bounds[ :, 1],size=pop_size)
#     for i in range(n_iterations):
#         for j in range(n_pop):
# # 生成莱维飞行的步长
#             step = levy_flight
# # (#更新位置
#             candidate = pop[j] + step * (pop[j] - best_solution)
#             candidate = np.clip(candidate,bounds[ :, 0], bounds[ :,1]) #计算适应度
#             fitness = objective_function(candidate)#更新最优解
#             if fitness < best_fitness:
#                 best_solution = candidate
#                 best_fitness = fitness
#         print('Iteration {f}: Best F((})- {}'.format(i，best_solution，best_fitness))
#     return best_solution,best_fitness