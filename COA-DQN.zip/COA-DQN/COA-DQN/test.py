import numpy as np

from fjsp import FJSP
from small_work import data_deal


def str_to_numpy_array(str_data):
    """
    将NumPy打印格式的字符串转换为NumPy数组
    :param str_data: 如 "[[46. 50. 16. ...]]" 的字符串
    :return: numpy.ndarray
    """
    # 清理括号和空格，转换为数值列表
    clean_str = str_data.replace('[', '').replace(']', '').strip()
    if not clean_str:
        return np.array([])
    num_list = [float(x) for x in clean_str.split()]
    # 还原为二维数组（如果原始是二维）
    return np.array([num_list])


oj = data_deal()
item_ = oj.item
job_num = item_["int2"]
machine_num = item_["M"]


Tmachine, Tmachinetime, tdx, work, tom, int1, int2, M, M_dicr, tran_time, worker, work_num = oj.cacu()



parm_data = [Tmachine, Tmachinetime, tdx, work, M_dicr, tran_time, int1, worker, work_num]

to = FJSP(job_num, machine_num, parm_data, 100)

job = "[[ 0. 3. 1. 2. 2. 0. 1. 2. 1. 3. 0. 1. 0. 0. 1. 2.]]"
machine = "[[1. 1. 1. 0. 2. 1. 2. 2. 0. 0. 0. 2. 2. 0. 0. 1. 1.]]"
machine_time = "[[ 50. 36. 46. 16. 49. 39. 56. 40. 10. 46. 37. 11. 22. 31. 12. 60.]]"
wc = "[[ 1. 1. 2. 2. 1. 2. 2. 1. 1. 1. 2. 2. 1. 1. 2. 2.]]"
WC_W = [[1.0, 2.0, 2.0, 1.0, 1.0], [2.0, 2.0, 1.0, 2.0, 2.0], [2.0, 1.0, 1.0, 2.0], [1.0, 1.0]]
tran = "[[0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 0.]]"

job_np = str_to_numpy_array(job)
machine_np = str_to_numpy_array(machine)
machine_time_np = str_to_numpy_array(machine_time)
wc_np = str_to_numpy_array(wc)
tran_np = str_to_numpy_array(tran)

to.draw_noFactory1(job_np, machine_np, machine_time_np, tran_np, wc_np, WC_W)

