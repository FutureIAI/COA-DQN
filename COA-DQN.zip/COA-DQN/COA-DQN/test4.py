import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

# -------------------------- 1. 数据预处理 --------------------------
# 原始机器调度数据（仅保留机器相关行）
data = """
M1      16.0      62.0    2    R1    
M1     111.0     159.0    3    R2    
M1     227.0     273.0    4    R1    
M2       0.0      60.0    1    R2    
M2      62.0     111.0    3    R1    
M2     111.0     147.0    4    R1    
M2     159.0     231.0    3    R2    
M2     283.0     367.0    1    R2    
M3       0.0      16.0    3    R1    
M3     147.0     186.0    1    R1    
M3     186.0     223.0    1    R1    
M3     231.0     273.0    1    R2    
M3     273.0     329.0    2    R1    
M3     329.0     339.0    2    R1    
M3     339.0     350.0    2    R1    
M3     350.0     368.0    2    R1 
"""

# 解析机器任务数据
machine_tasks = []  # 格式: [机器名, 开始时间, 持续时间, 工件, 工人]
for line in data.strip().split('\n'):
    parts = line.strip().split()
    if not parts or not parts[0].startswith('M'):
        continue
    machine, start, end, job, worker = parts
    start = float(start)
    end = float(end)
    duration = end - start
    machine_tasks.append([machine, start, duration, job, worker])

# 计算最大完工时间（Makespan）
all_end_times = [task[1] + task[2] for task in machine_tasks]
makespan = max(all_end_times)  # 核心：获取甘特图最终时间

# -------------------------- 2. 可视化配置 --------------------------
# 工件颜色映射（保证每个工件颜色唯一）
jobs = sorted(list(set([task[3] for task in machine_tasks])))
colors = plt.cm.Set3(np.linspace(0, 1, len(jobs)))  # 论文常用配色方案
job_color = {job: color for job, color in zip(jobs, colors)}

# 绘图基础设置（适配英文论文排版）
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'SimHei']  # 优先英文渲染
plt.rcParams['axes.unicode_minus'] = False
fig, ax = plt.subplots(1, 1, figsize=(14, 6))  # 论文常用宽高比

# -------------------------- 3. 绘制机器甘特图核心部分 --------------------------
# 机器排序（M1/M2/M3）
machines = sorted(list(set([task[0] for task in machine_tasks])), key=lambda x: int(x[1:]))
y_pos_machine = {m: i for i, m in enumerate(machines)}

# 绘制每个机器任务
for task in machine_tasks:
    machine, start, duration, job, worker = task
    y = y_pos_machine[machine]

    # 绘制任务矩形（论文级视觉效果）
    rect = mpatches.Rectangle((start, y - 0.3), duration, 0.6,
                              facecolor=job_color[job], edgecolor='black',
                              linewidth=1.2, alpha=0.8)
    ax.add_patch(rect)

    # 标注：工件编号 + 操作工人（英文适配）
    ax.text(start + duration / 2, y, f'{job}\n{worker}',
            ha='center', va='center', fontsize=9, fontweight='medium')

# -------------------------- 4. 坐标轴与网格优化 --------------------------
ax.set_yticks(range(len(machines)))
ax.set_yticklabels(machines, fontsize=11)
ax.set_xlabel('Time', fontsize=12, fontweight='medium')  # 补充时间单位
ax.set_ylabel('Machine', fontsize=12, fontweight='medium')

# 网格线：仅横轴，更简洁
ax.grid(axis='x', alpha=0.4, linestyle='--', linewidth=0.8)
# x轴范围：适配最大完工时间，预留标注空间
ax.set_xlim(0, makespan + 30)
# y轴范围：避免任务矩形溢出
ax.set_ylim(-0.5, len(machines) - 0.5)

# -------------------------- 5. 添加最大完工时间（Makespan）标注 --------------------------
# 绘制垂直红线标记最终时间
ax.axvline(x=makespan, color='red', linestyle='-.', linewidth=1.5)
# 添加文本标注（固定在图表右上角）
ax.text(makespan + 5, len(machines)-0.5,
        f'Makespan: {makespan} min',
        fontsize=11, fontweight='bold', color='red',
        bbox=dict(boxstyle='round,pad=0.3', facecolor='white', edgecolor='red', alpha=0.8))

# -------------------------- 6. 论文级图例配置（英文） --------------------------
legend_patches = [mpatches.Patch(color=job_color[job], label=f'Job {job}') for job in jobs]
# 合并Makespan图例
handles, labels = ax.get_legend_handles_labels()
ax.legend(handles=legend_patches + handles,
          title='Job Number',  # 英文图例标题
          bbox_to_anchor=(1.02, 1), loc='upper left',
          fontsize=9, title_fontsize=10, frameon=True)

# -------------------------- 7. 保存高清图片（论文专用） --------------------------
plt.tight_layout()  # 自动调整布局，避免图例/标题溢出
# 保存为PNG（300DPI，满足期刊印刷要求）
plt.savefig('机器甘特图.png',
            dpi=300, bbox_inches='tight', facecolor='white')
plt.show()

