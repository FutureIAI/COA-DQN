# -*- coding: utf-8 -*-
# @Time    : 2022/4/13 20:23
# @Author  : ht
# @File    : small_work.py
# @Software: PyCharmjob
import json
import numpy as np
class data_deal:
    def __init__(self):
        self.name_list = ["job", "daoda_time", "jiezhi_time", "M", "job_num", "job_dicr", "int1", "int2",  "M_dicr", "tran_time","worker","work_num","efficiency"]
        # "job":每个工件的工序在不同机器上处理的时间
        # "daoda_time"：到达时间
        # "jiezhi_time"：截止日期
        # "M"：机器数量
        # "job_num"：每个工件process_num
        # "job_dicr"：每个工件对应的工序数字典
        # "int1"：总工序数
        # "int2"：总工件数
        # "M_dicr"：机器编号与所属车间,机器加工功率,空载功率的字典
        # "tran_time"：车间之间的运输时间
        # "worker":可参与机器
        # "work_num"：工人数量
        self.item = {}
        self.get_item()



    def precess_(self, data):
            if "[" in data and "," not in data:
                data = data.strip().replace("[ ", "[").replace(" ]", "]").replace("  ", ",").replace(" ", ",").replace("][", "], [")
            elif "{" in data:
                data = data.strip().replace("：", ":")
            return eval(data)

    # 读取数据
    def get_item(self):
        with open("data\small_data\D06-20x7x3(1).txt") as fp:
        #with open("data\medium_data\DM16-40x13x4.txt") as fp:
            datas = fp.readlines()
            for i in range(len(self.name_list)):
                data = self.precess_(datas[i])
                self.item[self.name_list[i]] = data
        return self.item
    # 查找工件可加工的最大机器数
    def widthxx(self):
        widthx = []
        int2 = self.item["int2"]
        data = self.item['job']
        siga=0
        for i in range(int2):
            for j in range(len(data[i])):
                # 10个机器
                for k in range(10):
                    if data[i][j][k] > 0:
                        siga+=1
            widthx.append(siga)
            siga=0
        width = max(widthx)
        return width

    def tcaculate(self):
        # 共工件数
        int2=self.item["int2"]
        # 每个工件的工序数，是个数组
        jobnum=self.item["job_num"]

        # width = self.widthxx()
        # Tmachine, Tmachinetime = np.zeros((int2, width)), np.zeros((int2, width))
        Tmachine = [ [ [] for j in range(jobnum[i])] for i in range(int2)]
        Tmachinetime = [ [ [] for j in range(jobnum[i])] for i in range(int2)]
        tdx,sdx,tom,toe=[],[],[],[]
        M=self.item['M']
        data=self.item['job']
        # for i in range(len(data)):
        #     for j in range(len(data[i])):
        #         for k in range(M):
        #             data[i][j][k]=40
        # print(data)
        q=0
        a=0
        # 循环工件
        for i in range(len(data)):
            # 循环工序
            for j in range(len(data[i])):
                # 循环机器
                for k in range(M):
                    if data[i][j][k] > 0:
                        # 二维数组，统计i工件的j工序可加工机器序号
                        Tmachine[i][j].append(k+1)
                        # 三维数组，统计i工件的j工序可由k机器加工的时间
                        Tmachinetime[i][j].append(data[i][j][k])
                        q += 1
                        a += 1
                sdx.append(a)
                a=0
                toe.append(q)
            # 工序的可加工机器数
            tdx.append(sdx)
            sdx=[]
            q = 0
            # 每个工件的可加工机器数
            tom.append(toe)
            toe = []
        # Tmachine = Tmachine.tolist()
        # Tmachinetime=Tmachinetime.tolist()
        return Tmachine,Tmachinetime,tdx,tom


    def cacu(self):
        int2 = self.item["int2"]
        int1 = self.item["int1"]
        M=self.item["M"]
        M_dicr = self.item["M_dicr"]
        tran_time = self.item["tran_time"]
        worker = self.item["worker"]
        work_num = self.item["work_num"]
        efficiency = self.item["efficiency"]





        Tmachine, Tmachinetime, tdx ,tom= self.tcaculate()
        to, work = 0, []
        for i in range(int2):
            to += len(tdx[i])
            for j in range(1, len(tdx[i]) + 1, 1):
                work.append(i)
        # for i in range(int2):
        #     for j in range():
        #         if Tmachine[i][j]==1 or Tmachine[i][j]==2 or Tmachine[i][j]==3:
        #             tran.append(tran_num[0])
        #         if Tmachine[i][j] == 4 or Tmachine[i][j] == 5:
        #             tran.append(tran_num[1])
        #         if Tmachine[i][j] == 6 or Tmachine[i][j] == 7 or Tmachine[i][j]==8:
        #             tran.append(tran_num[2])
        #         if Tmachine[i][j] == 9 or Tmachine[i][j] == 10:
        #             tran.append(tran_num[3])
        #     Ttran.append(tran)
        #     tran=[]
        machine_list = self.job_processes_machine_Serial()

        return Tmachine, Tmachinetime, tdx, work, tom, int1,int2, M, M_dicr, tran_time,worker,work_num, efficiency

    def job_processes_machine_Serial(self):
        """
        将self.item["job"]转换为job_process，表示每个工件的每个工序可以在哪些机器上加工。

        Args:
          self.item["job"]: 三层嵌套列表，表示工件、工序和机器的加工时间。

        Returns:
          二层嵌套列表，表示每个工件的每个工序可以在哪些机器上加工。
          外层列表的索引表示job_order，内层列表的索引表示process_order，
          内层列表的内容是该工件该工序可以加工的machine_list。
        """

        job_num = len(self.item["job"])
        job_process = []

        for job_order in range(job_num):
            process_num = len(self.item["job"][job_order])
            job_process_machine = []

            for process_order in range(process_num):
                machine_list = [machine_order+1 for machine_order, time in enumerate(self.item["job"][job_order][process_order]) if time != -1.0]
                job_process_machine.append(machine_list)

            job_process.append(job_process_machine)
        # print(job_process)
        return job_process


# to=data_deal()
# Tmachine,Tmachinetime,tdx,work,tom,int2,M,M_dicr, tran_time= to.cacu()
# print(M_dicr[0],type(M_dicr[0]))
# # print(work)
# #Tmachine:工序对应的可使用机器
#Tmachinetime:工序在该机器上对应的运行时间
#tdx:工序对应的可使用机器数
#work：每个工件对应的工序，按工件索引排列
#tom：该工件按工序排列可使用的机器数和
# Ttran:每个工序对应的机器对应的车间
# print(a)
# print(b)
# int2=to.get_item()
# print(int2['int2'])
# print(Tmachine[33])
# print(Tmachinetime[33])
#print(Ttran)
# print(tdx)
# print(tom)
#worker：每个机器可以有那些编号人操作
 