def reschedule_min_impact(origin, opt_m, opt_t, opt_w, broken_m=6):
    new_m = origin['m'].copy()
    new_t = origin['t'].copy()
    new_w = origin['w'].copy()
    j_seq = origin['j']

    # 记录每个工件当前遍历到第几个工序
    job_step_counter = {}

    for i in range(len(j_seq)):
        job_id = j_seq[i]
        step = job_step_counter.get(job_id, 0)
        job_step_counter[job_id] = step + 1

        # 检查是否为故障机器上的任务
        if origin['m'][i] == broken_m:
            # 获取该工序在 opt_m 中的约束
            # 容错：防止 j 序列中的工序数超过 opt_m 定义
            if step >= len(opt_m[job_id]):
                step = len(opt_m[job_id]) - 1

            choices = opt_m[job_id][step]
            times = opt_t[job_id][step]

            # 过滤掉坏掉的机器 6，并寻找最优替代（时间最短）
            best_m = -1
            min_time = float('inf')

            for idx, m_val in enumerate(choices):
                if m_val != broken_m:
                    if times[idx] < min_time:
                        min_time = times[idx]
                        best_m = m_val

            # 如果找到了替代机器
            if best_m != -1:
                new_m[i] = best_m
                new_t[i] = min_time
                # 更新工人：如果原工人能操作新机器，则保留；否则换该机器第一个可用工人
                # 注意 opt_w 索引可能需匹配（假设 opt_w[0] 是机器 0）
                allowed_workers = opt_w[best_m]
                if origin['w'][i] not in allowed_workers:
                    new_w[i] = allowed_workers[0]
                else:
                    new_w[i] = origin['w'][i]

    return {'j': j_seq, 'm': new_m, 't': new_t, 'w': new_w}


def generate_optimized_reschedule(self, data, opt_m, opt_t, opt_w, fail_m):
    """
    Args:
        data: 故障后的数据序列 {'j':[], 'm':[], 't':[], 'w':[]}
        opt_m/opt_t: 机器/时间约束 (三层列表 [job][step][candidates])
        opt_w: 机器-工人约束 (字典或列表，表示某台机器可以由哪些工人操作)
        fail_m: 永久损坏的机器 ID (0-indexed)
    """
    # 1. 基础数据准备
    j_sequence = data['j'].astype(int)
    num_ops = len(j_sequence)

    # 资源空闲时刻追踪 (初始化为 0)
    m_clocks = {}  # 机器
    w_clocks = {}  # 工人
    j_clocks = {}  # 工件 (前序工序结束时刻)

    # 记录每个工件当前排到了第几道工序 (用于从 opt_m/t 索引)
    job_op_step = {}

    # 结果容器
    new_m = np.zeros(num_ops, dtype=int)
    new_t = np.zeros(num_ops, dtype=float)
    new_w = np.zeros(num_ops, dtype=int)

    # 预处理：将 opt_m 内部的机器编号统一为 0-indexed (如果原始是1-7)
    # 如果你的 opt_m 已经是 0-indexed，请跳过此步或根据实际调整
    def adjust_m_indices(opt_m):
        return [[[m_id - 1 for m_id in step] for step in job] for job in opt_m]

    # 假设此处需要转换，如果不需要请直接使用 adj_opt_m = opt_m
    adj_opt_m = adjust_m_indices(opt_m)

    # 2. 核心：按序列进行最优资源指派 (EFT策略)
    for i in range(num_ops):
        job_id = j_sequence[i]
        step_idx = job_op_step.get(job_id, 0)

        # 获取当前工序的所有候选资源
        try:
            candidate_machines = adj_opt_m[job_id][step_idx]
            candidate_times = opt_t[job_id][step_idx]
        except IndexError:
            # 异常处理：若索引超出，则沿用 data 原始值
            new_m[i], new_t[i], new_w[i] = data['m'][i], data['t'][i], data['w'][i]
            # 更新时钟以防中断
            st = max(m_clocks.get(new_m[i], 0), w_clocks.get(new_w[i], 0), j_clocks.get(job_id, 0))
            finish = st + new_t[i]
            m_clocks[new_m[i]] = finish
            j_clocks[job_id] = finish
            job_op_step[job_id] = step_idx + 1
            continue

        best_m = -1
        best_w = -1
        min_finish_time = float('inf')
        best_duration = 0

        # --- 局部精英搜索：遍历所有机器和工人组合 ---
        for m_idx, m_id in enumerate(candidate_machines):
            # 排除永久损坏机器
            if m_id == fail_m:
                continue

            duration = candidate_times[m_idx]
            # 获取该机器允许的工人集合
            possible_workers = opt_w[m_id]

            for worker_id in possible_workers:
                # 计算该组合下的开始时刻：max(机器空闲, 工人空闲, 工件前序完)
                start_time = max(m_clocks.get(m_id, 0),
                                 w_clocks.get(worker_id, 0),
                                 j_clocks.get(job_id, 0))
                finish_time = start_time + duration

                # 精英判定：选择使当前工序结束时间最早的组合
                if finish_time < min_finish_time:
                    min_finish_time = finish_time
                    best_m = m_id
                    best_w = worker_id
                    best_duration = duration
                # 破平规则（可选）：如果完工时间一样，选耗时短的机器，为以后留出空间
                elif finish_time == min_finish_time:
                    if duration < best_duration:
                        best_m = m_id
                        best_w = worker_id
                        best_duration = duration

        # 3. 锁定选择并更新系统时钟
        if best_m != -1:
            new_m[i] = best_m
            new_w[i] = best_w
            new_t[i] = best_duration

            m_clocks[best_m] = min_finish_time
            w_clocks[best_w] = min_finish_time
            j_clocks[job_id] = min_finish_time
        else:
            # 极端情况：如果该工序只能由损坏的机器加工，无解
            # 此时只能保留原数据并标记一个极大值，避免算法崩溃
            new_m[i] = data['m'][i]
            new_w[i] = data['w'][i]
            new_t[i] = data['t'][i]
            j_clocks[job_id] = 999999

        job_op_step[job_id] = step_idx + 1

    # 4. 组装新个体
    return {
        'j': data['j'].copy(),
        'm': new_m,
        't': new_t,
        'w': new_w
    }


def simulate_drc_fjsp_arrays(self, job_arr, mac_arr, time_arr, wc_arr):
    """
    针对 NumPy 数组的双资源调度仿真
    返回: (完工时间, 开始时刻字典)
    """
    # 自动识别资源规模
    num_m = int(np.max(mac_arr) + 1)
    num_w = int(np.max(wc_arr) + 1)

    # 初始化资源空闲状态
    m_avail = np.zeros(num_m)  # 机器
    w_avail = np.zeros(num_w)  # 工人
    j_avail = {}  # 工件工序就绪时刻
    op_counter = {}  # 记录工件内部工序索引

    start_times_record = {}

    for i in range(len(job_arr)):
        j_id = int(job_arr[i])
        m_id = int(mac_arr[i])
        w_idx = int(wc_arr[i] - 1)  # 假设工人ID 1-indexed, 转 0-indexed

        # 获取该工件当前第几道工序 (0, 1, 2...)
        idx = op_counter.get(j_id, 0)

        # 计算开工时间: max(机器空闲, 工人空闲, 工件前序完工)
        prev_f = j_avail.get(j_id, 0.0)
        s_ij = max(m_avail[m_id], w_avail[w_idx], prev_f)
        e_ij = s_ij + time_arr[i]

        # 记录
        start_times_record[(j_id, idx)] = (m_id, s_ij)

        # 更新状态
        m_avail[m_id] = e_ij
        w_avail[w_idx] = e_ij
        j_avail[j_id] = e_ij
        op_counter[j_id] = idx + 1

    makespan = max(j_avail.values()) if j_avail else 0
    return makespan, start_times_record


def calculate_sta_metrics(self, orig_data, res_data, failed_m_idx):
    """
    计算完工时间与稳定性
    """
    # 1. 运行仿真获取时间表
    mt_orig, starts_orig = self.simulate_drc_fjsp_arrays(orig_data['j'], orig_data['m'], orig_data['t'], orig_data['w'])
    mt_res, starts_res = self.simulate_drc_fjsp_arrays(res_data['j'], res_data['m'], res_data['t'], res_data['w'])

    # 2. 计算 Sta (公式 5-7)
    # Sta = Σ |S' - S| * (1 - Fk)
    sta = 0.0
    for key, (m_id_res, s_res) in starts_res.items():
        if key in starts_orig:
            _, s_orig = starts_orig[key]

            # (1 - Fk) 逻辑：如果当前工序分配到了故障机器，则不计入稳定性损失
            f_k = 1 if m_id_res == failed_m_idx else 0

            sta += abs(s_res - s_orig) * (1 - f_k)

    return sta


import numpy as np


def split_data_by_failure(self, data, fail_m, fail_time):
    # 提取数组
    j_arr = data['j']
    m_arr = data['m']
    t_arr = data['t']
    w_arr = data['w']

    # 记录资源空闲时刻 (初始化为0)
    m_clocks = {}  # 机器上一个任务结束时间
    w_clocks = {}  # 工人上一个任务结束时间
    j_clocks = {}  # 工件上一个工序结束时间

    pre_indices = []
    post_indices = []

    # 用于标记某个资源是否已经进入了“故障后”状态
    # 一旦某个资源在 fail_time 之后才空闲，后续依赖该资源的所有任务自动进入 post
    resource_after_failure = {'m': set(), 'w': set(), 'j': set()}

    for i in range(len(j_arr)):
        job_id = j_arr[i]
        m_id = m_arr[i]
        w_id = w_arr[i]
        dur = t_arr[i]

        # 1. 严格按顺序计算开始时间
        # 必须等到：该机器空闲 AND 该工人空闲 AND 该工件前序完成
        m_ready = m_clocks.get(m_id, 0)
        w_ready = w_clocks.get(w_id, 0)
        j_ready = j_clocks.get(job_id, 0)

        # 理论开始时间是三者取最大
        start_t = max(m_ready, w_ready, j_ready)
        end_t = start_t + dur

        # 2. 更新时钟（无论划分到哪，都要更新，以维持后续任务的时间链）
        m_clocks[m_id] = end_t
        w_clocks[w_id] = end_t
        j_clocks[job_id] = end_t

        # 3. 判定逻辑
        # 判定条件：当前任务结束时间在故障前，且该任务的所有前置约束没有跨越故障
        # 实际上，只要 end_t <= fail_time，由于 start_t 是根据前序任务算出来的，
        # 顺序自然就得到了保证。
        if end_t <= fail_time:
            pre_indices.append(i)
        else:
            # 一旦 end_t > fail_time，该任务及其后续所有任务都应划入 post
            # 为了严谨，即便后续任务计算出的 end_t 因为逻辑错误小于 fail_time，
            # 我们通过这个循环的顺序执行也能保证它进入 post_indices
            post_indices.append(i)

    # 4. 封装返回数据
    before_failure = {}
    after_failure = {}

    for key in data:
        # 保持原始数据类型
        before_failure[key] = data[key][pre_indices] if pre_indices else np.array([], dtype=data[key].dtype)
        after_failure[key] = data[key][post_indices] if post_indices else np.array([], dtype=data[key].dtype)

    return before_failure, after_failure


if i % 20 == 1:
    new_individual = stable.generate_optimized_reschedule(orig_arrays, Tmachine, Tmachinetime,
                                                          self.to.work_arr, orig_restult['f_m'])
    work_job[i] = new_individual['j']
    work_M[i] = new_individual['m']
    work_T[i] = new_individual['t']
    work_wc[i] = new_individual['w']
if i % 50 == 2:
    new_individual = stable.reschedule_min_impact(orig_arrays, Tmachine, Tmachinetime,
                                                  self.to.work_arr, orig_restult['f_m'])
    work_job[i] = new_individual['j']
    work_M[i] = new_individual['m']
    work_T[i] = new_individual['t']
    work_wc[i] = new_individual['w']
