# 打开文件
filename = 'worker.txt'  # 替换为实际文件路径

with open(filename, 'r') as file:
    # 逐行读取文件内容
    lines = file.readlines()
# 处理每行数据
data = []
for line in lines:

    numbers = list(map(int, line.strip().split()))
    data.append(numbers)
print(data)
worker_M = {}
for r in range(len(data)):  # Assuming O1 to O26
    for m in range(5):  # Assuming M1 to M5
        r_key = f'R{r+1}'
        m_key = f'M{m+1}'
        if m in data[r]:
            worker_M[(r_key, m_key)] = 1
        else:
            worker_M[(r_key, m_key)] = 0
print(worker_M)
# print(STEP_MOULDS)

