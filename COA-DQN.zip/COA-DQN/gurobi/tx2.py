import gurobipy as gp
from gurobipy import *

# 参数
supply = dict({
    "F1": 150000,
    "F2": 200000
})

through = dict({
    "D1": 70000,
    "D2": 50000,
    "D3": 100000,
    "D4": 40000
})

demand = dict({
    "C1": 50000,
    "C2": 10000,
    "C3": 40000,
    "C4": 35000,
    "C5": 60000,
    "C6": 20000
})

arcs, cost = gp.multidict({
    ("F1", "D1"): 0.5,
    ("F1", "D2"): 0.5,
    ("F1", "D3"): 1.0,
    ("F1", "D4"): 0.2,
    ("F1", "C1"): 1.0,
    ("F1", "C3"): 1.5,
    ("F1", "C4"): 2.0,
    ("F1", "C6"): 1.0,
    ("F2", "D2"): 0.3,
    ("F2", "D3"): 0.5,
    ("F2", "D4"): 0.2,
    ("F2", "C1"): 2.0,
    ("D1", "C2"): 1.5,
    ("D1", "C3"): 0.5,
    ("D1", "C5"): 1.5,
    ("D1", "C6"): 1.0,
    ("D2", "C1"): 1.0,
    ("D2", "C2"): 0.5,
    ("D2", "C3"): 0.5,
    ("D2", "C4"): 1.0,
    ("D2", "C5"): 0.5,
    ("D3", "C2"): 1.5,
    ("D3", "C3"): 2.0,
    ("D3", "C5"): 0.5,
    ("D3", "C6"): 1.5,
    ("D4", "C3"): 0.2,
    ("D4", "C4"): 1.5,
    ("D4", "C5"): 0.5,
    ("D4", "C6"): 1.5
})
print(arcs)
# model
model = gp.Model()
# decision var
flow = model.addVars(arcs, vtype=GRB.CONTINUOUS, name="flow")  # flow为tupledict
print(flow)
# constraints
# factory production
factory = supply.keys()
model.addConstrs((flow.sum(f, "*") <= supply[f] for f in factory), name="factory constraints")
# depot constraints
depot = through.keys()
model.addConstrs((flow.sum("*", d) <= through[d] for d in depot), name="depot constraint 1")
model.addConstrs((flow.sum("*", d) == flow.sum(d, "*") for d in depot), name="depot constraint 2")
# customer constraints
customers = demand.keys()
model.addConstrs((flow.sum("*", c) == demand[c] for c in customers), name="customers constraints")
# objective
obj = flow.prod(cost)
model.setObjective(obj, GRB.MINIMIZE)

# optimize
model.write("test.lp")
model.update()
model.optimize()
