from gurobipy import *

categories, minNutrition, maxNutrition = multidict({
    "calories": [1800, 2200],
    "protein": [91, GRB.INFINITY],
    "fat": [0, 65],
    "sodium": [0, 1779]
})

foods, cost = multidict({
    'hamburger': 2.49,
    'chicken': 2.89,
    'hot dog': 1.50,
    'fries': 1.89,
    'macaroni': 2.09,
    'pizza': 1.99,
    'salad': 2.49,
    'milk': 0.89,
    'ice cream': 1.59
})

nutritionValues = {
    ('hamburger', 'calories'): 410,
    ('hamburger', 'protein'): 24,
    ('hamburger', 'fat'): 26,
    ('hamburger', 'sodium'): 730,
    ('chicken', 'calories'): 420,
    ('chicken', 'protein'): 32,
    ('chicken', 'fat'): 10,
    ('chicken', 'sodium'): 1190,
    ('hot dog', 'calories'): 560,
    ('hot dog', 'protein'): 20,
    ('hot dog', 'fat'): 32,
    ('hot dog', 'sodium'): 1800,
    ('fries', 'calories'): 380,
    ('fries', 'protein'): 4,
    ('fries', 'fat'): 19,
    ('fries', 'sodium'): 270,
    ('macaroni', 'calories'): 320,
    ('macaroni', 'protein'): 12,
    ('macaroni', 'fat'): 10,
    ('macaroni', 'sodium'): 930,
    ('pizza', 'calories'): 320,
    ('pizza', 'protein'): 15,
    ('pizza', 'fat'): 12,
    ('pizza', 'sodium'): 820,
    ('salad', 'calories'): 320,
    ('salad', 'protein'): 31,
    ('salad', 'fat'): 12,
    ('salad', 'sodium'): 180,
    ('milk', 'calories'): 100,
    ('milk', 'protein'): 8,
    ('milk', 'fat'): 2.5,
    ('milk', 'sodium'): 125,
    ('ice cream', 'calories'): 330,
    ('ice cream', 'protein'): 8,
    ('ice cream', 'fat'): 10,
    ('ice cream', 'sodium'): 180
}

m = Model("mip1")

buy = m.addVars(foods, vtype=GRB.INTEGER, name="buy")

m.setObjective(sum(buy[f] * cost[f] for f in foods), GRB.MINIMIZE)

for c in categories:
    m.addRange(
        quicksum(nutritionValues[f, c] * buy[f] for f in foods if (f, c) in nutritionValues),
        minNutrition[c],
        maxNutrition[c],
        c
    )

m.optimize()

if m.status == GRB.Status.OPTIMAL:
    print("\nCost: %g" % m.objVal)
    print("Buy: ")
    buyx = m.getAttr('x', buy)
    for f in foods:
        if buy[f].x > 0.0001:
            print("%s %g" % (f, buyx[f]))
