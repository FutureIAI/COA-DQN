import matplotlib.pyplot as plt
import numpy as np

def parse_schedule_data(data_str):
    """解析原始数据，返回机器任务字典和工人任务字典"""
    lines = data_str.strip().split('\n')
    machine_tasks = {}
    worker_tasks = {}

    for line in lines:
        line = line.strip()
        # 跳过空行、标题行和末尾的数值行
        if not line or line.startswith('设备使用计划') or line[0].isdigit():
            continue
        parts = line.split()
        if len(parts) < 5:
            continue
        resource = parts[0]
        start = float(parts[1])
        end = float(parts[2])
        task = parts[3]
        other = parts[4]

        if resource.startswith('M'):
            machine_tasks.setdefault(resource, []).append((start, end, task, other))
        elif resource.startswith('R'):
            worker_tasks.setdefault(resource, []).append((start, end, task, other))

    return machine_tasks, worker_tasks

def draw_gantt(machine_tasks, worker_tasks):
    """绘制双资源甘特图"""
    # 对资源名称排序以保证顺序
    machines = sorted(machine_tasks.keys())
    workers = sorted(worker_tasks.keys())

    # 创建两个子图，共享x轴
    fig, (ax_mach, ax_work) = plt.subplots(2, 1, figsize=(14, 8), sharex=True)

    # 颜色映射（使用tab10色环，基于关联资源取模）
    colors = plt.cm.tab10(np.linspace(0, 1, 10))

    # 计算最大时间用于设置x轴范围
    max_time = 0
    for tasks in machine_tasks.values():
        for t in tasks:
            max_time = max(max_time, t[1])
    for tasks in worker_tasks.values():
        for t in tasks:
            max_time = max(max_time, t[1])

    # ---------- 绘制机器甘特图 ----------
    y_ticks_m = []
    y_labels_m = []
    for idx, mach in enumerate(machines):
        tasks = machine_tasks[mach]
        for start, end, task, worker in tasks:
            # 根据关联工人选择颜色
            color_idx = hash(worker) % 10
            color = colors[color_idx]
            ax_mach.barh(idx, end - start, left=start, height=0.6,
                         color=color, edgecolor='black', linewidth=0.5)
            # 在条形中央添加标签：工序(工人)
            label = f"{task}({worker})"
            ax_mach.text(start + (end - start) / 2, idx, label,
                         ha='center', va='center', fontsize=8,
                         color='white' if np.mean(color[:3]) < 0.5 else 'black')
        y_ticks_m.append(idx)
        y_labels_m.append(mach)

    ax_mach.set_yticks(y_ticks_m)
    ax_mach.set_yticklabels(y_labels_m)
    ax_mach.set_ylabel('Machines')
    ax_mach.set_title('Machine Schedule')
    ax_mach.grid(axis='x', linestyle='--', alpha=0.7)

    # ---------- 绘制工人甘特图 ----------
    y_ticks_w = []
    y_labels_w = []
    for idx, work in enumerate(workers):
        tasks = worker_tasks[work]
        for start, end, task, machine in tasks:
            # 根据关联机器选择颜色
            color_idx = hash(machine) % 10
            color = colors[color_idx]
            ax_work.barh(idx, end - start, left=start, height=0.6,
                         color=color, edgecolor='black', linewidth=0.5)
            # 标签：工序(机器)
            label = f"{task}({machine})"
            ax_work.text(start + (end - start) / 2, idx, label,
                         ha='center', va='center', fontsize=8,
                         color='white' if np.mean(color[:3]) < 0.5 else 'black')
        y_ticks_w.append(idx)
        y_labels_w.append(work)

    ax_work.set_yticks(y_ticks_w)
    ax_work.set_yticklabels(y_labels_w)
    ax_work.set_ylabel('Workers')
    ax_work.set_title('Worker Schedule')
    ax_work.grid(axis='x', linestyle='--', alpha=0.7)

    # 设置x轴范围并添加标签
    ax_work.set_xlim(0, max_time + 10)
    ax_work.set_xlabel('Time')

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    # 将你的数据粘贴在此处
    data_str = """设备使用计划:
M1      16.0      62.0	O5	R1	
M1     248.0     296.0	O12	R2	
M1     302.0     348.0	O15	R1	
M1     348.0     379.0	O4	R1	
M2       0.0      60.0	O0	R2	
M2     194.0     243.0	O11	R1	
M2     243.0     279.0	O14	R1	
M2     290.0     302.0	O9	R1	
M2     302.0     374.0	O13	R2	
M3       0.0      16.0	O10	R1	
M3      62.0     118.0	O6	R1	
M3     118.0     157.0	O1	R1	
M3     157.0     194.0	O2	R1	
M3     194.0     206.0	O7	R2	
M3     206.0     248.0	O3	R2	
M3     279.0     290.0	O8	R1	
R1       0.0      16.0	O10	M3	
R1      16.0      62.0	O5	M1	
R1      62.0     118.0	O6	M3	
R1     118.0     157.0	O1	M3	
R1     157.0     194.0	O2	M3	
R1     194.0     243.0	O11	M2	
R1     243.0     279.0	O14	M2	
R1     279.0     290.0	O8	M3	
R1     290.0     302.0	O9	M2	
R1     302.0     348.0	O15	M1	
R1     348.0     379.0	O4	M1	
R2       0.0      60.0	O0	M2	
R2     194.0     206.0	O7	M3	
R2     206.0     248.0	O3	M3	
R2     248.0     296.0	O12	M1	
R2     302.0     374.0	O13	M2	
1068.6000000000001"""

    machine_tasks, worker_tasks = parse_schedule_data(data_str)
    draw_gantt(machine_tasks, worker_tasks)