from gurobipy import *
import os

os.environ['GRB_LICENSE_FILE'] = r'C:\Users\Administrator\gurobi.lic'

# 机器
device = ['M1', 'M2', 'M3', 'M4', 'M5']

# 产品
# products = ['O0', 'O1', 'O2', 'O3', 'O4', 'O5', 'O6', 'O7', 'O8', 'O9', 'O10', 'O11', 'O12', 'O13', 'O14', 'O15', 'O16', 'O17',
#             'O18', 'O19', 'O20', 'O21', 'O22', 'O23', 'O24', 'O25', 'O26', 'O27', 'O28', 'O29', 'O30', 'O31', 'O32', 'O33', 'O34',
#             'O35','O36', 'O37', 'O38', 'O39', 'O40', 'O41', 'O42', 'O43', 'O44', 'O45', 'O46', 'O47', 'O48', 'O49', 'O50', 'O51',
#             'O52','O53']
products = ['O0', 'O1', 'O2', 'O3', 'O4', 'O5', 'O6', 'O7', 'O8', 'O9', 'O10', 'O11', 'O12', 'O13', 'O14', 'O15', 'O16', 'O17', 'O18', 'O19', 'O20', 'O21', 'O22', 'O23'
            ]

# 特殊工序
preProduct = {
    'O0': 'O1', 'O1': 'O2', 'O2': 'O3', 'O4': 'O5', 'O5': 'O6', 'O6': 'O7', 'O7': 'O8', 'O9': 'O10', 'O11': 'O12',
    'O12': 'O13', 'O13': 'O14', 'O14': 'O15', 'O16': 'O17', 'O18': 'O19', 'O20': 'O21', 'O21': 'O22', 'O22': 'O23'

}
# 工作能耗
workPower = {
    'M1': 18,
    'M2': 20,
    'M3': 10,
    'M4': 15,
    'M5': 17

}
# 空闲能耗
freePower = {
    'M1': 1.82,
    'M2': 2.73,
    'M3': 1.69,
    'M4': 2.09,
    'M5': 1.95
}


worker = ['R1', 'R2', 'R3']
worker_efficiency = {
    'R1': 1,
    'R2': 1,
    'R3': 1
}

with open('worker.txt', 'r') as file:
    lines = file.readlines()
data1 = []
for line in lines:
    numbers = list(map(int, line.strip().split()))
    data1.append(numbers)
print(data1)
worker_M = {}
for r in range(len(data1)):
    for m in range(len(device)+1):
        r_key = f'R{r + 1}'
        m_key = f'M{m + 1}'
        if m in data1[r]:
            worker_M[(r_key, m_key)] = 1
        else:
            worker_M[(r_key, m_key)] = 0
print(worker_M)

# 工序时间
with open('xxx.txt', 'r') as file:
    lines = file.readlines()
data = []
for line in lines:
    numbers = list(map(int, line.strip().split()))
    data.append(numbers)
STEP_TIME = {}
for i in range(len(data)):
    first_num = data[i][0]
    for j in range(first_num):
        M = 'O' + str(i)
        precess = 'M' + str(data[i][j * 2 + 1] + 1)
        nValue = data[i][j * 2 + 2]
        key = (M, precess)
        dict2 = {key: nValue}
        STEP_TIME.update(dict2)

STEP_MOULDS = {}
for o in range(0, 24):
    for m in range(1, 6):
        o_key = f'O{o}'
        m_key = f'M{m}'
        if (o_key, m_key) in STEP_TIME:
            STEP_MOULDS[(o_key, m_key)] = 1
        else:
            STEP_MOULDS[(o_key, m_key)] = 0

nORDERS = len(products)
nMOULDS = len(device)
M = 1000
SLOTS = range(nORDERS)
model = Model('AssemblyAPS')
start = model.addVars(products, vtype=GRB.INTEGER, name="start")
end = model.addVars(products, vtype=GRB.INTEGER, name="end")
useR_M = model.addVars(worker, SLOTS, device, products, vtype=GRB.BINARY, name="useR_M")
mSlotStartTime = model.addVars(device, SLOTS, name="mSlotStartTime")
mSlotEndTime = model.addVars(device, SLOTS, name="mSlotEndTime")
rSlotStartTime = model.addVars(worker, SLOTS, name="rSlotStartTime")
rSlotEndTime = model.addVars(worker, SLOTS, name="rSlotEndTime")
timeSpan = model.addVar(vtype=GRB.INTEGER, name="timeSpan")
timeSpan1 = model.addVar(vtype=GRB.INTEGER, name="timeSpan1")
timeSpan2 = model.addVar(vtype=GRB.INTEGER, name="timeSpan2")


# 添加约束
for i in products:
    for k in device:
        for r in worker:
            if STEP_MOULDS[i, k] == 1 and worker_M[r, k] == 1:
                model.addConstr(end[i] >= start[i] + quicksum(useR_M[r, j, k, i] * STEP_TIME[i, k] * worker_efficiency[r] for j in SLOTS))
# ... (其他代码，与之前相同)


for r in worker:
    for slot in SLOTS:
        model.addConstr(
            rSlotEndTime[r, slot] == rSlotStartTime[r, slot] + quicksum(
                useR_M[r, slot, k1, i] * STEP_TIME[i, k1] * worker_efficiency[r]
                for i in products
                for k1 in device
                if STEP_MOULDS[i, k1] == 1 and worker_M[r, k1] == 1
            )
        )


for k in device:
    for slot in SLOTS:
        model.addConstr(
            mSlotEndTime[k, slot] == mSlotStartTime[k, slot] + quicksum(
                useR_M[r, slot, k, i] * STEP_TIME[i, k] * worker_efficiency[r]
                for i in products
                for r in worker
                if STEP_MOULDS[i, k] == 1 and worker_M[r, k] == 1
            )
        )


powerSpan = {}
totalPower = model.addVar(vtype=GRB.INTEGER, name="totalPower")
for i in products:
    powerSpan[i] = model.addVar(vtype=GRB.INTEGER, name=f"powerSpan_{i}")
    for k in device:
        for r in worker:
            if STEP_MOULDS[i, k] == 1 and worker_M[r, k] == 1:
                model.addConstr(powerSpan[i] >= quicksum(
                    useR_M[r, j, k, i] * STEP_TIME[i, k] * worker_efficiency[r] * workPower[k] for j in SLOTS))
                # total_time == quicksum(STEP_TIME[j][k] * workPower[k] for j in SLOTS)
model.addConstr(totalPower >= quicksum(powerSpan[i] for i in products))

total_time = {}
timeM = model.addVar(vtype=GRB.INTEGER, name="timeM")
for i in products:

    total_time[i] = model.addVar(vtype=GRB.INTEGER, name=f"total_time_{i}")
    for k in device:
        for r in worker:
            if STEP_MOULDS[i, k] == 1 and worker_M[r, k] == 1:
                model.addConstr(total_time[i] >= quicksum(
                    useR_M[r, j, k, i] * STEP_TIME[i, k] * worker_efficiency[r] for j in SLOTS))
                # total_time == quicksum(STEP_TIME[j][k] * workPower[k] for j in SLOTS)
# model.addConstr(totalPower >= quicksum(powerSpan[i] for i in products))
model.addConstr(timeM >= quicksum(total_time[i] for i in products))

for key, value in preProduct.items():
    model.addConstr(start[value] >= end[key])

for pre, next in preProduct.items():
    for k in device:
        for r in worker:
            if STEP_MOULDS[pre, k] == 1 and worker_M[r, k] == 1:
                model.addConstr(quicksum(useR_M[r, j, k, next] for j in SLOTS) <= 1)
                for j_pre in SLOTS:
                    model.addConstr(start[next] >= end[pre] - M * (1 - useR_M[r, j_pre, k, pre]))

for order in products:
    model.addConstr(
        quicksum(useR_M[r, slot, mould, order] for r in worker for mould in device for slot in SLOTS) == 1)
    model.addConstrs(
        quicksum(useR_M[r, slot, mould, order] for slot in SLOTS) <= STEP_MOULDS[order, mould]
        for r in worker for mould in device)
    model.addConstrs(
        quicksum(useR_M[r, slot, mould, order] for slot in SLOTS) <= worker_M[r, mould]
        for r in worker for mould in device)

model.addConstrs(
    quicksum(useR_M[r, slot, mould, order] for r in worker for order in products) <= 1
    for mould in device for slot in SLOTS)
model.addConstrs(
    quicksum(useR_M[r, slot, mould, order] for mould in device for order in products) <= 1
    for r in worker for slot in SLOTS)


for mould in device:
    for slot in SLOTS:
        for order in products:
            for r in worker:
                if worker_M[r, mould] == 1 and STEP_MOULDS[order, mould] == 1:
                    if slot > 0:
                        model.addConstr(
                            start[order] >= mSlotEndTime[mould, slot - 1] - M * (
                                    1 - useR_M[r, slot, mould, order])
                        )
for r in worker:
    for slot in SLOTS:
        for order in products:
            for mould in device:
                if worker_M[r, mould] == 1 and STEP_MOULDS[order, mould] == 1:
                    if slot > 0:
                        model.addConstr(
                            start[order] >= rSlotEndTime[r, slot - 1] - M * (
                                    1 - useR_M[r, slot, mould, order])
                        )

for mould in device:
    model.addConstr(mSlotStartTime[mould, 0] == 0)
for r in worker:
    model.addConstr(rSlotStartTime[r, 0] == 0)
for mould in device:
    for slot in SLOTS[1:]:
        model.addConstr(mSlotEndTime[mould, slot - 1] <= mSlotStartTime[mould, slot])
for r in worker:
    for slot in SLOTS[1:]:
        model.addConstr(rSlotEndTime[r, slot - 1] <= rSlotStartTime[r, slot])

 # 将产品的开始时间与工人分配给该产品的最早开始时间相关联
for i in products:
    for k in device:
        for r in worker:
            for j in SLOTS:
                if STEP_MOULDS[i, k] == 1 and worker_M[r, k] == 1:
                    model.addConstr(start[i] >= rSlotStartTime[r, j] - M * (1 - useR_M[r, j, k, i]))
# 将产品的结束时间与工人完成该产品的最晚结束时间相关联
for i in products:
    for k in device:
        for r in worker:
            for j in SLOTS:
                if STEP_MOULDS[i, k] == 1 and worker_M[r, k] == 1:
                    model.addConstr(end[i] <=  rSlotEndTime[r, j] + M * (1 - useR_M[r, j, k, i]))


 # 将产品的开始时间与工人分配给该产品的最早开始时间相关联
for i in products:
    for r in worker:
        for k in device:

            for j in SLOTS:
                if STEP_MOULDS[i, k] == 1 and worker_M[r, k] == 1:
                    model.addConstr(start[i] >= mSlotStartTime[k, j] - M * (1 - useR_M[r, j, k, i]))
# 将产品的结束时间与工人完成该产品的最晚结束时间相关联
for i in products:
    for r in worker:
        for k in device:
            for j in SLOTS:
                if STEP_MOULDS[i, k] == 1 and worker_M[r, k] == 1:
                    model.addConstr(end[i] <=  mSlotEndTime[k, j] + M * (1 - useR_M[r, j, k, i]))


model.addConstr(timeSpan == max_([end[i] for i in products]))
model.addConstr(timeSpan1 == max_([mSlotEndTime[mould,slot] for mould in device for slot in SLOTS]))
model.setParam("TimeLimit",3600)

model.setObjective(0.94*timeSpan+0.01*totalPower+timeM*0.05, GRB.MINIMIZE)
model.update()
model.optimize()
free_total=0
for mould in device:
    for slot in SLOTS:
        string = mould + '\t' + '%10s' % str(mSlotStartTime[mould,slot].x) + '%10s' % str(mSlotEndTime[mould,slot].x) + '\t'
        print(string)
        if slot>0:
            free_total+= (freePower[mould]*(mSlotStartTime[mould,slot].x-mSlotEndTime[mould,slot-1].x))
print("free_total",free_total)
if model.status == GRB.OPTIMAL:
    print('总时长：', timeSpan.x)
    print('总能耗:', totalPower.x)
    print('总机器时长:', timeM.x)
else:
    print('Optimization ended with status', model.status)
print('\n\n###############################   输出结果   ######################################\n')
print('总时长：', timeSpan.x)
print('总能耗:', totalPower.x+free_total)
print('总:', timeM.x)
print('订单工序计划：')
for order in products:
    string = order + '\t' + '%10s' % str(start[order].x) + '%10s' % str(end[order].x) + '\t'
    stop = 0
    for mould in device:
        for slot in SLOTS:
            for r in worker:
                if abs(useR_M[r, slot, mould, order].x - 1) <= 0.01:
                    string = string + mould + '\t'
                    string = string + r + '\t'
                    stop = 1
                    break
            if stop == 1:
                break
    print(string)
print('\n')
print('设备使用计划:')
for mould in device:
    for slot in SLOTS:
        for r in worker:
            for order in products:
                if abs(useR_M[r, slot, mould, order].x - 1) <= 0.01:
                    string = ''
                    if mSlotEndTime[mould, slot].x > mSlotStartTime[mould, slot].x:
                        string = mould + '%10s' % str(mSlotStartTime[mould, slot].x) + '%10s' % str(
                            mSlotEndTime[mould, slot].x) + '\t'
                        stop = 0
                        string = string + order + '\t'
                        string = string + r + '\t'
                        print(string)
for r in worker:
    for slot in SLOTS:
        for mould in device:
            for order in products:
                if abs(useR_M[r, slot, mould, order].x - 1) <= 0.01:
                    string = ''
                    if rSlotEndTime[r, slot].x > rSlotStartTime[r, slot].x:
                        string = r + '%10s' % str(rSlotStartTime[r, slot].x) + '%10s' % str(
                            rSlotEndTime[r, slot].x) + '\t'
                        stop = 0
                        string = string + order + '\t'
                        string = string + mould + '\t'
                        print(string)
print(free_total)